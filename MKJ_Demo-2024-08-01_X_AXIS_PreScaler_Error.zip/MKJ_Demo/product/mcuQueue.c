#include "mcuQueue.h"


MQue m_Queue;

void initQueue(void)
{
	m_Queue.n32Front = 0;
	m_Queue.n32Rear = -1;
  m_Queue.u32Count = 0;
}
/**
	@return 0--��Ϊ�գ�-1�򲻿�
*/
int32_t isQueueEmpty(void)
{
	int32_t n32Ret = m_Queue.u32Count == 0? 0:-1;
	return n32Ret;
}
/**
	@return 0--��Ϊ����-1����
*/
int32_t isQueueFull(void)
{
	int32_t n32Ret = m_Queue.u32Count == __ST_PLTCMD_LENGTH__? 0:-1;
	return n32Ret;
} 

uint32_t getQueueFreeSpace(void)
{
	 return __ST_PLTCMD_LENGTH__ - m_Queue.u32Count;
}

int32_t InputQueue(CMDToM stValue)
{
	if (isQueueFull() == 0) {
		return -1;
  }
  m_Queue.n32Rear = (m_Queue.n32Rear + 1) % __ST_PLTCMD_LENGTH__;
  m_Queue.pSTCMDToMotor[m_Queue.n32Rear] = stValue;
  m_Queue.u32Count++;
  return m_Queue.u32Count;
}
CMDToM OutputQueue(void)
{
	CMDToM stRet;
	stRet.u32VoiceCoilEN = 0;
	stRet.u32MXDir = 0;
	stRet.u32MXMoveDis = 0;
	stRet.u32XPreScaler = 1;
	stRet.u32XCMR = 0;
	stRet.u32XCNR = 0;
	stRet.u32MYDir = 0;
	stRet.u32MYMoveDis = 0;
	stRet.u32YCMR = 0;
	stRet.u32YCNR = 0;
	stRet.u32YPreScaler = 1;
	if (isQueueEmpty() == 0) {
     return stRet;
	}	
	stRet = m_Queue.pSTCMDToMotor[m_Queue.n32Front];
  m_Queue.n32Front = (m_Queue.n32Front + 1) % __ST_PLTCMD_LENGTH__;
  m_Queue.u32Count--;
  return stRet;
} 
