#include "NuMicro.h"

#include "mcuMotorOp_MKJ.h"
#include "mcuID_MKJ.h"
#include "mcuCmd_MKJ.h"
#include "mcuNet_MKJ.h"
#include "mcuNet_MKJ_Addr.h"
#include "mcu_DataStruct.h"
#include "mcuQueue.h"

//--------------------------------------------
//uint32_t g_u32StopZeroToFar = 0;
uint32_t g_u32StopFarToZero = 0;
//--------------------------------------------
uint32_t g_u32WidthPulse = 0;
uint32_t g_u32LengthPulse = 0;
uint32_t g_u32MKJWidthPulse = 0;

uint32_t g_u32LB_XMargin = 0; // ҳ�߾�
uint32_t g_u32LB_YMargin = 0;

uint32_t g_u32LT_XMargin = 0;
uint32_t g_u32LT_YMargin = 0;

uint32_t g_u32RT_XMargin = 0;
uint32_t g_u32RT_YMargin = 0;
//--------------------------------------------
uint32_t g_IM_u32XZero = 0;
uint32_t g_IM_u32YZero = 0;

uint32_t g_IM_u32LBX = 0;
uint32_t g_IM_u32RBX = 0;
uint32_t g_IM_u32LTY = 0;

uint32_t g_IM_u32XPeriodCount = 0;
uint32_t g_IM_u32YPeriodCount = 0;
//--------------------------------------------
uint32_t g_X_MovingError = 0;
uint32_t g_Y_MovingError = 0;

//uint32_t g_IM_u32XCMR = 0;
//uint32_t g_IM_u32XCNR = 0;

//uint32_t g_IM_u32YCMR = 0;
//uint32_t g_IM_u32YCNR = 0;
//--------------------------------------------
float64_t g_f_EachXStepUm = 0.00;
float64_t g_f_EachYStepUm = 0.00;
uint32_t g_u32XMoveDistance = 0;
uint32_t g_u32YMoveDistance = 0;
//--------------------------------------------
uint32_t g_u32LastVoiceEN = 1;

uint32_t g_u32LastXCNR = 0;
uint32_t g_u32LastXCMR = 0;
uint32_t g_u32LastXPreScaler = 1;
uint32_t g_u32LastYCNR = 0;
uint32_t g_u32LastYCMR = 0;
uint32_t g_u32LastYPreScaler = 1;
//--------------------------------------------
uint32_t g_u32VoiceOpMode = __VOICE_MOTOR_CARVE__;
//--------------------------------------------
uint32_t g_u32INSENSORToFGR = 0;
uint32_t g_u32FGRToOUTSENSOR = 0;

uint32_t g_InPutToScanMark = 0;
uint32_t g_OutPutToScanMark = 0;

uint32_t g_u32MachineWidth = 0;
//--------------------------------------------

void f_CalculateMMToPulse(void) 
{
	/*uint32_t u32XOne = 3600/__X_AXIS_STEP_ANGLE__;
	uint32_t u32XeachMM = __X_AXIS_SUBDIVISION__ * u32XOne;
	g_u32WidthPulse = Conf_PLTInfo.u32PaperWidth;//(u32XeachMM * Conf_PLTInfo.u32PaperWidth)/__X_AXIS_SHAFT_LENGTH__;
	g_u32MKJWidthPulse = (u32XeachMM*__MKJ_WIDTH__)/__X_AXIS_SHAFT_LENGTH__;
	
	uint32_t u32YOne = 3600/__Y_AXIS_STEP_ANGLE__;
	uint32_t u32YeachMM = (__Y_AXIS_SUBDIVISION__ * u32YOne)/__Y_AXIS_SHAFT_LENGTH__;	
	g_u32LengthPulse = Conf_PLTInfo.u32PaperLength;//u32YeachMM * Conf_PLTInfo.u32PaperLength;
	g_u32HeighPulseRecord = g_u32LengthPulse;*/

	g_f_EachXStepUm = (float64_t)CONF.X10000Steps / 10000;
	float64_t XTotal = (float64_t)Conf_PLTInfo.u32PaperWidth / g_f_EachXStepUm;
	g_u32WidthPulse = (uint32_t) XTotal;
	
	g_f_EachYStepUm = (float64_t)CONF.Y10000Steps / 10000;
	float64_t YTotal = (float64_t)Conf_PLTInfo.u32PaperLength / g_f_EachYStepUm;
	g_u32LengthPulse = (uint32_t) YTotal;
	printf("Width:%u,Length:%u\n",g_u32WidthPulse,g_u32LengthPulse);
	
	g_u32INSENSORToFGR = (uint32_t)((float64_t)CONF.INSToFGW / g_f_EachYStepUm);
	g_u32FGRToOUTSENSOR = (uint32_t)((float64_t)CONF.FGWToOUTS / g_f_EachYStepUm);
	
	
	g_u32LB_XMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32LBMarkX / g_f_EachXStepUm); // ҳ�߾�
	g_u32LB_YMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32LBMarkY / g_f_EachYStepUm);

	g_u32LT_XMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32LTMarkX / g_f_EachXStepUm);
	g_u32LT_YMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32LTMarkY / g_f_EachYStepUm);

	g_u32RT_XMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32RTMarkX / g_f_EachXStepUm);
	g_u32RT_YMargin = (uint32_t)((float64_t)Conf_PLTInfo.u32RTMarkY / g_f_EachYStepUm);
	
	g_InPutToScanMark = (uint32_t)(__DISTANCE_INPUT_SCANMARK__ / g_f_EachYStepUm);
	g_OutPutToScanMark = (uint32_t)(__DISTANCE_OUTPUT_SCANMARK__ / g_f_EachYStepUm);
	
	g_u32MachineWidth = (uint32_t)(__DISTANCE_PLATFORM_WIDTH__ / g_f_EachXStepUm);
}

void f_WaitForNextBatchCMD(void) 
{
	initQueue();
	g_u32X_Axis_MoveState = __X_AXIS_MOVING__;
	g_u32Y_Axis_MoveState = __Y_AXIS_MOVING__;
	g_IM_u32XPeriodCount = 0;
	g_IM_u32YPeriodCount = 0;
	g_u32X_Axis_MoveState = 0;
}

void f_XAxis_MotorStop_WithAccInt(void) 
{
	P_C_M1_EN = 0;

}

void f_YAxis_MotorStop_WithAccInt(void)
{
	P_C_M3_EN = 0;

}
//--------------------------------------------
uint32_t g_u32VoiceCoil_IM_PeriodCount = 0;
uint32_t g_u32VoiceCoil_IM_RunCount = 0;
//--------------------------------------------
void f_VoiceCoil_Enable(void)
{
	SYS_UnlockReg();
#if defined(DEBUG) || defined(DEBUG0)
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR 
								| SYS_GPA_MFPL_PA2MFP_EPWM0_CH3 | SYS_GPA_MFPL_PA3MFP_EPWM0_CH2 | SYS_GPA_MFPL_PA1MFP_UART0_TXD
								| SYS_GPA_MFPL_PA0MFP_UART0_RXD;
										//SYS_GPA_MFPL_PA2MFP_BPWM0_CH3 | SYS_GPA_MFPL_PA3MFP_BPWM0_CH2 SYS_GPA_MFPL_PA2MFP_BPWM0_CH3
#else
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR;
#endif	
	NVIC_EnableIRQ(EPWM0P2_IRQn);
	SYS_LockReg();
}

void f_VoiceCoil_DisEnable(void)
{
	SYS_UnlockReg();
#if defined(DEBUG) || defined(DEBUG0)
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR 
								| SYS_GPA_MFPL_PA1MFP_UART0_TXD
								| SYS_GPA_MFPL_PA0MFP_UART0_RXD;
										//SYS_GPA_MFPL_PA2MFP_BPWM0_CH3 | SYS_GPA_MFPL_PA3MFP_BPWM0_CH2 SYS_GPA_MFPL_PA2MFP_BPWM0_CH3
#else
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR;
#endif	
	
	GPIO_SetMode(PA, BIT2 | BIT3 ,GPIO_MODE_OUTPUT);
	NVIC_DisableIRQ(EPWM0P2_IRQn);
	SYS_LockReg();
}

//---------------------------------------
