#include <stdio.h>

#include "NuMicro.h"
#include "mcu_DataStruct.h"

MKJDrivePara CONF = {
	.EMACTime = 3,
	.UPTime = 2,
	.InitTime = 120,
	.ADTime = 2,
	.FeedingFhz = 10000,
	.XAxisFhz = 15000,
	.YAxisFhz = 15000,
	.XCutFhz = 10000,
	.YCutFhz = 10000,
	.XMarkDis = 25000,
	.YMarkDis = 50000,
	.X10000Steps = 49000, 
	.Y10000Steps = 41200,
	.INSToFGW = 46000,
	.FGWToOUTS = 74000,
};

MKJDrivePara CONF_orig = {
	.EMACTime = 3,
	.UPTime = 2,
	.InitTime = 120,
	.ADTime = 2,
	.FeedingFhz = 10000,
	.XAxisFhz = 15000,
	.YAxisFhz = 15000,
	.XCutFhz = 10000,
	.YCutFhz = 10000,
	.XMarkDis = 25000,
	.YMarkDis = 50000,
	.X10000Steps = 49000, 
	.Y10000Steps = 41200,
	.INSToFGW = 46000,
	.FGWToOUTS = 74000,
};

PLTUDPH Conf_PLTInfo = {
	.u32HeadFlag=0,
	.u32TotalCount=0,
	.u32FileLength=0,
	.u32PaperLength=0,
	.u32PaperWidth=0,
	.u32LTMarkX=0,
	.u32LTMarkY=0,
	.u32RTMarkX=0,
	.u32RTMarkY=0,
	.u32LBMarkX=0,
	.u32LBMarkY=0,
	.u32RBMarkX=0,
	.u32RBMarkY=0,
	.u32CropCount=0,
	.arReserved = {0},
};


