#ifndef  _MCU_NET_H_
#define  _MCU_NET_H_

#include <stdint.h>

#define __PACKET_MAX_LENGTH__ 1056
#define __UDPPACKET_INFO_COUNT__	24	//1056/44

extern uint32_t MKJReadConfig(void);
extern uint32_t MKJReSetConfig(void);
extern uint32_t MKJWriteConfig(void);

extern uint32_t MKJOutPutStatus(void);
extern uint32_t iMKJOutPutStatus(void) ;//通知上位机将要复位
extern uint32_t foo(void);
extern uint32_t bar(void);

extern uint32_t Recv_PENUp_Move(void);
extern uint32_t Recv_PENDown_Move(void);
extern uint32_t Recv_PLTIN_PlotterInit(void);

extern uint32_t Recv_PENSelect(void);
//------------------------------------------------
extern uint32_t Recv_X_AXIS_Patrol(void);
extern uint32_t Recv_Y_AXIS_Patrol(void);

extern uint32_t Recv_Border_Patrol(void);
extern uint32_t Recv_ChangeSensorState(void);
//------------------------------------------------
extern uint32_t Send_NextBatchPLTCMD(void);
//------------------------------------------------
extern uint32_t Recv_Test_M_Run(void);
extern uint32_t Recv_Test_M_Stop(void);

extern uint32_t Recv_VoiceCoil_Run(void);
extern uint32_t Recv_VoiceCoil_Stop(void);

extern uint32_t Recv_Test_XiFeng(void);

extern uint32_t Recv_Test_M_ChangeSpeed(void);
extern uint32_t Recv_Test_AccPause_Continue(void);
extern uint32_t Recv_Test_SetCameraState(void);
//------------------------------------------------
extern uint32_t Recv_FirstPacket(void);
extern uint32_t Recv_No_FirstPacket(void);

extern uint32_t Send_BeginNoFirst(void);
extern uint32_t Send_ReSend_Recv(void);
extern uint32_t Send_Wait_Recv(void);
extern uint32_t Send_Continue_Recv(void);
extern uint32_t Recv_Default(void);
extern uint32_t Send_ReadUART(void);
//------------------------------------------------
extern uint32_t Recv_RUNMachine_NoMARK(void);
extern uint32_t Recv_VoiceCoil_Period(void);
//------------------------------------------------

#endif

