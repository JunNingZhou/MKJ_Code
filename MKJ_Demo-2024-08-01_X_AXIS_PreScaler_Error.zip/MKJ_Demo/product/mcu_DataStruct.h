#ifndef  _MCU_DATA_STRUCT_H_
#define  _MCU_DATA_STRUCT_H_

#include <stdio.h>

#ifdef RVDS_ARMCM4_NUC4xx
#include "arm_math.h"
#endif

typedef struct MKJDrive {
	uint32_t EMACTime;
	uint32_t UPTime;
	uint32_t InitTime;
	uint32_t ADTime;
	uint32_t FeedingFhz;
	uint32_t XAxisFhz;
	uint32_t YAxisFhz;
	uint32_t XCutFhz;
	uint32_t YCutFhz;
	uint32_t XMarkDis;
	uint32_t YMarkDis;
	uint32_t X10000Steps;
	uint32_t Y10000Steps;
	uint32_t INSToFGW;
	uint32_t FGWToOUTS;
}MKJDrivePara;

typedef struct PLTCmd {
	uint32_t uiCmd;
	uint32_t uiParam1;
	uint32_t uiParam2;
}PLTCMD;

typedef struct PLTUDPHeader {
	uint32_t u32HeadFlag;
	uint32_t u32TotalCount;
	uint32_t u32FileLength;
	uint32_t u32PaperLength;
	uint32_t u32PaperWidth;
	uint32_t u32LTMarkX;
	uint32_t u32LTMarkY;
	uint32_t u32RTMarkX;
	uint32_t u32RTMarkY;
	uint32_t u32LBMarkX;
	uint32_t u32LBMarkY;
	uint32_t u32RBMarkX;
	uint32_t u32RBMarkY;
	uint32_t u32CropCount;
	uint32_t arReserved[20];
} PLTUDPH;

typedef struct PLTCMDToM {
	uint32_t u32VoiceCoilEN;
	uint32_t u32MXDir;
	uint32_t u32MXMoveDis;
	uint32_t u32XCMR;
	uint32_t u32XCNR;
	uint32_t u32XPreScaler;
	uint32_t u32MYDir;
	uint32_t u32MYMoveDis;
	uint32_t u32YCMR;
	uint32_t u32YCNR;
	uint32_t u32YPreScaler;
} CMDToM;

typedef struct OffsetPoint {
	uint32_t u32PointX;
	uint32_t u32PointY;
}OffP;


#endif

