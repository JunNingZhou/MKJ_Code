#ifndef _MCU_CMD_TMD_H_
#define _MCU_CMD_TMD_H_

#include <stdint.h>

#include "epwm_reg.h"
#include "mcu_DataStruct.h"

/////////////////////////////////////////////////////
//�������
//---------------------------------------------------------OUTHEAT
#define P_C_OUTHEAT	PA4
#define B_C_OUTHEAT	BIT4
#define N_C_OUTHEAT	4
//---------------------------------------------------------camera
#define P_C_OUTCAMERA	PC1
#define B_C_OUTCAMERA	BIT1
#define N_C_OUTCAMERA	1
//---------------------------------------------------------XIFEN
#define P_C_OUTFAN_1 PG13
#define	B_C_OUTFAN_1 BIT13
#define N_C_OUTFAN_1 13

#define P_C_OUTFAN_2 PG14
#define B_C_OUTFAN_2 BIT14
#define N_C_OUTFAN_2 14
//---------------------------------------------------------BUZZER
#define P_C_BUZZER	PE15
#define B_C_BUZZER	BIT15
#define N_C_BUZZER	15
//---------------------------------------------------------LED
#define P_C_OUT_LED1 PA11
#define B_C_OUT_LED1 BIT11
#define N_C_OUT_LED1 11

#define P_C_OUT_LED2 PA10
#define B_C_OUT_LED2 BIT10
#define N_C_OUT_LED2 10

#define P_C_OUT_LED3 PA9
#define B_C_OUT_LED3 BIT9
#define N_C_OUT_LED3 9

#define P_C_OUT_LED4 PA8
#define B_C_OUT_LED4 BIT8
#define N_C_OUT_LED4 8
//---------------------------------------------------------INPUT
//---------------------------------------------------------Y IN INPUT12
#define P_C_YIN PB4	//INT1	
#define B_C_YIN BIT4
#define N_C_YIN 4
//---------------------------------------------------------Y OUT INPUT14
#define P_C_YOUT PB7 //INT5
#define B_C_YOUT BIT7
#define N_C_YOUT 7
//---------------------------------------------------------X Zere INPUT8
#define P_C_XZERO	PB3	//INT2
#define B_C_XZERO BIT3
#define N_C_XZERO	3
//---------------------------------------------------------X  Far INPUT6
#define P_C_XFAR	PC11
#define B_C_XFAR	BIT11
#define N_C_XFAR	11
//---------------------------------------------------------
#define P_C_INPUT_1	PC10		
#define B_C_INPUT_1	BIT10
#define N_C_INPUT_1	10

#define P_C_INPUT_2	PC9	
#define B_C_INPUT_2	BIT9
#define N_C_INPUT_2	9

#define P_C_INPUT_3	PB0		
#define B_C_INPUT_3	BIT0
#define N_C_INPUT_3	0

#define P_C_INPUT_4	PB1		
#define B_C_INPUT_4	BIT1
#define N_C_INPUT_4	1

#define P_C_INPUT_5	PC12	
#define B_C_INPUT_5	BIT12
#define N_C_INPUT_5	12

#define P_C_INPUT_7	PB2	//INT3	
#define B_C_INPUT_7	BIT2
#define N_C_INPUT_7	2

#define P_C_INPUT_9	PB12
#define B_C_INPUT_9	BIT12
#define N_C_INPUT_9	12

#define P_C_INPUT_10 PB13
#define B_C_INPUT_10 BIT13
#define N_C_INPUT_10 13

#define P_C_INPUT_11 PB5	//INT0	
#define B_C_INPUT_11 BIT5
#define N_C_INPUT_11 5

#define P_C_INPUT_13 PB6	//INT4
#define B_C_INPUT_13 BIT6
#define N_C_INPUT_13 6	

#define P_C_INPUT_15 PB14
#define B_C_INPUT_15 BIT14
#define N_C_INPUT_15 14

#define P_C_INPUT_16 PB15
#define B_C_INPUT_16 BIT15
#define N_C_INPUT_16 15

#define P_C_INPUT_17 PB9	//INT7
#define B_C_INPUT_17 BIT9
#define N_C_INPUT_17 9

#define P_C_INPUT_18 PB8	//INT6
#define B_C_INPUT_18 BIT8
#define N_C_INPUT_18 8

#define P_C_INPUT_19 PB10
#define B_C_INPUT_19 BIT10
#define N_C_INPUT_19 10

#define P_C_INPUT_20 PB11
#define B_C_INPUT_20 BIT11
#define N_C_INPUT_20 11
//---------------------------------------------------------DIR
#define P_C_M1_DIR	PD9
#define B_C_M1_DIR	BIT9
#define N_C_M1_DIR	9

#define P_C_M2_DIR	PD8
#define B_C_M2_DIR	BIT8
#define N_C_M2_DIR	8

#define P_C_M3_DIR	PG9
#define B_C_M3_DIR	BIT9
#define N_C_M3_DIR	9

#define P_C_M4_DIR	PG10
#define B_C_M4_DIR	BIT10
#define N_C_M4_DIR	10

#define P_C_M5_DIR	PG11
#define B_C_M5_DIR	BIT11
#define N_C_M5_DIR	11

#define P_C_M6_DIR	PG12
#define B_C_M6_DIR	BIT12
#define N_C_M6_DIR	12

#define P_C_M7_DIR	PF9
#define B_C_M7_DIR	BIT9
#define N_C_M7_DIR	9

#define P_C_M8_DIR	PF7
#define B_C_M8_DIR	BIT7
#define N_C_M8_DIR	7
//---------------------------------------------------------EN
#define P_C_M1_EN	PG15
#define B_C_M1_EN	BIT15
#define N_C_M1_EN	15

#define P_C_M2_EN	PD13
#define B_C_M2_EN	BIT13
#define N_C_M2_EN	13

#define P_C_M3_EN	PA12
#define B_C_M3_EN	BIT12
#define N_C_M3_EN	12

#define P_C_M4_EN	PA13
#define B_C_M4_EN	BIT13
#define N_C_M4_EN	13

#define P_C_M5_EN	PA14
#define B_C_M5_EN	BIT14
#define N_C_M5_EN	14

#define P_C_M6_EN	PA15
#define B_C_M6_EN	BIT15
#define N_C_M6_EN	15

#define P_C_M7_EN	PF8
#define B_C_M7_EN	BIT8
#define N_C_M7_EN	8

#define P_C_M8_EN	PF6
#define B_C_M8_EN	BIT6
#define N_C_M8_EN	6
//---------------------------------------------------------���
#define C_M1_PWM	EPWM1
#define C_M2_PWM	EPWM1
#define C_M3_PWM	EPWM1
#define C_M4_PWM	EPWM1
#define C_M5_PWM	EPWM1
#define C_M6_PWM	EPWM1
#define C_M7_PWM	EPWM0
#define C_M8_PWM	EPWM0


#define EPWM0_CH0		0
#define EPWM0_CH1		1
#define EPWM0_CH2		2
#define EPWM0_CH3		3
#define EPWM0_CH4		4
#define EPWM0_CH5		5

#define EPWM1_CH0		0
#define EPWM1_CH1		1
#define EPWM1_CH2		2
#define EPWM1_CH3		3
#define EPWM1_CH4		4
#define EPWM1_CH5		5

//���M1 ����
#define C_M1_PUL 				EPWM1_CH0
#define C_M1_PUL_MASK 	EPWM_CH_0_MASK
//���M2 ����
#define C_M2_PUL				EPWM1_CH1
#define C_M2_PUL_MASK		EPWM_CH_1_MASK
//���M3 ����
#define C_M3_PUL				EPWM1_CH2
#define C_M3_PUL_MASK		EPWM_CH_2_MASK
//���M4 ����
#define C_M4_PUL				EPWM1_CH3
#define C_M4_PUL_MASK		EPWM_CH_3_MASK
//���M5 ����
#define C_M5_PUL				EPWM1_CH4
#define C_M5_PUL_MASK		EPWM_CH_4_MASK
//���M6 ����
#define C_M6_PUL				EPWM1_CH5
#define C_M6_PUL_MASK		EPWM_CH_5_MASK

//���M7 ����
#define C_M7_PUL				EPWM0_CH4
#define C_M7_PUL_MASK		EPWM_CH_4_MASK
//���M8 ����
#define C_M8_PUL				EPWM0_CH5
#define C_M8_PUL_MASK		EPWM_CH_5_MASK
//---------------------------------------------------------
//���縴λ�˿�
#define P_EMACRESET PA5 
#define B_EMACRESET BIT5
#define N_EMACRESET 5

#define FSM_FREE   	0
#define FSM_PRINT   1
#define FSM_WORK   	2
#define FSM_ALARM  	4

#define Dsr GPIO_DBCTL_DBCLKSEL_8 //��̬������ȥ������ʱ
#define Isr 16 //��̬������ȥ������ʱ

//������Ϣ
extern uint32_t RxBuf[1514];

#define UDPLength 42

//UDPLength  42 �ֽ� + Addr (����) 2�ֽ� �� 44�ֽ� /4(32λ) = 11 
//#define  theAddr  RxBuf[10]   //

#define theCmd  RxBuf[0]

#define gP0  RxBuf[1]
#define gP1  RxBuf[2]
#define gP2  RxBuf[3]
#define gP3  RxBuf[4]
#define gP4  RxBuf[5]
#define gP5  RxBuf[6]
#define gP6  RxBuf[7]
#define gP7  RxBuf[8]
#define gP8  RxBuf[9]
#define gP9  RxBuf[10]
#define gPa  RxBuf[11]
#define gPb  RxBuf[12]
#define gPc  RxBuf[13]
#define gPd  RxBuf[14]
#define gPe  RxBuf[15]
#define gPf  RxBuf[16]
//------------------------------------------------
int set_data_flash_base(void);
void GenConfig(void);
void LoadConfig(void);
//------------------------------------------------
#define __MAX_MKJ_FHZ__	100000
#define __MAX_ACC_INT__	65000

extern MKJDrivePara CONF;
extern MKJDrivePara CONF_orig;
//------------------------------------------------
extern PLTUDPH Conf_PLTInfo;
//------------------------------------------------��ǰ��λ��X,Y
extern int32_t g_n32XOffset;
extern int32_t g_n32YOffset;
//------------------------------------------------
extern uint32_t g_uiPaperLength;
extern uint32_t g_uiPaperWidth;
//------------------------------------------------
extern volatile uint32_t g_u32ExpectPacketNumber;
extern volatile uint32_t g_u32UploadRecvFailed;

extern uint32_t g_u32PLTCMDTotalCount;//�ܹ���ָ����

extern volatile uint32_t g_u32RunFinishCount;
//------------------------------------------------

#define __SENSOR_OCCLUSION__	0 //�ڱ�
#define __SENSOR_EXPOSURE__		1 //��¶

#define BIT_SHOW_YIN			0x01			//�� 0 ���� 1
#define BIT_SHOW_YOUT			0x01<<1		//�� 0 ���� 1
#define BIT_SHOW_XZERO		0x01<<2		//�� 0 ���� 1
#define BIT_SHOW_XFAR			0x01<<3		//�� 0 ���� 1

#define BIT_SHOW_CAMOUT		0x01<<4
#define BIT_SHOW_CANIN		0x01<<5
#define BIT_SHOW_PAPER		0x01<<6
//------------------------------------------------
#define __FLAG_RECV_BEGIN__						1003
#define __FLAG_RECV_WAIT__						1004
#define __FLAG_RECV_MID_WAIT__				1005
#define __FLAG_RECV_CONTINUE__				1006
#define __FLAG_RECV__MID_CONTINUE__		1007
#define __FLAG_RECV_FINISH__					1008
#define __FLAG_RECV_RESEDN__					1009
#define __FLAG_RECV_MID_RESEDN__			1010
#define __FLAG_RECV_NOMAL__						1011

extern uint32_t g_u32FlagRecvState;
//------------------------------------------------
#define __FLAG_RUNSTATE_INIT__							1099
#define __FLAG_RUNSTATE_BEGIN__ 						1100
#define __FLAG_RUNSTATE_BEFORE_SCAN_MARK__	1101
#define __FLAG_RUNSTATE_FINDXMARK__					1102
#define __FLAG_RUNSTATE_FINDYMARK__					1103
#define __FLAG_RUNSTATE_RECVDATA__					1104
#define __FLAG_RUNSTATE_END__								1105
#define __FLAG_RUNSTATE_TEST__							1106
#define __FLAG_RUNSTATE_TEST_2__						1107
#define __FLAG_RUNSTATE_TEST_3__						1108
#define __FLAG_RUNSTATE_TEST_4__						1109

extern uint32_t g_u32FlagRunState;
//------------------------------------------------
#define __FLAG_MOVE_PU__			22010
#define __FLAG_MOVE_PD__			22011
#define __FLAG_MOVE_NULL__		22012
//#define __FLAG_UP_XCMR_CNR__	22013
//#define __FLAG_UP_YCMR_CNR__	22014
#define __FLAG_MOVE_XMOTOR__	22015
#define __FLAG_MOVE_YMOTOR__	22016

extern uint32_t g_u32FlagMoveState;
//------------------------------------------------
#define __ZERO_SENSOR_DETECTED__	100112
#define __ZERO_SENSOR_STOP__			100113
#define __ZERO_SENSOR_NULL__			100114

extern uint32_t g_u32ZeroStop_IM_PeriodCount;
extern uint32_t g_u32FlagZeroStop;
//------------------------------------------------
#define __FLAG_BEFORE_SCAN_STEP1__	1130
#define __FLAG_BEFORE_SCAN_STEP2__	1131
#define __FLAG_BEFORE_SCAN_STEP3__	1132
#define __FLAG_BEFORE_SCAN_STEP4__	1133

extern uint32_t g_u32FlagBeforeSacnState;
//------------------------------------------------
#define __FLAG_SCAN_X_MARK_STEP1__		1122
#define __FLAG_SCAN_X_MARK_STEP2__		1123
#define __FLAG_SCAN_X_MARK_STEP3__		1124
#define __FLAG_SCAN_X_MARK_NULL__			1125

#define __FLAG_SCAN_Y_MARK_STEP1__		1126
#define __FLAG_SCAN_Y_MARK_STEP2__		1127
#define __FLAG_SCAN_Y_MARK_STEP3__		1128
#define __FLAG_SCAN_Y_MARK_NULL__			1129

extern uint32_t g_u32FlagScanState;
//------------------------------------------------
extern uint32_t g_u32CompletedCopies;

#define __X_AXIS_MOVING__		125
#define __X_AXIS_MOVEDOME__	126
#define __Y_AXIS_MOVING__		127
#define __Y_AXIS_MOVEDOME__	128

extern uint32_t g_u32X_Axis_MoveState;
extern uint32_t g_u32Y_Axis_MoveState;
//------------------------------------------------
#define __X_MOTOT_ZERO_STOP__  	9
#define __X_MOTOR_FAR_STOP__	 	10
#define __X_MOTOR_RUN_ZERO__		12
#define __X_MOTOR_RUN_FAR__	 	 	13

#define __Y_MOTOR_RUN_AHEAD__	 	14
#define __Y_MOTOR_RUN_BACK__	 	15

#define __Y_MOTOR_ARRIVED_STOP__	27
#define __X_MOTOR_ARRIVED_STOP__	28

#define __X_MOTOR_CAR_STOP__		18
#define __Y_MOTOR_CAR_STOP__		19

#define __X_MOTOR_PATROL_STOP__	16
#define __Y_MOTOR_PATROL_STOP__	17

#define __Y_INTOOUT_MOVE_LENGTH__	21
#define __Y_OUTTOIN_MOVE_LENGTH__	22

#define __X_ZEROTOFAR_MOVE_WIDTH__	23
#define __X_FARTOZERO_MOVE_WIDTH__	24

#define __Y_PAPER_FEEDOUT_STOP__	29

#define __X_ZERO_RUN_AND_STOP__	30 //���ֹͣ ��Ҫ������3����

#define __FEED_SENDING__	25
#define __FEED_STOP__			26
//------------------------------------------------
extern OffP g_arstOffsetPoint[4];

extern uint32_t g_u32PointFindXCount;
extern uint32_t g_u32PointFindYCount;
//-------------------------------------------------
extern uint32_t g_u32INSENSORToFGR; //��ֽ������������
extern uint32_t g_u32FGRToOUTSENSOR; // ���ֵ���ֽ������
//--------------------------------------------
#define RX_BUFFER_SIZE 128
extern volatile uint8_t g_u8RxBuffer[RX_BUFFER_SIZE];
extern volatile uint32_t g_u32RxIndex;

#define __DISTANCE_PLATFORM_WIDTH__				490000.000f
#define __DISTANCE_INPUT_OUTPUT_SENSOR__	120000.000f
#define	__DISTANCE_FIRST_SECOND_WHEELS__	50000.000f
#define __DISTANCE_INPUT_FIRST_S_W__			46000.000f
#define __DISTANCE_FIRST_OUTPUT_S_W__			74000.000f
#define __DISTANCE_INPUT_SCANMARK__				70000.000f
#define __DISTANCE_OUTPUT_SCANMARK__			50000.000f
//--------------------------------------------
#define __NO_MARK_FEED_PAPER__					12334
#define __NO_MARK_Y_MOTOR_AHEAD__				12335
#define __NO_MARK_X_RUN_MARK1__					12336
#define __NO_MARK_X_SCAN_MARK_BEGIN__		12337
#define __NO_MARK_X_SCAN_MARK_MID__			12338
#define __NO_MARK_X_SCAN_MARK_END__			12339
#define __NO_MARK_Y_MOTOR_BACK__				12340

#define __NO_MARK_RUN_NULL__				12355

extern uint32_t g_u32FlagNoMarkRunState;
//--------------------------------------------
extern void CalCMRCNR_UpdateMotorSpeed(EPWM_T* pepwm, uint32_t uiChannelNum, uint32_t nNewFhz);
extern void X_Y_AXIS_Running(CMDToM stCmd);

#define __XIFENG_OPEN__		0
#define __XIFENG_CLOSE__	1

#endif /* _CMD_H_ */


