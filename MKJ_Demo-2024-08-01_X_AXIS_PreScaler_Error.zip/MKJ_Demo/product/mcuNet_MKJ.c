#include "NuMicro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mcuID_MKJ.h"
#include "mcuCmd_MKJ.h"
#include "mcuNet_MKJ.h"
#include "mcuNet_MKJ_Addr.h"
#include "mcu_DataStruct.h"
#include "mcuQueue.h"
#include "mcuMotorOp_MKJ.h"



uint32_t foo(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00,
    0x00,
    FOO_ID,
    0,
    0,
    0,
    0,
    ADDRTAG,
	};
   return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t bar(void)
{
	CLK_SysTickLongDelay(100);
  //PowerOff();
	// �رյ�Դ
  // dy_sleep
  //Log(BN(TMPrintPowerOff����\r\n));
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    BAR_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
//------------------------------------------------
uint32_t Recv_PENUp_Move(void)
{
	uint32_t uiX = gP0;
	uint32_t uiY = gP1;
	PLTCMD stCmd;
	stCmd.uiCmd = 0x5055;
	stCmd.uiParam1 = uiX;
	stCmd.uiParam2 = uiY;
	uint8_t auPkt[UDPLength + 12] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    PLTCMD_PU_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_PENDown_Move(void)
{
	uint32_t uiX = gP0;
	uint32_t uiY = gP1;
	PLTCMD stCmd;
	stCmd.uiCmd = 0x5044;
	stCmd.uiParam1 = uiX;
	stCmd.uiParam2 = uiY;
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    PLTCMD_PD_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_PLTIN_PlotterInit(void) 
{
	uint32_t uiPaperLengt = gP0;
	uint32_t uiPaperWidth = gP1;
	uint32_t u32CmdLength = gP2;
	printf("---CmdLength:%u---\n",u32CmdLength);
	
	//g_uiPaperLength = uiPaperLengt;
	//g_uiPaperWidth = uiPaperWidth;	

	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    PLTCMD_IN_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}

uint32_t Recv_PENSelect(void)
{
	uint32_t uiPen = gP0;
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    PLTCMD_SP_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

//------------------------------------------------
uint32_t Recv_X_AXIS_Patrol(void) //X��Ѳ��
{
	uint32_t nFhz = gP0;
	EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,nFhz,50);
	EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
	uint32_t u32Period = gP1;
	P_C_OUTCAMERA = gP1;
	g_u32XMoveDistance = 0;
	g_u32YMoveDistance = 0;
	P_C_M1_EN = 1;
	P_C_M1_DIR = 1;
	EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    X_AXIS_PATROL_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
uint32_t Recv_Y_AXIS_Patrol(void) //Y��Ѳ��
{
	uint32_t nFhz = gP0;
	EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,nFhz,50);
	EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);
	EPWM_EnableAcc(C_M3_PWM,C_M3_PUL,5000,EPWM_IFA_PERIOD_POINT);//�������� 
	EPWM_EnableAccInt(C_M3_PWM,C_M3_PUL);
		
	P_C_M3_EN = 1;
	P_C_M3_DIR = 0;
	EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    Y_AXIS_PATROL_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_Border_Patrol(void) 
{
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    BORDER_PATROL_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}

uint32_t Recv_ChangeSensorState(void) 
{
	uint32_t u32Switch = gP0;
	uint32_t u32Value = gP1;
	switch (u32Switch)
  {
  	case 1:
			P_C_INPUT_4 = gP1;
  		break;
  	case 2: 
			P_C_INPUT_18 = gP1;
  		break;
  	default:
  		break;
  }
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    SENSOR_VALUE_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}
//------------------------------------------------
uint32_t Send_NextBatchPLTCMD(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    PLTCMD_SP_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
		(0)&0xFF, (0>>8)&0xFF,(0>>16)&0xFF,(0>>24)&0xFF,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
//------------------------------------------------
uint32_t Recv_Test_M_Run(void)
{
	uint32_t uWhichM = gP0;
	uint32_t nFhz = gP1;
	uint32_t nDir = gP2;
	printf("nWhich:%u,nFhz:%u,nDir:%u\n",uWhichM,nFhz,nDir);
	switch (uWhichM)
  {
  	case 1: {
			EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,nFhz,50);
			EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
			uint32_t u32Account = gP3;
			if(u32Account != 0) {
				printf("Recv_Test_M_Run u32ACC:%u\n",u32Account);
				EPWM_EnableAcc(C_M1_PWM,C_M1_PUL,u32Account,EPWM_IFA_COMPARE_UP_COUNT_POINT);
				EPWM_EnableAccInt(C_M1_PWM,C_M1_PUL);
			}
			uint32_t u32Period = gP4;
			if(u32Period != 0) {
				printf("Recv_Test_M_Run u32Period:%u\n",u32Period);
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);
				g_u32XMoveDistance = u32Period;
			}
			P_C_M1_EN = 1;
			P_C_M1_DIR = nDir;
			EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
		}
  		break;
  	case 2: {
			EPWM_ConfigOutputChannel(C_M2_PWM,C_M2_PUL,nFhz,50);
			EPWM_EnableOutput(C_M2_PWM,C_M2_PUL_MASK);
			P_C_M2_EN = 1;
			P_C_M2_DIR = nDir;
			EPWM_Start(C_M2_PWM,C_M2_PUL_MASK);
		}
  		break;
		case 3: {
			EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,nFhz,50);
			EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);	
			uint32_t u32Account = gP3;
			if(u32Account != 0) {
				EPWM_EnableAcc(C_M3_PWM,C_M3_PUL,u32Account,EPWM_IFA_PERIOD_POINT);
				EPWM_EnableAccInt(C_M3_PWM,C_M3_PUL);
			}
			uint32_t u32Period = gP4;
			if(u32Period != 0) {
				EPWM_EnablePeriodInt(C_M3_PWM,C_M3_PUL,0);
				g_u32YMoveDistance = u32Period;
			}			
			P_C_M3_EN = 1;
			P_C_M3_DIR = nDir;
			EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
		}		
  		break;
		case 4: {
			EPWM_ConfigOutputChannel(C_M4_PWM,C_M4_PUL,nFhz,50);
			EPWM_EnableOutput(C_M4_PWM,C_M4_PUL_MASK);
			P_C_M4_EN = 1;
			P_C_M4_DIR = nDir;
			EPWM_Start(C_M4_PWM,C_M4_PUL_MASK);
		}
  		break;
		case 5: {
			EPWM_ConfigOutputChannel(C_M5_PWM,C_M5_PUL,nFhz,50);
			EPWM_EnableOutput(C_M5_PWM,C_M5_PUL_MASK);
			P_C_M5_EN = 1;
			P_C_M5_DIR = nDir;
			EPWM_Start(C_M5_PWM,C_M5_PUL_MASK);
		}
  		break;
		case 6: {
			EPWM_ConfigOutputChannel(C_M6_PWM,C_M6_PUL,nFhz,50);
			EPWM_EnableOutput(C_M6_PWM,C_M6_PUL_MASK);
			P_C_M6_EN = 1;
			P_C_M6_DIR = nDir;
			EPWM_Start(C_M6_PWM,C_M6_PUL_MASK);
		}
  		break;
		case 7: {
			EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,nFhz,50);
			EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
			EPWM_ConfigCaptureChannel(C_M1_PWM,C_M1_PUL,52,0);
			EPWM_EnableCapture(C_M1_PWM,C_M1_PUL_MASK);
			P_C_M1_EN = 1;
			P_C_M1_DIR = nDir;
			EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
		}
			break;
  	default:
  		break;
  }
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_M_RUN_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_Test_M_Stop(void) 
{
	uint32_t uWhichM = gP0;
	switch (uWhichM)
  {
  	case 1: {
			EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
			EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
			EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
		}
  		break;
  	case 2: {
			EPWM_Stop(C_M2_PWM,C_M2_PUL_MASK);
			EPWM_ForceStop(C_M2_PWM,C_M2_PUL_MASK);
			EPWM_DisableOutput(C_M2_PWM,C_M2_PUL_MASK);
		}
  		break;
		case 3: {
			EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
			EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
			EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);
		}
  		break;
		case 4: {
			EPWM_Stop(C_M4_PWM,C_M4_PUL_MASK);
			EPWM_ForceStop(C_M4_PWM,C_M4_PUL_MASK);
			EPWM_DisableOutput(C_M4_PWM,C_M4_PUL_MASK);
		}
  		break;
		case 5: {
			EPWM_Stop(C_M5_PWM,C_M5_PUL_MASK);
			EPWM_ForceStop(C_M5_PWM,C_M5_PUL_MASK);
			EPWM_DisableOutput(C_M5_PWM,C_M5_PUL_MASK);
		}
  		break;
		case 6: {
			EPWM_Stop(C_M6_PWM,C_M6_PUL_MASK);
			EPWM_ForceStop(C_M6_PWM,C_M6_PUL_MASK);
			EPWM_DisableOutput(C_M6_PWM,C_M6_PUL_MASK);
		}
  		break;
  	default:
  		break;
  }
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_M_STOP_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_Test_M_ChangeSpeed(void) 
{
	uint32_t uWhichM = gP0;
	uint32_t u32NewFhz = gP1;
	switch (uWhichM)
  {
  	case 1: {
			CalCMRCNR_UpdateMotorSpeed(C_M1_PWM,C_M1_PUL,u32NewFhz);
		}
  		break;
  	case 2: {
			CalCMRCNR_UpdateMotorSpeed(C_M3_PWM,C_M3_PUL,u32NewFhz);
		}
  		break;
  	default:
  		break;
  }
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_M_C_SPEED_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}


uint32_t Recv_VoiceCoil_Run(void)
{
	uint32_t u32Mode = gP0;
	g_u32VoiceOpMode = u32Mode;
	uint32_t u32Duty = gP1;
	f_VoiceCoil_Enable();
	if(u32Mode == 1) {
		EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH2,10000,u32Duty);
		EPWM_EnableOutput(EPWM0,EPWM_CH_2_MASK);
		EPWM_Start(EPWM0,EPWM_CH_2_MASK);	
		
		EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
		EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
		EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
	} else if(u32Mode == 2) {
		EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH3,10000,u32Duty);
		EPWM_EnableOutput(EPWM0,EPWM_CH_3_MASK);
		EPWM_Start(EPWM0,EPWM_CH_3_MASK);	
		
		EPWM_Stop(EPWM0,EPWM_CH_2_MASK);
		EPWM_ForceStop(EPWM0,EPWM_CH_2_MASK);
		EPWM_DisableOutput(EPWM0,EPWM_CH_2_MASK);
	} else if(u32Mode == 3) {
		EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH2,10000,u32Duty);
		EPWM_EnableOutput(EPWM0,EPWM_CH_2_MASK);
		EPWM_Start(EPWM0,EPWM_CH_2_MASK);	
		
		EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH3,10000,u32Duty);
		EPWM_EnableOutput(EPWM0,EPWM_CH_3_MASK);
		EPWM_Start(EPWM0,EPWM_CH_3_MASK);	
	}
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    VOICECOIL_RUN_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}

uint32_t Recv_VoiceCoil_Stop(void)
{
	EPWM_Stop(EPWM0,EPWM_CH_2_MASK);
	EPWM_ForceStop(EPWM0,EPWM_CH_2_MASK);
	EPWM_DisableOutput(EPWM0,EPWM_CH_2_MASK);
	
	EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
	EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
	EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
	f_VoiceCoil_DisEnable();
	PA2 = 0;
	PA3 = 0;
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    VOICECOIL_STOP_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}

uint32_t Recv_Test_XiFeng(void) 
{
	uint32_t u32Open = gP0;
	P_C_OUTFAN_1 = u32Open;
	P_C_OUTFAN_2 = u32Open;
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_XIFENG_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}

uint32_t Recv_Test_AccPause_Continue(void) 	
{
	uint32_t u32Mode = gP0;
	printf("Mode == %u\n",u32Mode);

	if(u32Mode == 1) {
		uint32_t u32AccCount = gP1;
		uint32_t u32Speed = gP2;
		g_u32WidthPulse = u32AccCount;
		EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,u32Speed,50);
		EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);		
		P_C_M1_EN = 1;
		P_C_M1_DIR = 1;
		P_C_OUTCAMERA = 1;
		P_C_OUT_LED1 = 1;
		P_C_OUT_LED2 = 0;
		P_C_OUT_LED3 = 0;
		
		EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
	} else if(u32Mode == 2) {
		P_C_M1_EN = 0;
		EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
		EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
		EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
	} else if(u32Mode == 3) {
		EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
		P_C_M1_EN = 1;
		EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
	}
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN116, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK16, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN216, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_M_RUN_ACC_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
		(u32Mode)&0xFF, (u32Mode>>8)&0xFF,(u32Mode>>16)&0xFF,(u32Mode>>24)&0xFF,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_Test_SetCameraState(void) 
{
	P_C_INPUT_18 = gP0;
	P_C_OUTCAMERA = gP1;
	uint32_t g_stInput = 0x00000000;
	g_stInput |= (P_C_YIN) ? BIT_SHOW_YIN : 0x0000;
	g_stInput |= (P_C_YOUT) ? BIT_SHOW_YOUT : 0x0000;
	g_stInput |= (P_C_XZERO) ? BIT_SHOW_XZERO : 0x0000;
	g_stInput |= (P_C_XFAR) ? BIT_SHOW_XFAR : 0x0000;
	g_stInput |= (P_C_OUTCAMERA) ? BIT_SHOW_CAMOUT:0x0000;
	g_stInput |= (P_C_INPUT_18) ? BIT_SHOW_CANIN:0x0000;
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN116, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK16, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN216, //	data[38] ; data[39]
    0x00, 0x00,
    TEST_SET_CAM_STATE_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
		(g_stInput)&0xFF, (g_stInput>>8)&0xFF,(g_stInput>>16)&0xFF,(g_stInput>>24)&0xFF,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
//------------------------------------------------
uint32_t Recv_FirstPacket(void)
{
	memcpy(&Conf_PLTInfo,(void*)&gP0,sizeof(Conf_PLTInfo));
	g_u32PLTCMDTotalCount = Conf_PLTInfo.u32FileLength / sizeof(CMDToM);
	//g_u32FlagRecvState = __FLAG_RECV_BEGIN__;
	printf("sizeof(Conf_PLTInfo) = %u, sizeof(PLTUDPH) = %u \n",sizeof(Conf_PLTInfo),sizeof(PLTUDPH));
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    FIRST_PACKET_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_No_FirstPacket(void)
{
	printf("Expect Index:%u,Curr Index:%u\n",g_u32ExpectPacketNumber,gP0);
	if (g_u32ExpectPacketNumber == gP0) {		
		g_u32UploadRecvFailed = 0;
		if(getQueueFreeSpace() < __UDPPACKET_INFO_COUNT__) {//getStackFreeSpace() < 20
			g_u32FlagRecvState = __FLAG_RECV_WAIT__;
			printf("Recv_No_FirstPacket : __FLAG_RECV_WAIT__\n");
		} else {
			int32_t nIndex = 2;
			for (int i=0;i<__UDPPACKET_INFO_COUNT__;i++) {
				CMDToM stCmd;
				stCmd.u32VoiceCoilEN = RxBuf[nIndex++];
				stCmd.u32MXDir = RxBuf[nIndex++];
				stCmd.u32MXMoveDis = RxBuf[nIndex++];
				stCmd.u32XCMR = RxBuf[nIndex++];
				stCmd.u32XCNR = RxBuf[nIndex++];
				stCmd.u32XPreScaler = RxBuf[nIndex++];
				stCmd.u32MYDir = RxBuf[nIndex++];
				stCmd.u32MYMoveDis = RxBuf[nIndex++];
				stCmd.u32YCMR = RxBuf[nIndex++];
				stCmd.u32YCNR = RxBuf[nIndex++];	
				stCmd.u32YPreScaler = RxBuf[nIndex++];
				int32_t nRet = InputQueue(stCmd);
				//printf("Recv_%d\n",nRet); 
			}
			g_u32ExpectPacketNumber++;
		}
	} else {
		g_u32UploadRecvFailed++;
		if(g_u32UploadRecvFailed == 2) {
			g_u32FlagRecvState = __FLAG_RECV_RESEDN__;
		}
	}
	return 0;
}

uint32_t Send_BeginNoFirst(void) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		//�ܳ��� ��ʵudp������ +28(���֡����-14)
		LEN116, // data[16], data[17]
		IFTU,
		// CheckSum1
		CK16, // 0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		// ����  ��ʵudp������ + 8 (���֡����-34)
		LEN216, //	data[38] ; data[39]
		// CheckSum2
		0x00, 0x00,
		BEGIN_SEND_NOFIRST_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_u32ExpectPacketNumber)&0xFF, (g_u32ExpectPacketNumber>>8)&0xFF,(g_u32ExpectPacketNumber>>16)&0xFF,(g_u32ExpectPacketNumber>>24)&0xFF,
	};
	return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Send_ReSend_Recv(void) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		//�ܳ��� ��ʵudp������ +28(���֡����-14)
		LEN116, // data[16], data[17]
		IFTU,
		// CheckSum1
		CK16, // 0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		// ����  ��ʵudp������ + 8 (���֡����-34)
		LEN216, //	data[38] ; data[39]
		// CheckSum2
		0x00, 0x00,
		NOT_EXCEPT_PACKET_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_u32ExpectPacketNumber)&0xFF, (g_u32ExpectPacketNumber>>8)&0xFF,(g_u32ExpectPacketNumber>>16)&0xFF,(g_u32ExpectPacketNumber>>24)&0xFF,
	};
	return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Send_Wait_Recv(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		//�ܳ��� ��ʵudp������ +28(���֡����-14)
		LEN116, // data[16], data[17]
		IFTU,
		// CheckSum1
		CK16, // 0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		// ����  ��ʵudp������ + 8 (���֡����-34)
		LEN216, //	data[38] ; data[39]
		// CheckSum2
		0x00, 0x00,
		SEND_RECV_WAIT_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_u32ExpectPacketNumber)&0xFF, (g_u32ExpectPacketNumber>>8)&0xFF,(g_u32ExpectPacketNumber>>16)&0xFF,(g_u32ExpectPacketNumber>>24)&0xFF,
	};
	return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}
uint32_t Send_Continue_Recv(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		//�ܳ��� ��ʵudp������ +28(���֡����-14)
		LEN116, // data[16], data[17]
		IFTU,
		// CheckSum1
		CK16, // 0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		// ����  ��ʵudp������ + 8 (���֡����-34)
		LEN216, //	data[38] ; data[39]
		// CheckSum2
		0x00, 0x00,
		SEND_RECV_CONTINUE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_u32ExpectPacketNumber)&0xFF, (g_u32ExpectPacketNumber>>8)&0xFF,(g_u32ExpectPacketNumber>>16)&0xFF,(g_u32ExpectPacketNumber>>24)&0xFF,
	};
	return EMAC_SendPkt(auPkt, sizeof(auPkt));	
}
//-------------------------------------------------------------
uint32_t Recv_Default(void) 
{
	EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz,50);
	EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
	P_C_M1_EN = 1;
	P_C_M1_DIR = 0;
	EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
	return 0;
}

uint32_t Send_ReadUART(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_READ_UART_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
//-------------------------------------------------------------
uint32_t Recv_RUNMachine_NoMARK(void) 
{
	memcpy(&Conf_PLTInfo,(void*)&gP0,sizeof(Conf_PLTInfo));
	g_u32PLTCMDTotalCount = Conf_PLTInfo.u32FileLength / sizeof(CMDToM);
	printf("Total CMD:%u\n",g_u32PLTCMDTotalCount);
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN116, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK16, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN216, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    RUN_MACHINE_NO_MARK_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
		(g_u32PLTCMDTotalCount)&0xFF, (g_u32PLTCMDTotalCount>>8)&0xFF,(g_u32PLTCMDTotalCount>>16)&0xFF,(g_u32PLTCMDTotalCount>>24)&0xFF,	
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t Recv_VoiceCoil_Period(void) 
{
	g_u32VoiceCoil_IM_RunCount = gP0;
	uint32_t u32Duty = gP1;
	f_VoiceCoil_Enable();
	EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH2,10000,u32Duty);
	EPWM_EnableOutput(EPWM0,EPWM_CH_2_MASK);
	EPWM_Start(EPWM0,EPWM_CH_2_MASK);	
		
	EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
	EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
	EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
	
	uint8_t auPkt[] = {
		YOURMAC,
    MYMAC,
    VLD,
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
    // CheckSum2
    0x00, 0x00,
    TEST_VOICECOIL_PERIOD_ID,
    0x00,0x00,0x00,0x00,
    ADDRTAG,
	};
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
//-------------------------------------------------------------

