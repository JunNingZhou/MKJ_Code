#ifndef _MCU_QUEUE_H_
#define _MCU_QUEUE_H_

#include <stdint.h>
#include "mcu_DataStruct.h"

#define __ST_PLTCMD_LENGTH__ 3000

typedef struct MCUQueue
{
	CMDToM pSTCMDToMotor[__ST_PLTCMD_LENGTH__];
	int32_t n32Front;	//ͷ
  int32_t n32Rear;	//β
  uint32_t u32Count; //
} MQue;

extern MQue m_Queue;

extern void initQueue(void);
/**
	@return 0--��Ϊ�գ�-1�򲻿�
*/
int32_t isQueueEmpty(void);
/**
	@return 0--��Ϊ����-1����
*/
int32_t isQueueFull(void); 
uint32_t getQueueFreeSpace(void);
int32_t InputQueue(CMDToM stValue);
CMDToM OutputQueue(void); 


#endif //_MCU_QUEUE_H_

