#include "NuMicro.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include <arm_math.h>

#include "absacc.h"

#include "mcuID_MKJ.h"
#include "mcuCmd_MKJ.h"
#include "mcuNet_MKJ.h"
#include "mcuNet_MKJ_Addr.h"
#include "mcu_DataStruct.h"
#include "mcuMotorOp_MKJ.h"
#include "mcuQueue.h"


static volatile uint32_t InitTime = 0; //����ʱ��ʱ��ʼ��

static volatile uint32_t EMACTime = 0;

static volatile uint32_t UPTime = 0;

static volatile uint32_t tempUPTime = 0;

static volatile uint32_t BEEPTime = 0; //����

static uint8_t g_au8MacAddr[6] = { MYMAC0,MYMAC1,MYMAC2,MYMAC3,MYMAC4,MYMAC5};

static uint8_t g_au8IpAddr[4] = { MYIP0,MYIP1,MYIP2,MYIP3 };

static uint8_t g_au8MacAddrArp[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

volatile uint8_t g_au8YourMacAddr[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

uint32_t RxBuf[1514] = { 0 };

static uint8_t pRxBufByte[UDPLength] = { 0 };

static uint8_t auNetPkt[1514] = { 0 };

static uint32_t volatile u32PktLen = 0;
//------------------------------------------------
static uint32_t g_u32TestCount = 0;//����
//------------------------------------------------
//------------------------------------------------
int32_t g_n32XOffset = 0;//X��ƫ��
int32_t g_n32YOffset = 0;//Y��ƫ��
//------------------------------------------------
uint32_t g_u32CompletedCopies = 0;	//����е�����
uint32_t g_u32X_Axis_MoveState = __X_AXIS_MOVING__;//X���Ƿ����е�λ
uint32_t g_u32Y_Axis_MoveState = __Y_AXIS_MOVING__;//Y���Ƿ����е�λ
//------------------------------------------------
volatile uint32_t g_u32UploadRecvFailed = 0;//����ʧ�ܴ���
volatile uint32_t g_u32ExpectPacketNumber = 1;//������ID
uint32_t g_u32PLTCMDTotalCount = 0;//�ܹ�����
volatile uint32_t g_u32RunFinishCount = 0;//��ɲ���

uint32_t g_u32FlagRecvState = __FLAG_RECV_FINISH__;// ���հ�״̬
//------------------------------------------------
uint32_t g_u32FlagRunState = __FLAG_RUNSTATE_INIT__;// ����״̬
uint32_t g_u32FlagScanState = __FLAG_SCAN_X_MARK_STEP1__; 
uint32_t g_u32FlagBeforeSacnState = __FLAG_BEFORE_SCAN_STEP1__;
uint32_t g_u32FlagMoveState = __FLAG_MOVE_NULL__;
//------------------------------------------------
uint32_t g_u32ZeroStop_IM_PeriodCount = 0;
uint32_t g_u32FlagZeroStop = __ZERO_SENSOR_NULL__;
//------------------------------------------------
OffP g_arstOffsetPoint[4] = {0,0};	//MARK��X Yλ��
uint32_t g_u32PointFindXCount = 0;	//X��MARK��
uint32_t g_u32PointFindYCount = 0;	//Y��MARK��
//------------------------------------------------
static volatile uint32_t g_sPaperINSensor = 0; // ��ֽ������
static volatile uint32_t g_sZeroMARK = 0;
static volatile uint32_t g_sPaperOUTSensor = 0; // ��ֽ������ 
//------------------------------------------------
static uint32_t g_st_u32ReSendNotFirst = 0;
//------------------------------------------------
volatile uint8_t g_u8RxBuffer[RX_BUFFER_SIZE] = {0};
volatile uint32_t g_u32RxIndex = 0;
//------------------------------------------------
uint32_t g_u32FlagNoMarkRunState = __NO_MARK_RUN_NULL__;
//--------------------------------------------

void EMAC_TX_IRQHandler(void)
{
	// Log(BN(EMAC_TX_IRQHandler));
	EMAC_SendPktDone();
}
void EMAC_RX_IRQHandler(void)
{
	//uint32_t i = 0;
	//Log(BN(EMAC_RX_IRQHandler));
	//  EMACTime = 0; //?���жϾ�֤������������

	while (1) {
		if (EMAC_RecvPkt(auNetPkt, (uint32_t*)&u32PktLen) == 0)
			break;

		//		Log(BN(�յ�����,���� %d \r\n),u32PktLen);
		//	EMACTime = 0; //?��Ҫ�յ����ݲ��㣿
		EMAC_RecvPktDone();
	}
}

static int EMACINT = 0;
static int EMACINTOO = 0;

void TMR0_IRQHandler(void)
{
	EMACTime++;
	UPTime++;
	InitTime++;
	g_u32TestCount++;
	g_st_u32ReSendNotFirst++;
	if (EMACINT == 0) {
		EMACINTOO ^= 1;
		if (EMACINTOO) {
			// Log(BN(�������� !\r\n));
			P_EMACRESET = 1;
		}
		else {
			//	Log(BN(�������� !\r\n));
			P_EMACRESET = 0;
		}
	}

	//OK	Log(BN(��ѭ������ʱ�䵽...));
	TIMER_ClearIntFlag(TIMER0);
}

//---------------------------------------
// ���²��� �Ӷ������ٶ�
void CalCMRCNR_UpdateMotorSpeed(EPWM_T* pepwm, uint32_t uiChannelNum, uint32_t nNewFhz) 
{
	uint32_t CNRAdd1 = FREQ_192MHZ/nNewFhz;
	uint32_t CMRAdd1 = CNRAdd1/2;
	EPWM_SET_CNR(pepwm,uiChannelNum,CNRAdd1-1);
	EPWM_SET_CMR(pepwm,uiChannelNum,CMRAdd1-1);
}

void X_Y_AXIS_Running(CMDToM stCmd) 
{
	if(stCmd.u32VoiceCoilEN == 1) {
		g_u32FlagMoveState = __FLAG_MOVE_PU__;
		g_X_MovingError = 0;
		g_Y_MovingError = 0;	
		if(stCmd.u32MXMoveDis == 0) {
			g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
			g_u32XMoveDistance = 0;
			if(P_C_M1_EN != 0) {
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);	
			}			
		} 
		else {
			g_u32X_Axis_MoveState = __X_AXIS_MOVING__;
			g_u32XMoveDistance = stCmd.u32MXMoveDis;
			if(P_C_M1_EN == 0) {
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XCutFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);		
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);		
				P_C_M1_EN = 1;
				P_C_M1_DIR = stCmd.u32MXDir;				
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
			} else {
				P_C_M1_DIR = stCmd.u32MXDir;
				CalCMRCNR_UpdateMotorSpeed(C_M1_PWM,C_M1_PUL,CONF.XCutFhz);
			}
		}
		
		if(stCmd.u32MYMoveDis == 0) {
			g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
			g_u32YMoveDistance = 0;
			if(P_C_M3_EN != 0) {
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);	
			}
		} 
		else {
			g_u32Y_Axis_MoveState = __Y_AXIS_MOVING__;
			g_u32YMoveDistance = stCmd.u32MYMoveDis;
			if(P_C_M3_EN == 0) {
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,CONF.YCutFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_EnablePeriodInt(C_M3_PWM,C_M3_PUL,0);
				P_C_M3_EN = 1;
				P_C_M3_DIR = stCmd.u32MYDir;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
			} else {
				P_C_M3_DIR = stCmd.u32MYDir;
				CalCMRCNR_UpdateMotorSpeed(C_M3_PWM,C_M3_PUL,CONF.YCutFhz);
			}
		}
		g_IM_u32XPeriodCount = 0;
		g_IM_u32YPeriodCount = 0;
	} 
	else if(stCmd.u32VoiceCoilEN == 0) { // ʹ��
		g_u32FlagMoveState = __FLAG_MOVE_PD__;
		if(stCmd.u32MXMoveDis == 0) {
			g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
			g_u32XMoveDistance = 0;
			g_u32FlagMoveState = __FLAG_MOVE_YMOTOR__;
			if(P_C_M1_EN != 0) {
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);	
			}	
		} 
		else {
			g_u32X_Axis_MoveState = __X_AXIS_MOVING__;
			g_u32XMoveDistance = stCmd.u32MXMoveDis + g_X_MovingError;
			if(P_C_M1_EN == 0) {
				uint32_t u32XFhz = (FREQ_192MHZ/stCmd.u32XPreScaler) / stCmd.u32XCNR;
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,u32XFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);		
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);
				P_C_M1_EN = 1;
				P_C_M1_DIR = stCmd.u32MXDir;				
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
				//EPWM_SET_PRESCALER(C_M1_PWM,C_M1_PUL,stCmd.u32XPreScaler);
				//EPWM_SET_CNR(C_M1_PWM,C_M1_PUL,stCmd.u32XCNR);
				//EPWM_SET_CMR(C_M1_PWM,C_M1_PUL,stCmd.u32XCMR);														
				printf("X Start,FHZ:%u\n",u32XFhz);
			} else {
				P_C_M1_DIR = stCmd.u32MXDir;
				EPWM_SET_PRESCALER(C_M1_PWM,C_M1_PUL,stCmd.u32XPreScaler);
				EPWM_SET_CNR(C_M1_PWM,C_M1_PUL,stCmd.u32XCNR);
				EPWM_SET_CMR(C_M1_PWM,C_M1_PUL,stCmd.u32XCMR);
			}
		}
		
		if(stCmd.u32MYMoveDis == 0) {
			g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
			g_u32YMoveDistance = 0;
			g_u32FlagMoveState = __FLAG_MOVE_XMOTOR__;
			if(P_C_M3_EN != 0) {
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);	
			}
		} 
		else {
			g_u32Y_Axis_MoveState = __Y_AXIS_MOVING__;
			g_u32YMoveDistance = stCmd.u32MYMoveDis + g_Y_MovingError;
			if(P_C_M3_EN == 0) {		
				uint32_t u32YFhz = (FREQ_192MHZ/stCmd.u32YPreScaler) / stCmd.u32YCNR;
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,u32YFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_EnablePeriodInt(C_M3_PWM,C_M3_PUL,0);
				P_C_M3_EN = 1;
				P_C_M3_DIR = stCmd.u32MYDir;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
				
				//EPWM_SET_PRESCALER(C_M3_PWM,C_M3_PUL, stCmd.u32YPreScaler);
				//EPWM_SET_CNR(C_M3_PWM,C_M3_PUL,stCmd.u32YCNR);
				//EPWM_SET_CMR(C_M3_PWM,C_M3_PUL,stCmd.u32YCMR);
				printf("Y Start,FHZ:%u\n",u32YFhz);
			} else {
				P_C_M3_DIR = stCmd.u32MYDir;
				EPWM_SET_PRESCALER(C_M3_PWM,C_M3_PUL, stCmd.u32YPreScaler);
				EPWM_SET_CNR(C_M3_PWM,C_M3_PUL,stCmd.u32YCNR);
				EPWM_SET_CMR(C_M3_PWM,C_M3_PUL,stCmd.u32YCMR);
			}
		}	
		g_IM_u32XPeriodCount = 0;
		g_IM_u32YPeriodCount = 0;
		
		if(g_X_MovingError >= __MAXIMUMIGNORED_ERROR__) {
			printf("XMove Distance Error:%u, Index:%u\n",g_X_MovingError,g_u32RunFinishCount - 1);
		}
		
		if(g_Y_MovingError >= __MAXIMUMIGNORED_ERROR__) {
			printf("YMove Distance Error:%u, Index:%u\n",g_Y_MovingError,g_u32RunFinishCount - 1);
		}
		g_X_MovingError = 0;
		g_Y_MovingError = 0;		
	}
	//===================================================	
	if(g_u32LastVoiceEN != stCmd.u32VoiceCoilEN) {
		g_u32LastVoiceEN = stCmd.u32VoiceCoilEN;
		if(stCmd.u32VoiceCoilEN == 0) {//ʹ��
			f_VoiceCoil_Enable();
			EPWM_ConfigOutputChannel(EPWM0,EPWM0_CH2,10000,100);
			EPWM_EnableOutput(EPWM0,EPWM_CH_2_MASK);
			EPWM_Start(EPWM0,EPWM_CH_2_MASK);	
			
			EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
			EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
			EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
		} else {
			//EPWM_Stop(EPWM0,EPWM_CH_2_MASK);
			//EPWM_ForceStop(EPWM0,EPWM_CH_2_MASK);
			//EPWM_DisableOutput(EPWM0,EPWM_CH_2_MASK);
			f_VoiceCoil_DisEnable();
			PA2 = 0;
			PA3 = 0;
		}
	}
	printf("Params:nVoiceEN:%u XDir:%u XDis:%u XCMR:%u,XCNR:%u,XPreScaler:%u,YDir:%u YDis:%u,YCMR:%u,YCNR:%u,YPreScaler:%u\n",
					stCmd.u32VoiceCoilEN,stCmd.u32MXDir,g_u32XMoveDistance,stCmd.u32XCMR,stCmd.u32XCNR,stCmd.u32XPreScaler,
					stCmd.u32MYDir,g_u32YMoveDistance,stCmd.u32YCMR,stCmd.u32YCNR,stCmd.u32YPreScaler);	
}
//---------------------------------------
void EPWM1P0_IRQHandler(void) // X���ڼ����ж�
{
	if(EPWM_GetPeriodIntFlag(C_M1_PWM,C_M1_PUL)) {
		EPWM_ClearPeriodIntFlag(C_M1_PWM,C_M1_PUL);
		g_IM_u32XPeriodCount++;
		g_u32ZeroStop_IM_PeriodCount++;
	}
}

void EPWM1P1_IRQHandler(void) // Y���ڼ����ж�
{
	if(EPWM_GetPeriodIntFlag(C_M3_PWM,C_M3_PUL)) {
		EPWM_ClearPeriodIntFlag(C_M3_PWM,C_M3_PUL);
		g_IM_u32YPeriodCount++;
	}
}
//---------------------------------------
void EPWM0P2_IRQHandler(void) //��Ȧ��� 
{
	if(EPWM_GetPeriodIntFlag(EPWM0,EPWM0_CH2)) {
		EPWM_ClearPeriodIntFlag(EPWM0,EPWM0_CH2);
		g_u32VoiceCoil_IM_PeriodCount++;
	}
}
//---------------------------------------
void GPB_IRQHandler(void) 
{
	if(GPIO_GET_INT_FLAG(PB,B_C_YIN)) {	
		if(P_C_YIN == __SENSOR_OCCLUSION__) {
			g_sPaperINSensor = 1;
		}
		GPIO_CLR_INT_FLAG(PB,B_C_YIN);
	} else if(GPIO_GET_INT_FLAG(PB,B_C_YOUT)) {
		if(P_C_YOUT == __SENSOR_OCCLUSION__) { // �½��� ��¶->�ڱ�
			g_sPaperOUTSensor = 1;
		} else if(P_C_YOUT == __SENSOR_EXPOSURE__){ // ������	�ڱ�->��¶
			g_sPaperOUTSensor = 2;
		}
		GPIO_CLR_INT_FLAG(PB,B_C_YOUT);
	} else if(GPIO_GET_INT_FLAG(PB,B_C_XZERO)) {	
		if(P_C_XZERO == __SENSOR_OCCLUSION__) {
			g_u32StopFarToZero = 1;
		} else {
			g_sZeroMARK = 1;
		}
		GPIO_CLR_INT_FLAG(PB,B_C_XZERO);
	}
}

//---------------------------------------
//static uint8_t stu8Flag = 0;
void UART2_IRQHandler(void) 
{
	//if(stu8Flag <= 20) {
			//stu8Flag += 1;
			//printf("UART2_IRQHandler\n");
	//}	
	P_C_OUT_LED1 = 0;
	P_C_OUT_LED2 = 1;
	P_C_OUT_LED3 = 0;
	uint32_t u32IntStatus = UART2->INTSTS;
	if (u32IntStatus & UART_INTSTS_RDAINT_Msk) {
		while (UART_GET_RX_EMPTY(UART2) == 0) {
			P_C_OUT_LED1 = 1;
			P_C_OUT_LED2 = 1;
			P_C_OUT_LED3 = 0;
			g_u8RxBuffer[g_u32RxIndex++] = UART_READ(UART2);
			if (g_u32RxIndex >= RX_BUFFER_SIZE) {
				g_u32RxIndex = 0; // ���¿�ʼ�洢����
			}
		}	
	}
}
//---------------------------------------
void SYS_Init(void)
{
	SYS_UnlockReg();

	PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);
	PF->MODE &= ~(GPIO_MODE_MODE4_Msk | GPIO_MODE_MODE5_Msk);

	CLK->PWRCTL |= CLK_PWRCTL_HXTEN_Msk; // XTAL12M (HXT) Enabled
	CLK->PWRCTL |= CLK_PWRCTL_LXTEN_Msk; // 32K (LXT) Enabled
	CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);
	CLK_WaitClockReady(CLK_STATUS_LXTSTB_Msk);

	CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HXT, CLK_CLKDIV0_HCLK(1));
	CLK_SetCoreClock(FREQ_192MHZ);
	CLK->PCLKDIV = CLK_PCLKDIV_PCLK0DIV1 | CLK_PCLKDIV_PCLK1DIV1;

	CLK_EnableModuleClock(EMAC_MODULE);
	CLK_EnableModuleClock(TMR0_MODULE); //

  CLK_EnableModuleClock(EPWM0_MODULE); //����Ҫ
	CLK_EnableModuleClock(EPWM1_MODULE); //����Ҫ
	
	CLK_SetModuleClock(EPWM1_MODULE,CLK_CLKSEL2_EPWM1SEL_PLL,(uint32_t)NULL);
	
	//CLK_EnableModuleClock(QEI0_MODULE);
	//CLK_EnableModuleClock(QEI1_MODULE);
	
	//CLK_EnableModuleClock(TMR1_MODULE); //����Ҫ
	//CLK_EnableModuleClock(TMR2_MODULE); //����Ҫ
	//CLK_EnableModuleClock(TMR3_MODULE); //����Ҫ
	
	CLK_EnableModuleClock(PDMA_MODULE);//��������ֱ�Ӵ洢��

	//CLK_EnableModuleClock(I2C1_MODULE);//����Ҫ
#if defined(DEBUG) || defined(DEBUG0)
	CLK_EnableModuleClock(UART0_MODULE);
	CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
#endif
	CLK_EnableModuleClock(UART2_MODULE);
	CLK_SetModuleClock(UART2_MODULE, CLK_CLKSEL3_UART2SEL_HXT, CLK_CLKDIV4_UART2(1));
	

	CLK_SetModuleClock(EMAC_MODULE, 0, CLK_CLKDIV3_EMAC(127));

	CLK_SetModuleClock(EPWM0_MODULE, CLK_CLKSEL2_EPWM0SEL_PLL, (uint32_t)NULL); //����Ҫ
	CLK_SetModuleClock(EPWM1_MODULE, CLK_CLKSEL2_EPWM1SEL_PLL, (uint32_t)NULL); //����Ҫ

	CLK_SetModuleClock(TMR0_MODULE, CLK_CLKSEL1_TMR0SEL_HXT, 0);
	//CLK_SetModuleClock(TMR1_MODULE, CLK_CLKSEL1_TMR1SEL_HXT, 0);
	//CLK_SetModuleClock(TMR2_MODULE, CLK_CLKSEL1_TMR2SEL_HXT, 0);
	//CLK_SetModuleClock(TMR3_MODULE, CLK_CLKSEL1_TMR3SEL_HXT, 0);
	
	SystemCoreClockUpdate();

//��ʵ������ר��IO ����һ��ʾ��	
	// SYS->GPA_MFPH = SYS_GPA_MFPH_PA8MFP_INT4;
	SYS->GPA_MFPH = 0x00000000;

#if defined(DEBUG) || defined(DEBUG0)
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR 
								| SYS_GPA_MFPL_PA2MFP_EPWM0_CH3 | SYS_GPA_MFPL_PA3MFP_EPWM0_CH2 | SYS_GPA_MFPL_PA1MFP_UART0_TXD
								| SYS_GPA_MFPL_PA0MFP_UART0_RXD;
										//SYS_GPA_MFPL_PA2MFP_BPWM0_CH3 | SYS_GPA_MFPL_PA3MFP_BPWM0_CH2 SYS_GPA_MFPL_PA2MFP_BPWM0_CH3
#else
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR;
#endif
	///*SYS_GPC_MFPH_PC11MFP_SPI3_MOSI | SYS_GPC_MFPH_PC10MFP_SPI3_CLK |*/
	SYS->GPC_MFPH = SYS_GPC_MFPH_PC13MFP_UART2_TXD | SYS_GPC_MFPH_PC8MFP_EMAC_RMII_REFCLK;
	SYS->GPC_MFPL = SYS_GPC_MFPL_PC7MFP_EMAC_RMII_RXD0 | SYS_GPC_MFPL_PC6MFP_EMAC_RMII_RXD1 | SYS_GPC_MFPL_PC5MFP_EPWM1_CH0 | SYS_GPC_MFPL_PC4MFP_EPWM1_CH1
									| SYS_GPC_MFPL_PC3MFP_EPWM1_CH2 | SYS_GPC_MFPL_PC2MFP_EPWM1_CH3 | /*SYS_GPC_MFPL_PC1MFP_EPWM1_CH4 |*/ SYS_GPC_MFPL_PC0MFP_EPWM1_CH5;
	
	/*| SYS_GPC_MFPL_PC4MFP_EPWM1_CH1 | SYS_GPC_MFPL_PC2MFP_EPWM1_CH3 | SYS_GPC_MFPL_PC0MFP_EPWM1_CH5*/
	
	SYS->GPD_MFPH = SYS_GPD_MFPH_PD14MFP_EPWM0_CH4 | SYS_GPD_MFPH_PD12MFP_UART2_RXD;
	SYS->GPD_MFPL = 0x00000000;

  SYS->GPE_MFPH = SYS_GPE_MFPH_PE12MFP_EMAC_RMII_TXEN | SYS_GPE_MFPH_PE11MFP_EMAC_RMII_TXD1 
									| SYS_GPE_MFPH_PE10MFP_EMAC_RMII_TXD0 | SYS_GPE_MFPH_PE9MFP_EMAC_RMII_MDIO | SYS_GPE_MFPH_PE8MFP_EMAC_RMII_MDC;

	SYS->GPE_MFPL = SYS_GPE_MFPL_PE7MFP_QEI1_INDEX | SYS_GPE_MFPL_PE6MFP_QEI1_A | SYS_GPE_MFPL_PE5MFP_QEI1_B
									| SYS_GPE_MFPL_PE4MFP_QEI0_INDEX | SYS_GPE_MFPL_PE3MFP_QEI0_A | SYS_GPE_MFPL_PE2MFP_QEI0_B;

	SYS->GPF_MFPH = 0x00000000;
	SYS->GPF_MFPL = SYS_GPF_MFPL_PF5MFP_X32_IN | SYS_GPF_MFPL_PF4MFP_X32_OUT | SYS_GPF_MFPL_PF3MFP_XT1_IN
								| SYS_GPF_MFPL_PF2MFP_XT1_OUT | SYS_GPF_MFPL_PF1MFP_ICE_CLK | SYS_GPF_MFPL_PF0MFP_ICE_DAT;

	SYS->GPG_MFPH = 0x00000000;
	SYS->GPG_MFPL = 0x00000000;
	SYS->GPH_MFPH = 0x00000000;
	//SYS->GPH_MFPH = SYS_GPH_MFPH_PH9MFP_SPI1_SS | SYS_GPH_MFPH_PH8MFP_SPI1_CLK;
	SYS->GPH_MFPL = SYS_GPH_MFPH_PH11MFP_EPWM0_CH5;

	// Enable high slew rate on all RMII TX output pins
	PE->SLEWCTL = (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN10_Pos) 
								| (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN11_Pos) | (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN12_Pos);

	//IIC����
	//PE->SMTEN |= GPIO_SMTEN_SMTEN1_Msk;
	//PH->SMTEN |= GPIO_SMTEN_SMTEN8_Msk;
	SYS_LockReg();
}

//��ʵ������ͨ��IO ����һ��ʾ��
__STATIC_INLINE void IO_Init(void)
{
	GPIO_SET_DEBOUNCE_TIME(GPIO_DBCTL_DBCLKSRC_LIRC, Dsr);
	//�������
	//���縴λ�˿�
	GPIO_SetMode(PA, B_EMACRESET |B_C_M3_EN | B_C_M4_EN | B_C_M5_EN | B_C_M6_EN 
										| B_C_OUT_LED1 | B_C_OUT_LED2 | B_C_OUT_LED3 | B_C_OUT_LED4
										| B_C_OUTHEAT,
										GPIO_MODE_OUTPUT);
	P_C_M3_EN = 0; P_C_M4_EN = 0; P_C_M5_EN = 0; P_C_M6_EN = 0;
	P_C_OUT_LED1 = 0; P_C_OUT_LED2 = 0; P_C_OUT_LED3 = 0; P_C_OUT_LED4 = 0;
	P_EMACRESET = 0;	

	GPIO_SetMode(PC,B_C_OUTCAMERA,
								GPIO_MODE_OUTPUT);
	P_C_OUTCAMERA = 0;
	
	GPIO_SetMode(PD,B_C_M2_EN | B_C_M1_DIR | B_C_M2_DIR,GPIO_MODE_OUTPUT);
	P_C_M2_EN = 0; P_C_M1_DIR = 1; P_C_M2_DIR = 0;
	
	GPIO_SetMode(PG,B_C_M1_EN | B_C_M3_DIR | B_C_M4_DIR | B_C_M5_DIR | B_C_M6_DIR
										| B_C_OUTFAN_1 | B_C_OUTFAN_2,
										GPIO_MODE_OUTPUT);
	P_C_M1_EN = 0; P_C_M3_DIR = 0; P_C_M4_DIR = 0; P_C_M5_DIR = 0; P_C_M6_DIR = 0;
	
	GPIO_SetMode(PF,B_C_M7_EN | B_C_M8_EN | B_C_M7_DIR | B_C_M8_DIR,GPIO_MODE_OUTPUT);
	P_C_M7_DIR = 0;P_C_M7_EN = 0; P_C_M8_DIR = 0;P_C_M8_EN = 0;
	//---------------------------------------
	GPIO_SetMode(PC, B_C_INPUT_1 | B_C_INPUT_2 | B_C_INPUT_5 | B_C_XFAR, GPIO_MODE_INPUT);
		
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_1);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_2);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_5);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_XFAR);
	
	GPIO_SetMode(PB, B_C_INPUT_3 | B_C_INPUT_4 | B_C_INPUT_7 | B_C_XZERO | B_C_INPUT_9 | B_C_INPUT_10
									 | B_C_INPUT_11 | B_C_YIN | B_C_INPUT_13 | B_C_YOUT 
									 | B_C_INPUT_15 | B_C_INPUT_16 | B_C_INPUT_17 | B_C_INPUT_18 
									 | B_C_INPUT_19 | B_C_INPUT_20, 
									GPIO_MODE_INPUT);	
	P_C_INPUT_18 = 0;
	P_C_INPUT_4 = 0;
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_3);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_3);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_7);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_XZERO);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_9);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_10);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_11);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_YIN);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_13);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_YOUT);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_15);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_16);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_17);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_18);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_19);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_20);
	
	GPIO_EnableInt(PB,N_C_XZERO,GPIO_INT_BOTH_EDGE);
	GPIO_EnableInt(PB,N_C_YIN,GPIO_INT_BOTH_EDGE);
	GPIO_EnableInt(PB,N_C_YOUT,GPIO_INT_BOTH_EDGE);
	
	NVIC_EnableIRQ(GPB_IRQn);
}

//��ʼ��ȫ�ֱ���  ����һ��ʾ��
__STATIC_INLINE void Init_VAR(void) //��ʼ��ȫ�ֱ���
{
	// BUSY = 0;
	EMACTime = 0;
	UPTime = 0;
	InitTime = 0;
	tempUPTime = 0;
	g_u32TestCount = 0;
	
	g_sPaperINSensor = 0;
	g_sZeroMARK = 0;
	g_st_u32ReSendNotFirst = 0;
}

int main(void)
{
	uint32_t RxLen = 0;
	uint32_t CommID = 0; //����ID

	//ϵͳ��ʼ��	
	SYS_Init();

#if defined(DEBUG) || defined(DEBUG0)
	UART_Open(UART0, 115200);
#endif
	
	//�˿ڳ�ʼ��	
	IO_Init();
 //��ʼ��ȫ�ֱ���
	Init_VAR();
	//CLK_SysTickLongDelay(1000);
	//���ز���
	LoadConfig();
	tempUPTime = CONF.UPTime;
	//��ʼ������
  P_EMACRESET = 1;

	CLK_SysTickLongDelay(50000);
	CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);

	EMACINT = 0;
	EMACINTOO = 0;
	//����TIMER0�жϷ���
	TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 2);
	TIMER_EnableInt(TIMER0);
	NVIC_EnableIRQ(TMR0_IRQn);
	TIMER_Start(TIMER0);
	
	EMAC_Open(g_au8MacAddr);
	EMAC_EnableCamEntry(1, g_au8MacAddrArp);
	EMACINT = 1;
	EMACINTOO = 1;
	P_EMACRESET = 0;
	//CLK_SysTickLongDelay(1000);
	EMAC_DISABLE_RECV_BCASTPKT();
	EMAC_DISABLE_RECV_MCASTPKT();

	NVIC_EnableIRQ(EMAC_TX_IRQn);
	NVIC_EnableIRQ(EMAC_RX_IRQn);

	//CLK_SysTickLongDelay(1000);

	EMAC_ENABLE_RX();
	EMAC_ENABLE_TX();
	
	NVIC_EnableIRQ(EPWM1P0_IRQn);
	NVIC_EnableIRQ(EPWM1P1_IRQn);

	//P_EMACREST = 1;
	//CLK_SysTickLongDelay(50000);
	//P_EMACREST = 0;
	//CLK_SysTickLongDelay(50000);

	iMKJOutPutStatus(); //������״̬
	//NVIC_EnableIRQ(EMAC_RX_IRQn);
	//������ѭ��
	printf("--MKJ Main Is Running -0727 -01 --\n");//0618 -01 
	uint16_t u16InputM1RunFlag = 0;
	initQueue();
//=======================================================
	// ���� UART0 �ж�
	UART_Open(UART2, 115200);
  UART_EnableInt(UART2, (UART_INTEN_RDAIEN_Msk | UART_INTEN_RXTOIEN_Msk));
	NVIC_EnableIRQ(UART2_IRQn);
//=======================================================
	printf("Init Queue Finish\n");
	uint32_t u32XCurrOperator = 0;
	uint32_t u32XLastOperator = 0;
	uint32_t u32YCurrOperator = 0;
	uint32_t u32YLastOperator = 0;
	
	uint32_t u32CurrFeedOperator = 0;
	uint32_t u32LastFeedOperator = 0;
	
	uint32_t u32ScanCount = 0;
	
	uint16_t u16InitCorrectly = 0;
	uint16_t u16FlagBeforeScanFeeding = 0;
	//uint16_t u16PaperFinishCut = 0;
	
	uint32_t u32LastUploadNotFirstPacket = 0;
	
	uint32_t u32LastFarSensorState = 0;//ģ��һ��������
	//-----------------------------------------
	uint16_t u16Flag_Test = 0;
	//-----------------------------------------
	P_C_OUT_LED1 = 1; P_C_OUT_LED2 = 0; P_C_OUT_LED3 = 1;
	//-----------------------------------------
	while (1) { //��ѭ��
		do {
			RxLen = u32PktLen;
		  if (RxLen == 0)
				break;
			//   NVIC_DisableIRQ(EMAC_RX_IRQn);
			EMACTime = 0; //?���жϾ�֤������������
			memcpy(pRxBufByte, auNetPkt, UDPLength);
			RxLen = u32PktLen - UDPLength;
			if (RxLen != 0) {
				memcpy((void*)&RxBuf, auNetPkt + UDPLength, RxLen);
			}
			u32PktLen = 0;
			
		//ARP���� ��PC���ӱ���Ҫ
		if ((pRxBufByte[12] == 0x08) && (pRxBufByte[13] == 0x06)) {
			if (pRxBufByte[21] == 0x02) {
				g_au8YourMacAddr[0] = pRxBufByte[22];
				g_au8YourMacAddr[1] = pRxBufByte[23];
				g_au8YourMacAddr[2] = pRxBufByte[24];
				g_au8YourMacAddr[3] = pRxBufByte[25];
				g_au8YourMacAddr[4] = pRxBufByte[26];
				g_au8YourMacAddr[5] = pRxBufByte[27];
				g_au8YourMacAddr[0],
				g_au8YourMacAddr[1],
				g_au8YourMacAddr[2],
				g_au8YourMacAddr[3], 
				g_au8YourMacAddr[4], 
				g_au8YourMacAddr[5];
				tempUPTime = CONF.UPTime;
			} else if ((pRxBufByte[21] == 0x01) &&
					(pRxBufByte[38] == g_au8IpAddr[0]) &&
					(pRxBufByte[39] == g_au8IpAddr[1]) &&
					(pRxBufByte[40] == g_au8IpAddr[2]) &&
					(pRxBufByte[41] == g_au8IpAddr[3])) {
				g_au8YourMacAddr[0] = pRxBufByte[22];
				g_au8YourMacAddr[1] = pRxBufByte[23];
				g_au8YourMacAddr[2] = pRxBufByte[24];
				g_au8YourMacAddr[3] = pRxBufByte[25];
				g_au8YourMacAddr[4] = pRxBufByte[26];
				g_au8YourMacAddr[5] = pRxBufByte[27];				
				//g_au8YourMacAddr[0],
				//g_au8YourMacAddr[1],
				//g_au8YourMacAddr[2],
				//g_au8YourMacAddr[3], 
				//g_au8YourMacAddr[4], 
				//g_au8YourMacAddr[5];
				uint8_t auPkt[] = {
						YOURMAC,
						MYMAC ,
						0x08,0x06,
						0x00,0x01,
						0x08,0x00,
						0x06,0x04,
						0x00,0x02, //��Ӧ
						MYMAC,
						MYIP,
						YOURMAC,
						YOURIP,
				};
				EMAC_SendPkt(auPkt, sizeof(auPkt));
				tempUPTime = CONF.UPTime;
			}
				break;
		}
		//UDPЭ�� ����������Ӧ
		if ((pRxBufByte[0] ==  MYMAC0) &&
				(pRxBufByte[1] == MYMAC1) &&
				(pRxBufByte[2] == MYMAC2) &&
				(pRxBufByte[3] == MYMAC3) &&
				(pRxBufByte[4] == MYMAC4) &&
				(pRxBufByte[5] == g_au8MacAddr[5]) &&
				(pRxBufByte[23] == 0x11)) {
			CommID = theCmd;
			theCmd = 0; 
			switch (CommID) {
				case ID_MKJOutPutStatus: {
					MKJOutPutStatus();
				}
					break;
				case ID_MKJREAD_CONFIG: {
					MKJReadConfig();
				}
					break;
				case ID_MKJWRITE_CONFIG:{
					MKJWriteConfig();
				}
					break;
				case ID_MKJRESET_CONFIG:{
					MKJReSetConfig();
				}
					break;
				case ID_FOO: {
					foo();
				}
					break;
				case ID_BAR: {
					bar();
				}
					break;
				case ID_RUN_MACHINE_NO_MARK:{
					Recv_RUNMachine_NoMARK();
					//------------------------------------
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST_3__;
					g_u32FlagNoMarkRunState = __NO_MARK_FEED_PAPER__;
					g_u32ExpectPacketNumber = 1;
					g_u32RunFinishCount = 0;
					g_IM_u32XPeriodCount = 0;
					g_IM_u32YPeriodCount = 0;
					f_CalculateMMToPulse();
					//------------------------------------
				}
					break;				
				case ID_FIRST_PACKET:{
					Recv_FirstPacket();
					g_u32ExpectPacketNumber = 1;
					g_u32RunFinishCount = 0;
					g_IM_u32XPeriodCount = 0;
					g_IM_u32YPeriodCount = 0;
					g_u32PointFindXCount = 0;
					g_u32PointFindYCount = 0;
					P_C_OUTCAMERA = 0;
					P_C_INPUT_18 = 0;
					f_CalculateMMToPulse();
					g_u32FlagRunState = __FLAG_RUNSTATE_BEFORE_SCAN_MARK__;
					g_u32FlagBeforeSacnState = __FLAG_BEFORE_SCAN_STEP1__;
				}
					break;
				case ID_NO_FIRST_PACKET:{
					g_u32FlagRunState = __FLAG_RUNSTATE_BEGIN__;
					Recv_No_FirstPacket();
				}
					break;
				case ID_VOICECOIL_RUN :{
					Recv_VoiceCoil_Run();
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST__;
				}
					break;
				case ID_VOICECOIL_STOP:{
					Recv_VoiceCoil_Stop();
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST__;
				}
					break;
				case ID_TEST_M_RUN:{
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST__;
					Recv_Test_M_Run();
					printf("Recv ID_TEST_M_RUN\n");
				}
					break;
				case ID_TEST_M_STOP:{
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST__;
					Recv_Test_M_Stop();
				}
					break;
				case ID_TEST_SET_CAM_STATE:{
					Recv_Test_SetCameraState();
				}
					break;
				case ID_X_AXIS_PATROL:{
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST__;
					Recv_X_AXIS_Patrol();
				}
					break;
				case ID_TEST_READ_UART:{
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST_2__;					
					Send_ReadUART();
					P_C_OUT_LED1 = 0;
					P_C_OUT_LED2 = 0;
					P_C_OUT_LED3 = 0;
					uint8_t au8TestData[8] = {'A','B','C','D','E','F','G','H'};
				  uint32_t u32WriteCount = UART_Write(UART2,&au8TestData[0],8);
					printf("UART_Write:%u\n",u32WriteCount);
				}
					break;
				case ID_TEST_XIFENG:{
					Recv_Test_XiFeng();
				}
					break;
				case ID_TEST_VOICECOIL_PERIOD:{
					g_u32FlagRunState = __FLAG_RUNSTATE_TEST_4__;
					u16Flag_Test = 0;
					Recv_VoiceCoil_Period();
				}
				 break;
				default: {
					//printf("Recv Default\n");
				}	
					break;
			}
		}
		UPTime = 0;
		theCmd = 0;		
		//NVIC_EnableIRQ(EMAC_RX_IRQn);
		//BUSY = 0;
	} while (0);
	///////////////////
	//=============================================================��ʼ��
	if(g_u32FlagRunState == __FLAG_RUNSTATE_INIT__) {
		if(P_C_XZERO == __SENSOR_EXPOSURE__) {
			u32XCurrOperator = __X_MOTOR_RUN_ZERO__;
			//printf("Init\n");
		}
	} 
	//=============================================================��MARK��
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_BEFORE_SCAN_MARK__) {
		if(g_u32FlagBeforeSacnState == __FLAG_BEFORE_SCAN_STEP1__) {
			if(P_C_XZERO == __SENSOR_EXPOSURE__) {
				u32XCurrOperator = __X_MOTOR_RUN_ZERO__;
				printf("Xmark\n");
			} else {
				g_u32FlagBeforeSacnState = __FLAG_BEFORE_SCAN_STEP2__;
			}
		} else if(g_u32FlagBeforeSacnState == __FLAG_BEFORE_SCAN_STEP2__) {
			if(P_C_INPUT_4 == __SENSOR_EXPOSURE__) {
				g_u32FlagRunState = __FLAG_RUNSTATE_END__;
				// TODO:��ʼ��
				printf("No Paper\n");// �ϱ�ȱֽ
			} else {
				u32CurrFeedOperator = __FEED_SENDING__;//��ֽ
				g_u32FlagBeforeSacnState = __FLAG_BEFORE_SCAN_STEP3__;
				printf("__FLAG_BEFORE_SCAN_STEP3__\n");
			}
		} else if(g_u32FlagBeforeSacnState == __FLAG_BEFORE_SCAN_STEP3__) {
			if(g_sPaperINSensor == 1) {
				g_sPaperINSensor = 0;
				g_IM_u32YPeriodCount = 0;
				u32YCurrOperator = __Y_MOTOR_RUN_AHEAD__;
				u32YLastOperator = 0;
				//----------------------------------
				P_C_OUTFAN_1 = __XIFENG_OPEN__;
				P_C_OUTFAN_2 = __XIFENG_OPEN__;
				//----------------------------------
				g_u32FlagBeforeSacnState = __FLAG_BEFORE_SCAN_STEP4__;
				printf("__FLAG_BEFORE_SCAN_STEP4__\n");
			}
		} else if(g_u32FlagBeforeSacnState == __FLAG_BEFORE_SCAN_STEP4__) {
			if(g_sPaperOUTSensor == 1) {
				g_sPaperOUTSensor = 0;
				g_IM_u32YPeriodCount = g_u32FGRToOUTSENSOR;
				printf("g_sPaperOUTSensor == 1 %u---\n",g_IM_u32YPeriodCount);
				u32YCurrOperator = __Y_INTOOUT_MOVE_LENGTH__;
				u32YLastOperator = 0;
				u32CurrFeedOperator = __FEED_STOP__;
			}
			if(g_IM_u32YPeriodCount >= (g_u32LengthPulse-g_u32LB_YMargin)) { //TODO:��Ҫ��ȥ�ױ߾�
				printf("---%u--%u---\n",g_IM_u32YPeriodCount,g_u32LengthPulse);
				u32YCurrOperator = __Y_MOTOR_ARRIVED_STOP__;
				u32YLastOperator = 0;			
				g_u32FlagRunState = __FLAG_RUNSTATE_FINDXMARK__;
				g_u32FlagScanState = __FLAG_SCAN_X_MARK_STEP1__;
			}
		}
	}
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_FINDXMARK__) {
		if(g_sZeroMARK == 1) {
			g_sZeroMARK = 0;
			g_IM_u32XZero = g_IM_u32XPeriodCount;
			printf("Zero Point:%u\n",g_IM_u32XZero);
		}
		
		if(g_u32FlagScanState ==__FLAG_SCAN_X_MARK_STEP1__) {
			P_C_OUTCAMERA = 1;
			u32XCurrOperator = __X_ZEROTOFAR_MOVE_WIDTH__;
			printf("SCAN X STEP1\n");
			g_u32FlagScanState = __FLAG_SCAN_X_MARK_NULL__;
		} else if(g_u32FlagScanState == __FLAG_SCAN_X_MARK_STEP2__) {
			if(g_IM_u32XPeriodCount >= g_u32XMoveDistance) {
				P_C_OUTCAMERA = 1;
				CalCMRCNR_UpdateMotorSpeed(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz);
				printf("SCAN X STEP2\n");
				g_u32FlagScanState = __FLAG_SCAN_X_MARK_NULL__;
			}
		} else if(g_u32FlagScanState == __FLAG_SCAN_X_MARK_STEP3__) {
			if(g_IM_u32XPeriodCount >= g_u32XMoveDistance) {
				u32XCurrOperator = __X_MOTOR_CAR_STOP__;
				u32XLastOperator = 0;
				g_u32XMoveDistance = 0;
				printf("SCAN X STEP3\n");
				g_u32FlagRunState = __FLAG_RUNSTATE_FINDYMARK__;
				g_u32FlagScanState = __FLAG_SCAN_Y_MARK_STEP1__;
			}
		} else if(g_u32FlagScanState == __FLAG_SCAN_X_MARK_NULL__) {
		
		}
		
		if(P_C_OUTCAMERA == 1 && P_C_INPUT_18 == 1) {
			P_C_OUTCAMERA = 0;
			P_C_INPUT_18 = 0;
			g_u32PointFindXCount++;
			if(g_u32PointFindXCount == 1) {
				g_u32PointFindYCount++;
				g_IM_u32LBX = g_IM_u32XPeriodCount;
				g_u32XMoveDistance  = g_IM_u32XPeriodCount + CONF.XMarkDis;
				g_u32FlagScanState = __FLAG_SCAN_X_MARK_STEP2__;
				printf("X FIND Point 1 %u\n",g_IM_u32LBX);
				CalCMRCNR_UpdateMotorSpeed(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz*3);
			} else if(g_u32PointFindXCount == 2) {
				g_IM_u32RBX = g_IM_u32XPeriodCount;
				CalCMRCNR_UpdateMotorSpeed(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz*3);
				P_C_M1_DIR = 0;
				printf("X FIND Point 2 %u\n",g_IM_u32RBX);
				g_u32XMoveDistance = g_IM_u32RBX - g_IM_u32LBX;
				g_IM_u32XPeriodCount = 0;
				g_u32FlagScanState = __FLAG_SCAN_X_MARK_STEP3__;
			}
		}
	} 
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_FINDYMARK__) {
		if(g_u32FlagScanState ==__FLAG_SCAN_Y_MARK_STEP1__) {
			u32YCurrOperator = __Y_OUTTOIN_MOVE_LENGTH__;
			g_u32YMoveDistance = CONF.YMarkDis;
			g_u32FlagScanState = __FLAG_SCAN_Y_MARK_STEP2__;
		} else if(g_u32FlagScanState ==__FLAG_SCAN_Y_MARK_STEP2__) {
			if(g_IM_u32YPeriodCount >= g_u32YMoveDistance) {
				P_C_OUTCAMERA = 1;
				g_u32YMoveDistance = 0;
				g_u32FlagScanState = __FLAG_SCAN_Y_MARK_STEP3__;
			}
		}	else if(g_u32FlagScanState == __FLAG_SCAN_Y_MARK_STEP3__) {
			//--------------------�ж��Ƿ�ȱY��MARK��
			if(g_IM_u32YPeriodCount >= (g_u32LengthPulse)) {//TODO:��Ҫ����
				if(g_u32PointFindYCount < 2) {
					u32YCurrOperator = __Y_MOTOR_RUN_AHEAD__;
					u32YLastOperator = 0;
					g_u32FlagRunState = __FLAG_RUNSTATE_END__;
					printf("NOT FIND Y2 MARK POINT\n");
				}
			}
		} else if(g_u32FlagScanState == __FLAG_SCAN_Y_MARK_NULL__) {
			
		}
		if(P_C_OUTCAMERA == 1 && P_C_INPUT_18 == 1) {
			P_C_OUTCAMERA = 0;
			P_C_INPUT_18 = 0;
			g_u32PointFindYCount++;
			if(g_u32PointFindYCount == 2) {
				g_IM_u32LTY = g_IM_u32YPeriodCount;
				g_IM_u32YPeriodCount = 0;
				g_u32FlagRunState = __FLAG_RUNSTATE_RECVDATA__;
				g_st_u32ReSendNotFirst = 0;
				g_u32XMoveDistance = 0;
				g_u32YMoveDistance = 0;
				printf("Y FIND Point 2 %u\n",g_IM_u32LTY);
				u32YCurrOperator = __Y_MOTOR_CAR_STOP__;
				u32YLastOperator = 0;
				g_u32X_Axis_MoveState = __X_AXIS_MOVING__;
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVING__;
			}
		}	
	} 
	//=============================================================��������
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_RECVDATA__) {
		if((g_st_u32ReSendNotFirst % 5 ) == 0 && u32LastUploadNotFirstPacket != g_st_u32ReSendNotFirst) {
			u32LastUploadNotFirstPacket = g_st_u32ReSendNotFirst;
			Send_BeginNoFirst();
			printf("UPLOAD NOT FIRST:%u\n",g_st_u32ReSendNotFirst);
		}
		if(g_st_u32ReSendNotFirst >= 50) {
			g_st_u32ReSendNotFirst = 0;
			u32LastUploadNotFirstPacket = 0;
			g_u32FlagRunState = __FLAG_RUNSTATE_END__;
		}
	}
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_BEGIN__) {		
		if(g_u32FlagMoveState == __FLAG_MOVE_PU__) {
			if(g_IM_u32XPeriodCount >= g_u32XMoveDistance && g_u32X_Axis_MoveState == __X_AXIS_MOVING__) {
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);				
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				printf("PU g_IM_u32XPeriodCount:%u,g_u32XMoveDistance:%u\n",g_IM_u32XPeriodCount, g_u32XMoveDistance);
			}
			if(g_IM_u32YPeriodCount >= g_u32YMoveDistance && g_u32Y_Axis_MoveState == __Y_AXIS_MOVING__) {
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);	
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				printf("PU g_IM_u32YPeriodCount:%u,g_u32YMoveDistance:%u\n",g_IM_u32YPeriodCount, g_u32YMoveDistance);
			}
		} 
		else if(g_u32FlagMoveState == __FLAG_MOVE_PD__) {
			if(g_IM_u32XPeriodCount >= g_u32XMoveDistance && g_IM_u32YPeriodCount < g_u32YMoveDistance) {
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				uint32_t u32YError = g_u32YMoveDistance - g_IM_u32YPeriodCount;
				printf("X Arrive First,XDis:%u,XPeriod:%u,YDis:%u,YPeriod:%u,YError:%u\n",
											g_u32XMoveDistance,g_IM_u32XPeriodCount,g_u32YMoveDistance,g_IM_u32YPeriodCount,u32YError);
				if(u32YError >= __MAXIMUMIGNORED_ERROR__) {
					g_Y_MovingError = u32YError;
				} else {
					g_Y_MovingError = 0;
				}
				g_X_MovingError = 0;
			} else if(g_IM_u32XPeriodCount < g_u32XMoveDistance && g_IM_u32YPeriodCount >= g_u32YMoveDistance) {
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				uint32_t u32XError = g_u32XMoveDistance - g_IM_u32XPeriodCount;
				printf("Y Arrive First,XDis:%u,XPeriod:%u,YDis:%u,YPeriod:%u,XError:%u\n",
										g_u32XMoveDistance,g_IM_u32XPeriodCount,g_u32YMoveDistance,g_IM_u32YPeriodCount,u32XError);
				if(u32XError >= __MAXIMUMIGNORED_ERROR__) {
					g_X_MovingError = u32XError;
				} else {
					g_X_MovingError = 0;
				}
				g_Y_MovingError = 0;
			} else if(g_IM_u32XPeriodCount >= g_u32XMoveDistance && g_IM_u32YPeriodCount >= g_u32YMoveDistance) {
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				g_X_MovingError = 0;
				g_Y_MovingError = 0;
				printf("Both Arrive\n");
			}
		} 
		else if(g_u32FlagMoveState == __FLAG_MOVE_XMOTOR__) {
			if(g_IM_u32XPeriodCount >= g_u32XMoveDistance) {
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);	
				
				g_X_MovingError = 0;
				g_Y_MovingError = 0;
				printf("X Motor Arrive\n");
			}
		}
		else if(g_u32FlagMoveState == __FLAG_MOVE_YMOTOR__) {
			if(g_IM_u32YPeriodCount >= g_u32YMoveDistance) {
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);	
				
				g_X_MovingError = 0;
				g_Y_MovingError = 0;
				printf("Y Motor Arrive\n");
			}
		}	
		//=============================================================
		if(g_u32X_Axis_MoveState == __X_AXIS_MOVEDOME__ && g_u32Y_Axis_MoveState == __Y_AXIS_MOVEDOME__) {
			if(g_u32RunFinishCount == g_u32PLTCMDTotalCount) {
				printf("Finish Run\n");
				u32LastUploadNotFirstPacket = 0;
				f_VoiceCoil_DisEnable();// ֹͣ��Ȧ���
				PA2 = 0;
				PA3 = 0;
				//----------------------------------
				P_C_OUTFAN_1 = __XIFENG_CLOSE__;
				P_C_OUTFAN_2 = __XIFENG_CLOSE__;
				//----------------------------------
				f_WaitForNextBatchCMD();
				u32YCurrOperator = __Y_MOTOR_RUN_AHEAD__;
				u32YLastOperator = 0;
					
				u32XCurrOperator = __X_MOTOR_RUN_ZERO__;
				u32XLastOperator = 0;
				g_u32FlagRunState = __FLAG_RUNSTATE_END__;
			}			
			
			if(isQueueEmpty() != 0) {
				printf("isQueueEmpty != 0, nIndex:%u \n",g_u32RunFinishCount);
				g_u32RunFinishCount++;
				CMDToM stCmd = OutputQueue();
				X_Y_AXIS_Running(stCmd);
			}				
		}		
		if(g_u32FlagRecvState == __FLAG_RECV_WAIT__) { // ����ֹͣ����
			g_u32FlagRecvState = __FLAG_RECV_MID_WAIT__;
			printf("g_u32FlagRecvState == __FLAG_RECV_WAIT__\n");
			Send_Wait_Recv();
		} else if(g_u32FlagRecvState == __FLAG_RECV_CONTINUE__) { // ���ͼ�������
			g_u32FlagRecvState = __FLAG_RECV__MID_CONTINUE__;
			printf("g_u32FlagRecvState == __FLAG_RECV_CONTINUE__\n");
			Send_Continue_Recv();
		} else if(g_u32FlagRecvState == __FLAG_RECV_RESEDN__) { // ��Ҫ�ط�
			g_u32FlagRecvState = __FLAG_RECV_MID_RESEDN__;
			printf("g_u32FlagRecvState == __FLAG_RECV_RESEDN__\n");
			Send_ReSend_Recv();
		} else if(g_u32FlagRecvState == __FLAG_RECV_MID_WAIT__) {
			if(getQueueFreeSpace() == __ST_PLTCMD_LENGTH__/2) {
				g_u32FlagRecvState = __FLAG_RECV_CONTINUE__;
				printf("g_u32FlagRecvState == __FLAG_RECV_MID_WAIT__\n");
			}
		}		
	}
	//=============================================================
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_TEST__) {
		if(g_IM_u32XPeriodCount >= g_u32XMoveDistance && g_u32XMoveDistance != 0) {
			u32XCurrOperator = __X_MOTOR_ARRIVED_STOP__;
			u32XLastOperator = 0;
		}
		if(g_IM_u32YPeriodCount >= g_u32YMoveDistance && g_u32YMoveDistance != 0) {
			u32YCurrOperator = __Y_MOTOR_ARRIVED_STOP__;
			u32YLastOperator = 0;
		}
		
		if(P_C_OUTCAMERA == 1 && P_C_INPUT_18 == 1) {
			P_C_OUTCAMERA = 0;
			P_C_INPUT_18 = 0;
			u32XCurrOperator = __X_MOTOR_CAR_STOP__;
			u32XLastOperator = 0;
		}
	} 
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_TEST_2__) {
		if (g_u32RxIndex > 0) {
			// �������յ�������
			printf("Received Length:%u\n",g_u32RxIndex);
      for (uint32_t i = 0; i < g_u32RxIndex; i++) {
				printf("Received: %c\n", g_u8RxBuffer[i]);
			}
      g_u32RxIndex = 0; // ���ý��ջ���������
    }
	} 
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_TEST_3__) {
		if(g_u32FlagNoMarkRunState == __NO_MARK_FEED_PAPER__) {
			u32CurrFeedOperator = __FEED_SENDING__;//��ֽ
			g_u32FlagNoMarkRunState = __NO_MARK_Y_MOTOR_AHEAD__;
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_Y_MOTOR_AHEAD__) {
			if(g_sPaperINSensor == 1) {
				g_sPaperINSensor = 0;
				g_IM_u32YPeriodCount = 0;
				u32YCurrOperator = __Y_MOTOR_RUN_AHEAD__;
				u32YLastOperator = 0;
				//----------------------------------
				P_C_OUTFAN_1 = __XIFENG_OPEN__;
				P_C_OUTFAN_2 = __XIFENG_OPEN__;
				//----------------------------------
				g_u32FlagNoMarkRunState = __NO_MARK_X_RUN_MARK1__;
				printf("__NO_MARK_Y_MOTOR_AHEAD__\n");
			}
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_X_RUN_MARK1__) {
			if(g_sPaperOUTSensor == 1) {
				g_sPaperOUTSensor = 0;
				g_IM_u32YPeriodCount = g_InPutToScanMark + g_OutPutToScanMark;
				printf("g_sPaperOUTSensor == 1 %u---\n",g_IM_u32YPeriodCount);
				u32YCurrOperator = __Y_INTOOUT_MOVE_LENGTH__;
				u32YLastOperator = 0;
				u32CurrFeedOperator = __FEED_STOP__;
			}
			if(g_IM_u32YPeriodCount >= (g_u32LengthPulse + g_InPutToScanMark - g_u32LB_YMargin - 2800)) {
				u32YCurrOperator = __Y_MOTOR_ARRIVED_STOP__;
				u32YLastOperator = 0;		
				g_u32FlagNoMarkRunState	= __NO_MARK_X_SCAN_MARK_BEGIN__;
			}
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_X_SCAN_MARK_BEGIN__) {
			//P_C_OUTCAMERA = 1;
			u32XCurrOperator = __X_ZEROTOFAR_MOVE_WIDTH__;
			g_IM_u32XPeriodCount = 0;
			g_u32FlagNoMarkRunState = __NO_MARK_X_SCAN_MARK_MID__;
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_X_SCAN_MARK_MID__) {
			if(g_sZeroMARK == 1) {
				g_sZeroMARK = 0;
				g_IM_u32XZero = g_IM_u32XPeriodCount;
				printf("Zero Point:%u\n",g_IM_u32XZero);
			}
			if(g_IM_u32XPeriodCount >= (g_u32WidthPulse + ((g_u32MachineWidth - g_u32WidthPulse)/2))) {
				printf("__NO_MARK_X_SCAN_MARK_MID__,%u\n",g_IM_u32XPeriodCount);
				g_IM_u32XPeriodCount = 0;
				u32XCurrOperator = __X_FARTOZERO_MOVE_WIDTH__;
				g_u32FlagNoMarkRunState = __NO_MARK_X_SCAN_MARK_END__;
			}
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_X_SCAN_MARK_END__) {
			if(g_IM_u32XPeriodCount >= (g_u32WidthPulse)) {
				g_IM_u32XPeriodCount = 0;
				g_IM_u32YPeriodCount = 0;
				u32XCurrOperator = __X_MOTOR_CAR_STOP__;
				u32YCurrOperator = __Y_OUTTOIN_MOVE_LENGTH__;
				g_u32FlagNoMarkRunState = __NO_MARK_Y_MOTOR_BACK__;
				printf("__NO_MARK_X_SCAN_MARK_END__\n");
			}
		} else if(g_u32FlagNoMarkRunState == __NO_MARK_Y_MOTOR_BACK__) {
			if(g_IM_u32YPeriodCount >= (g_u32LengthPulse - g_u32LT_YMargin - g_u32LB_YMargin)) {
				u32YCurrOperator = __Y_MOTOR_CAR_STOP__;
				u32YLastOperator = 0;
				g_u32X_Axis_MoveState = __X_AXIS_MOVEDOME__;
				g_u32Y_Axis_MoveState = __Y_AXIS_MOVEDOME__;
				g_st_u32ReSendNotFirst = 0; 
				g_u32FlagRunState = __FLAG_RUNSTATE_RECVDATA__;
				printf("__NO_MARK_Y_MOTOR_BACK__\n");
			}
		}
	} 
	else if(g_u32FlagRunState == __FLAG_RUNSTATE_TEST_4__) {
		if(g_u32VoiceCoil_IM_RunCount <= g_u32VoiceCoil_IM_PeriodCount) {
			/*if(u16Flag_Test == 0) {
				u16Flag_Test = 1;
				g_u32TestCount = 0;
			}
			
			if(g_u32TestCount >= 50 && u16Flag_Test == 1) {
				u16Flag_Test = 2;
				EPWM_Stop(EPWM0,EPWM_CH_2_MASK);
				EPWM_ForceStop(EPWM0,EPWM_CH_2_MASK);
				EPWM_DisableOutput(EPWM0,EPWM_CH_2_MASK);
				
				EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
				EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
				EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
		
				f_VoiceCoil_DisEnable();
				PA2 = 0;
				PA3 = 0;
			}	*/
			if(u16Flag_Test == 0) {
				u16Flag_Test = 1;
				EPWM_Stop(EPWM0,EPWM_CH_2_MASK);
				EPWM_ForceStop(EPWM0,EPWM_CH_2_MASK);
				EPWM_DisableOutput(EPWM0,EPWM_CH_2_MASK);
				
				EPWM_Stop(EPWM0,EPWM_CH_3_MASK);
				EPWM_ForceStop(EPWM0,EPWM_CH_3_MASK);
				EPWM_DisableOutput(EPWM0,EPWM_CH_3_MASK);
		
				f_VoiceCoil_DisEnable();
				PA2 = 0;
				PA3 = 0;
			}
		}		
	}
	//=============================================================
	if(g_u32StopFarToZero == 1) {
		if(g_u32FlagZeroStop == __ZERO_SENSOR_NULL__) {
			g_u32FlagZeroStop = __ZERO_SENSOR_DETECTED__;
		}
		if(g_u32FlagZeroStop == __ZERO_SENSOR_DETECTED__) {
			g_u32FlagZeroStop = __ZERO_SENSOR_STOP__;
			u32XCurrOperator = __X_ZERO_RUN_AND_STOP__;
			g_u32ZeroStop_IM_PeriodCount = 0;
			printf("Clear INC1 \n");
		} else if(g_u32FlagZeroStop == __ZERO_SENSOR_STOP__){
			if(g_u32ZeroStop_IM_PeriodCount >= 1200) {
				g_u32StopFarToZero = 0;
				printf("Zero INC \n");
				//f_XMotor_Stop();
				u32XCurrOperator = __X_MOTOT_ZERO_STOP__;
				u32XLastOperator = 0;	
				g_u32FlagZeroStop = __ZERO_SENSOR_NULL__;
			}
		}
	}
	
	if(P_C_XFAR == __SENSOR_OCCLUSION__ && u32LastFarSensorState  == __SENSOR_EXPOSURE__) {
		u32LastFarSensorState = __SENSOR_OCCLUSION__;
		//f_XMotor_Stop();
		u32XCurrOperator = __X_MOTOR_FAR_STOP__;
		u32XLastOperator = 0;
	} else {
		u32LastFarSensorState = P_C_XFAR;
	}
	
	if(g_sPaperOUTSensor == 2) {
		g_sPaperOUTSensor = 0;
		if(g_u32FlagRunState == __FLAG_RUNSTATE_FINDXMARK__
				|| g_u32FlagRunState == __FLAG_RUNSTATE_FINDYMARK__
				|| g_u32FlagRunState== __FLAG_RUNSTATE_BEGIN__
				|| g_u32FlagRunState == __FLAG_RUNSTATE_TEST_3__) {
		
		} else {
			u32YCurrOperator = __Y_PAPER_FEEDOUT_STOP__;
			u32YLastOperator = 0;
		}	
	} 
	/*
	else if(g_sPaperOUTSensor == 2) {
		u32YCurrOperator = __Y_PAPER_FEEDOUT_STOP__;
		u32YLastOperator = 0;
	}
	*/
	//=============================================================
	if(u32XCurrOperator != 0 && u32XCurrOperator != u32XLastOperator) {
		printf("XCurrOperator:%u\n",u32XCurrOperator);
		switch (u32XCurrOperator)
    {
    	case __X_MOTOT_ZERO_STOP__:	{
				P_C_M1_EN = 0;
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
			}
    		break;
			case __X_MOTOR_RUN_ZERO__:{
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);			
				P_C_M1_EN = 1;
				P_C_M1_DIR = __X_MOTOR_MOVE_TO_ZERO__;
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
			}
 				break;
			case __X_MOTOR_FAR_STOP__:{
				if(g_u32FlagRunState == __FLAG_RUNSTATE_FINDXMARK__) {
					if(g_u32PointFindXCount < 2) {
						printf("NOT FIND X%u MARK POINT\n",g_u32PointFindXCount+1);
						g_u32FlagRunState = __FLAG_RUNSTATE_END__;
						u32YCurrOperator = __Y_MOTOR_RUN_AHEAD__;
						u32YLastOperator = 0;
					}
				}
				P_C_M1_EN = 0;
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
			case __X_ZEROTOFAR_MOVE_WIDTH__:{
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);			
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);
				P_C_M1_EN = 1;
				P_C_M1_DIR = __X_MOTOR_MOVE_TO_FAR__;
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
			case __X_FARTOZERO_MOVE_WIDTH__:{
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);			
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);
				P_C_M1_EN = 1;
				P_C_M1_DIR = __X_MOTOR_MOVE_TO_ZERO__;
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
			case __X_MOTOR_ARRIVED_STOP__: {
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				g_IM_u32XPeriodCount = 0;
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
			case __X_MOTOR_CAR_STOP__ :{
				P_C_M1_EN = 0;
				EPWM_DisablePeriodInt(C_M1_PWM,C_M1_PUL);
				
				EPWM_Stop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_ForceStop(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_DisableOutput(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
			case __X_ZERO_RUN_AND_STOP__:{
				EPWM_ConfigOutputChannel(C_M1_PWM,C_M1_PUL,CONF.XAxisFhz,50);
				EPWM_EnableOutput(C_M1_PWM,C_M1_PUL_MASK);
				EPWM_EnablePeriodInt(C_M1_PWM,C_M1_PUL,0);				
				P_C_M1_EN = 1;
				P_C_M1_DIR = __X_MOTOR_MOVE_TO_ZERO__;
				EPWM_Start(C_M1_PWM,C_M1_PUL_MASK);
			}
				break;
    	default:
    		break;
    }
		u32XLastOperator = u32XCurrOperator;
		u32XCurrOperator = 0;
	}
	//=============================================================
	if(u32YCurrOperator != 0 && u32YCurrOperator != u32YLastOperator) {
		printf("YCurrOperator:%u\n",u32YCurrOperator);
		switch (u32YCurrOperator)
    {
    	case __Y_MOTOR_RUN_AHEAD__: {
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,CONF.YAxisFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);				
				P_C_M3_EN = 1;
				P_C_M3_DIR = __Y_MOTOR_MOVE_TO_OUT__;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
			}
    		break;
			case __Y_MOTOR_RUN_BACK__: {
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,CONF.YAxisFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);				
				P_C_M3_EN = 1;
				P_C_M3_DIR = __Y_MOTOR_MOVE_TO_IN__;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
			case __Y_INTOOUT_MOVE_LENGTH__: {
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,CONF.YAxisFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);				
				EPWM_EnablePeriodInt(C_M3_PWM,C_M3_PUL,0);		
				P_C_M3_EN = 1;
				P_C_M3_DIR = __Y_MOTOR_MOVE_TO_OUT__;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
			case __Y_MOTOR_ARRIVED_STOP__:{
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				g_IM_u32YPeriodCount = 0;
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
			case __Y_OUTTOIN_MOVE_LENGTH__:{
				EPWM_ConfigOutputChannel(C_M3_PWM,C_M3_PUL,CONF.YAxisFhz,50);
				EPWM_EnableOutput(C_M3_PWM,C_M3_PUL_MASK);		
				EPWM_EnablePeriodInt(C_M3_PWM,C_M3_PUL,0);			
				P_C_M3_EN = 1;
				P_C_M3_DIR = __Y_MOTOR_MOVE_TO_IN__;
				EPWM_Start(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
			case __Y_MOTOR_CAR_STOP__:{
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				g_IM_u32YPeriodCount = 0;
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
			case __Y_PAPER_FEEDOUT_STOP__:{
				P_C_M3_EN = 0;
				EPWM_DisablePeriodInt(C_M3_PWM,C_M3_PUL);
				g_IM_u32YPeriodCount = 0;
				EPWM_Stop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_ForceStop(C_M3_PWM,C_M3_PUL_MASK);
				EPWM_DisableOutput(C_M3_PWM,C_M3_PUL_MASK);
			}
				break;
    	default:
    		break;
    }
		u32YLastOperator = u32YCurrOperator;
		u32YCurrOperator = 0;
	}
	//=============================================================
	if(u32CurrFeedOperator != 0 && u32CurrFeedOperator != u32LastFeedOperator) {
		printf("u32CurrFeedOperator:%u\n",u32CurrFeedOperator);
		switch (u32CurrFeedOperator)
    {
    	case __FEED_SENDING__: {
				EPWM_ConfigOutputChannel(C_M4_PWM,C_M4_PUL,CONF.FeedingFhz,50);
				EPWM_EnableOutput(C_M4_PWM,C_M4_PUL_MASK);
				P_C_M4_EN = 1;
				P_C_M4_DIR = 1;
				EPWM_Start(C_M4_PWM,C_M4_PUL_MASK);
				P_C_OUT_LED1 = 0; P_C_OUT_LED2 = 1; P_C_OUT_LED3 = 1;
			}	
    		break;
    	case __FEED_STOP__: {
				EPWM_Stop(C_M4_PWM,C_M4_PUL_MASK);
				EPWM_ForceStop(C_M4_PWM,C_M4_PUL_MASK);
				EPWM_DisableOutput(C_M4_PWM,C_M4_PUL_MASK);
			}
    		break;
    	default:
    		break;
    }		
		u32LastFeedOperator = u32CurrFeedOperator;
		u32CurrFeedOperator = 0;
	}
	
	
	if (UPTime > tempUPTime) {//ע�⣺�ڶ�ʱ������printf�������>10����		
			UPTime = 0;
			if ((g_au8YourMacAddr[0] == 0xFF)
				&& (g_au8YourMacAddr[1] == 0xFF)
				&& (g_au8YourMacAddr[2] == 0xFF)
				&& (g_au8YourMacAddr[3] == 0xFF)
				&& (g_au8YourMacAddr[4] == 0xFF)
				&& (g_au8YourMacAddr[5] == 0xFF)) {
				//�ϴ�ʱ�䵽  ARP ���� % d... % d...\r\n), CONF.UPTime, CONF.EMACTime);
				iMKJOutPutStatus();
				tempUPTime = CONF.UPTime;
			}else {
				MKJOutPutStatus();//������״̬
				tempUPTime = CONF.UPTime;
			}
		}
	} //while(1){//��ѭ��
	return 0;
}
