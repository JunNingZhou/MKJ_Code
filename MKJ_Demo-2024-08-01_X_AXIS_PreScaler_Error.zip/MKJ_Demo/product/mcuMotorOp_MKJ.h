#ifndef _MCUMOTOROP_MKJ_H_
#define _MCUMOTOROP_MKJ_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_math.h>

#define __X_AXIS_STEP_ANGLE__		18
#define __Y_AXIS_STEP_ANGLE__		18
#define __X_AXIS_SUBDIVISION__	6400
#define __Y_AXIS_SUBDIVISION__	6400
#define __X_AXIS_MOTOR_RATIO__	40
#define __Y_AXIS_MOTOR_RATIO__	40
#define __X_AXIS_SHAFT_LENGTH__	20000 //mm
#define __Y_AXIS_SHAFT_LENGTH__	20000

//--------------------------------------------
#define __X_MOTOR_MOVE_TO_ZERO__ 	0
#define __X_MOTOR_MOVE_TO_FAR__		1
//--------------------------------------------
#define __Y_MOTOR_MOVE_TO_IN__ 		0
#define __Y_MOTOR_MOVE_TO_OUT__ 	1
//--------------------------------------------
//extern uint32_t g_u32StopZeroToFar;
extern uint32_t g_u32StopFarToZero;
//--------------------------------------------
extern uint32_t g_u32MKJWidthPulse;
extern uint32_t g_u32WidthPulse;
extern uint32_t g_u32LengthPulse;

extern uint32_t g_u32LB_XMargin; // ҳ�߾�
extern uint32_t g_u32LB_YMargin;

extern uint32_t g_u32LT_XMargin;
extern uint32_t g_u32LT_YMargin;

extern uint32_t g_u32RT_XMargin;
extern uint32_t g_u32RT_YMargin;

extern uint32_t g_InPutToScanMark;
extern uint32_t g_OutPutToScanMark;

extern uint32_t g_u32MachineWidth; // ��������
//--------------------------------------------
extern uint32_t g_IM_u32XZero;
extern uint32_t g_IM_u32YZero;

extern uint32_t g_IM_u32LBX;
extern uint32_t g_IM_u32RBX;
extern uint32_t g_IM_u32LTY;

extern uint32_t g_IM_u32XPeriodCount;
extern uint32_t g_IM_u32YPeriodCount;
//--------------------------------------------
extern uint32_t g_X_MovingError;
extern uint32_t g_Y_MovingError;

//extern uint32_t g_IM_u32XCMR;
//extern uint32_t g_IM_u32XCNR;

//extern uint32_t g_IM_u32YCMR;
//extern uint32_t g_IM_u32YCNR;
//--------------------------------------------
extern float64_t g_f_EachXStepUm;
extern float64_t g_f_EachYStepUm;
extern uint32_t g_u32XMoveDistance;
extern uint32_t g_u32YMoveDistance;
//--------------------------------------------
extern uint32_t g_u32LastVoiceEN;

extern uint32_t g_u32LastXCNR;
extern uint32_t g_u32LastXCMR;
extern uint32_t g_u32LastXPreScaler;
extern uint32_t g_u32LastYCNR;
extern uint32_t g_u32LastYCMR;
extern uint32_t g_u32LastYPreScaler;
//--------------------------------------------
#define __VOICE_MOTOR_CARVE__	1
#define __VOICE_MOTOR_PRESS__	2
#define __VOICE_MOTOR_BOTH__	3
extern uint32_t g_u32VoiceOpMode;
//--------------------------------------------
extern void f_CalculateMMToPulse(void);
extern void f_WaitForNextBatchCMD(void);

extern void f_XAxis_MotorStop_WithAccInt(void);
extern void f_YAxis_MotorStop_WithAccInt(void);
//--------------------------------------------
extern uint32_t g_u32VoiceCoil_IM_RunCount;
extern uint32_t g_u32VoiceCoil_IM_PeriodCount;
//--------------------------------------------
extern void f_VoiceCoil_Enable(void);
extern void f_VoiceCoil_DisEnable(void);
//--------------------------------------------
#define __MAXIMUMIGNORED_ERROR__	50

#endif
