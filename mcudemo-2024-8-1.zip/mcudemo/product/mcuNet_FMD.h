#ifndef  _MCU_NET_H_
#define  _MCU_NET_H_

#include <stdint.h>

//UDP commondID对应的函数

//extern uint32_t 
extern uint32_t iFMDOutPutStatus(void) ;//通知上位机将要复位
extern uint32_t FMDOutPutStatus(void);
extern uint32_t FMDReadMessage(void);
extern uint32_t FMDReadConfig(void);
extern uint32_t FMDReSetConfig(void);
extern uint32_t FMDWriteConfig(void);
extern uint32_t FMDEnterTestMode(void);
extern uint32_t FMDExitTestMode(void);
extern uint32_t foo(void) ;
extern uint32_t bar(void) ;

extern uint32_t Motor1_Run(void);
extern uint32_t Motor1_Stop(void);
extern uint32_t Motor2_Run(void);
extern uint32_t Motor2_Stop(void);
extern uint32_t Motor3_Run(void);
extern uint32_t Motor3_Stop(void);
extern uint32_t Motor4_Run(void);
extern uint32_t Motor4_Stop(void);
extern uint32_t Motor5_Run(void);
extern uint32_t Motor5_Stop(void);
extern uint32_t Motor6_Run(void);
extern uint32_t Motor6_Stop(void);
extern uint32_t Motor7_Run(void);
extern uint32_t Motor7_Stop(void);
extern uint32_t Motor8_Run(void);
extern uint32_t Motor8_Stop(void);

extern uint32_t QEI0_Start(void);
extern uint32_t QEI0_Stop(void);
extern uint32_t QEI1_Start(void);
extern uint32_t QEI1_Stop(void);
//-------------------------------------------------
extern uint32_t SetSolenoidValue(void);
//-------------------------------------------------
extern uint32_t OUTPUT_UpdateState(void);
extern uint32_t MACHINE_UpdateFHz(void);
extern uint32_t MACHINE_UpdateDia(void);

extern uint32_t Before_Begin_Working(void);
extern uint32_t Beging_Working(void);
extern uint32_t Finish_Working(void);

extern uint32_t HeatLaminationRoll(void);
extern uint32_t FeiDaMotor_UpdateFHz(void);
extern uint32_t FMDUploadAlarm(void);
//-------------------------------------------------
extern uint32_t TestHeatDuty(void);
extern uint32_t TestSheetPaper(void);
//-------------------------------------------------测试飞达
extern uint32_t TestFeiDaFhzWithMotor2(void);
extern uint32_t TestBrokenFhzWithMotot1(void);
//-------------------------------------------------
extern uint32_t UploadStateNow(uint32_t uiStateID);
extern uint32_t UploadStateNow_WithOneParam(uint32_t stateID, uint32_t param1);
extern uint32_t UploadStateNow_WithTwoParam(uint32_t stateID, uint32_t param1, uint32_t param2);
extern uint32_t UploadStateNowAndNetOperatot(uint32_t uiStateID, uint32_t nextCmdID);
//-------------------------------------------------
extern uint32_t UpLoadAlignBlockSolenoidState(uint32_t FeederState, uint32_t AlignState, uint32_t EnCodedrCount);


#endif

