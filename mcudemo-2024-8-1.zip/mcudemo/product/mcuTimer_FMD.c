#include "NuMicro.h"

#include <stdio.h>
#include <string.h>

/*
void TMR1_IRQHandler(void)
{

	TIMER_ClearIntFlag(TIMER1);
}
*/

