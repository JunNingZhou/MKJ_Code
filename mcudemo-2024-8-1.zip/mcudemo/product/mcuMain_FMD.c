#include "NuMicro.h"
#include <stdio.h>

#include <arm_math.h>

#include "mcuID_FMD.h"
#include "mcuCmd_FMD.h"
#include "mcuNet_FMD.h"
#include "mcuNet_FMD_Addr.h"
#include "mcu_DataStruct.h"
#include "mcuTemperature_FMD.h"
#include "mcuOtherOperator_FMD.h"


volatile int g_iSchema = SCHEMA_TESTMODE;//ZHOU:������Ϊ����ģʽ  ��Ҫ�޸ĵ�

volatile int g_iSignalOper = 0;

static volatile uint32_t InitTime = 0; //����ʱ��ʱ��ʼ��

static volatile uint32_t EMACTime = 0;//MAC

static volatile uint32_t EADCTime = 0;

static volatile uint32_t UPTime = 0;//�ϱ�

static volatile uint32_t tempUPTime = 0;//

static volatile uint32_t BEEPTime = 0; //����

static volatile uint32_t CUTRUNTime = 0;//��ֽ�������ʱ��

static volatile uint32_t OUTPUTTime = 0;//��ֽ��������⵽��ʱ��

static volatile uint32_t SOLENOID2Time = 0;//�¹���ŷ���ͣ�������ʱ��

static volatile uint32_t HEATTime = 0; //����ʱ��

static volatile uint32_t PlateRiseTime = 0;//������ֽ��������ʱ��

static volatile uint32_t FeiDaBackTime = 0;
//-------------------------------------------------TMR1
static volatile uint32_t InPutPaperDithering = 0;
//-------------------------------------------------

uint32_t g_u32FlagIsHeating = 1;
//-----------------------------------��һ����
uint32_t g_LastPaperLength = 0;
uint32_t g_LastPaperLengthPulse = 0;
uint32_t g_LastOverlapLength = 0;
uint32_t g_LastOverlapLengthPulse = 0;

uint32_t g_LastBatchCount = 0;
uint32_t g_FirstPaperHeaderQEI = 0;
static uint8_t stuiFlagQEIOVUNF = 0;
//-----------------------------------�ɴ���������������
uint32_t g_FeiDaMotorForwardPulse = 0;
//-----------------------------------��������ֵ�ߵĳ���
float64_t g_f64EachPulseDis = 1.00;
//-----------------------------------
volatile uint32_t QEIValueIndex_NextPaper =0;
volatile uint32_t QEIValueIndex_OverLap = 0;
volatile uint32_t QEIValueIndex_CutPaperPlace = 0;
volatile uint32_t PaperQEI[9][4] = {{0,0,0,0}};

volatile uint32_t QEIRecordValue = 0x1000;

//-----------------------------------
volatile uint32_t BrokenPaperQEI[__BROKEN_PAPER_QEI_MAX_COUNT__] = {0,0,0,0,0,0};//��ֽ�������ʱ��
volatile uint32_t QEIValueIndex_BrokenPaper = 0;
volatile uint32_t g_u32BrokenPaperLength = 0;
float64_t g_f64BrokenLengthPath = 0.600;
volatile uint32_t g_u32BrokenPaperStoreIndex = 0; 
//-----------------------------------

volatile uint32_t g_PaperLengthToPulse = 0;
volatile uint32_t g_OverlapLengthToPulse = 0;
volatile uint32_t g_AlignUpLengthToPulse = 0;


volatile uint32_t g_CalculatePaperCount = 0;//ֽ����
uint32_t g_OneCycleTotalPaperCount = 0;

uint32_t g_InSensorToHitDotPulse = 0;
uint32_t g_HitDotToCutPaperPulse = 0;
uint32_t g_CutPaperToOutSensorPulse = 0;
uint32_t g_AlignSolenoidToInSensorPulse = 0;
uint32_t g_OneCyclePulse = 0;
//=================================================
uint32_t g_AlignSolenoidToCutPaperPulse = 0;
//=================================================

static volatile uint32_t PaperOutputSensor = 0;
static volatile uint32_t PaperOutputSensorCurrPulse = 0;//��ֽ������������ʱ��¼��������
static volatile uint32_t PaperBrolenMotorStop = 0;//��ֽ���(���1)ֹͣ
//-----------------------------------�ɴ�������
static volatile uint32_t PaperSendBackSensor = 0;	// �ɴ����ĺ���
static volatile uint32_t PaperSendStop = 0; // �ɴ�ֹͣ
//----------------------------------- ���ȵ�����¶�
uint32_t g_MaxHeatLaminatingTemperature = 0;
//-----------------------------------//����
volatile uint32_t g_AlarmCode = 0;
//-------------------------------------------------

static uint8_t g_au8MacAddr[6] = { MYMAC0,MYMAC1,MYMAC2,MYMAC3,MYMAC4,MYMAC5};

static uint8_t g_au8IpAddr[4] = { MYIP0,MYIP1,MYIP2,MYIP3 };

static  uint8_t g_au8MacAddrArp[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

volatile uint8_t g_au8YourMacAddr[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

uint32_t RxBuf[1514] = { 0 };

static uint8_t pRxBufByte[UDPLength] = { 0 };

static uint8_t auNetPkt[1514] = { 0 };

static uint32_t volatile u32PktLen = 0;
//----------------------------------------------
uint16_t g_u16FlagFocusFeederSensor = 0;
uint32_t g_u32Initial_ValueRecord = 0;

static uint16_t stIsBeginFirstPaper = 0;
uint16_t g_u16FlagPaperOnPlatForm = 0;
//-----------------------------------
uint32_t g_u32_Sheet_Record_LastStopQEI = 0; // ��¼������һ��ֹͣ��QEI
uint32_t g_u32_Sheet_Record_DeviationQEI = 0; // ��¼ƫ��
//----------------------------------------------

void EMAC_TX_IRQHandler(void)
{
	// Log(BN(EMAC_TX_IRQHandler));
	// printf("EMAC_TX_Handle\n");
	EMAC_SendPktDone();
}

void EMAC_RX_IRQHandler(void)
{
	//	uint32_t i = 0;
	//	Log(BN(EMAC_RX_IRQHandler));
	//	EMACTime = 0; //?���жϾ�֤������������
	//	printf("EMAC_RX_Handler\n");
	while (1) {
		if (EMAC_RecvPkt(auNetPkt, (uint32_t*)&u32PktLen) == 0)
			break;
		//	Log(BN(�յ�����,���� %d \r\n),u32PktLen);
		//	EMACTime = 0; //?��Ҫ�յ����ݲ��㣿
		EMAC_RecvPktDone();
	}
}

static int EMACINT = 0;
static int EMACINTOO = 0;
void TMR0_IRQHandler(void)
{
	EMACTime++;
	UPTime++;
	InitTime++;
	EADCTime++;
	CUTRUNTime++;
	SOLENOID2Time++;
	HEATTime++;
	PlateRiseTime++;
	OUTPUTTime++;
	FeiDaBackTime++;
	if (EMACINT == 0) {
		EMACINTOO ^= 1;
		if (EMACINTOO) {
			//printf("�������� !\r\n");
			P_C_RMII_RESET = 1;
		}
		else {
			//printf("�������� !\r\n");
			P_C_RMII_RESET = 0;
		}
	}
	//OK	Log(BN(��ѭ������ʱ�䵽...));
	TIMER_ClearIntFlag(TIMER0);
}
void TMR1_IRQHandler(void) 
{
	InPutPaperDithering++;
	TIMER_ClearIntFlag(TIMER1);
}
//--------------------------------------------------------GPIO�ж�
void GPA_IRQHandler(void) {
	if(GPIO_GET_INT_FLAG(PA,B_C_INPUT_11)){//��ֽ������	
		if(P_C_INPUT_11 == 1) { //������	��ֽ������б�־λ
			PaperBrolenMotorStop = 1;
			if(g_iSchema == SCHEMA_TESTMODE) {
				//QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
				//uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
				//UploadStateNow_WithOneParam(ID_PAPERBROKENINPUT0TO1,uiQEI0);
			}
		} else if(P_C_INPUT_11 == 0) { //�½���		��ֽ���ֹͣ
			//PaperBrolenMotorStop = 1;
			if(g_iSchema == SCHEMA_TESTMODE) {
				//QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
				//uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
				//UploadStateNow_WithOneParam(ID_PAPERBROKENINPUT1TO0,uiQEI0);
			}
		}
		GPIO_CLR_INT_FLAG(PA, B_C_INPUT_11);
	}
}

void GPB_IRQHandler(void) {
	if(GPIO_GET_INT_FLAG(PB,B_C_INPUT_3)){//��ֽ������
		PaperOutputSensor = 1;
		QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
		PaperOutputSensorCurrPulse = QEI_GET_HOLD_VALUE(QEI0);
		GPIO_CLR_INT_FLAG(PB, B_C_INPUT_3);				
	}
}

void GPC_IRQHandler(void){
	if(GPIO_GET_INT_FLAG(PC, B_C_INPUT_5)) {//�ɴ����ϵ���ֽ������
		if(P_C_INPUT_5 == 0) {
			//1 -- 0 �½���	-- ��������
			PaperSendStop = 1;
			if(g_iSchema == SCHEMA_TESTMODE) {
				//QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
				//uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
				//UploadStateNow_WithOneParam(ID_FEIDAINPUT1TO0,uiQEI0);
			}
		} else if(P_C_INPUT_5 == 1) {
			// 0 -- 1 ������  --��������
			PaperSendBackSensor = 1;
			FeiDaBackTime = 0;
			if(g_iSchema == SCHEMA_TESTMODE) {
				//QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
				//uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
				//UploadStateNow_WithOneParam(ID_FEIDAINPUT0TO1,uiQEI0);
			}
		}
		GPIO_CLR_INT_FLAG(PC, B_C_INPUT_5);		
	} 
}
//-------------------------------------------------------- QEI�ж�
void QEI0_IRQHandler(void)
{
		if(QEI_GET_INT_FLAG(QEI0, QEI_STATUS_OVUNF_Msk)) {
			if(g_CalculatePaperCount == 0) {
				QEI_SET_CNT_VALUE(QEI0,0);
			} 
			stuiFlagQEIOVUNF = 1;
			if(g_iSchema == SCHEMA_TESTMODE) {
				UploadStateNow_WithOneParam(ID_QEIOVUNIEN,g_CalculatePaperCount);
			}
			QEI_CLR_INT_FLAG(QEI0, QEI_STATUS_OVUNF_Msk);
		}
}
//--------------------------------------------------------
void SYS_Init(void)
{
	SYS_UnlockReg();

	PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);
	PF->MODE &= ~(GPIO_MODE_MODE4_Msk | GPIO_MODE_MODE5_Msk);

	CLK->PWRCTL |= CLK_PWRCTL_HXTEN_Msk; // XTAL12M (HXT) Enabled
	CLK->PWRCTL |= CLK_PWRCTL_LXTEN_Msk; // 32K (LXT) Enabled
	CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);
	CLK_WaitClockReady(CLK_STATUS_LXTSTB_Msk);

	CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HXT, CLK_CLKDIV0_HCLK(1));
	CLK_SetCoreClock(FREQ_192MHZ);
	CLK->PCLKDIV = CLK_PCLKDIV_PCLK0DIV1 | CLK_PCLKDIV_PCLK1DIV1;

	CLK_EnableModuleClock(EMAC_MODULE);
	CLK_EnableModuleClock(TMR0_MODULE); //
	CLK_EnableModuleClock(TMR1_MODULE);
  CLK_EnableModuleClock(EPWM0_MODULE); //����Ҫ
	CLK_EnableModuleClock(EPWM1_MODULE); //����Ҫ
	CLK_EnableModuleClock(QEI0_MODULE);//QEIʱ��ģ��
	CLK_EnableModuleClock(QEI1_MODULE);
	CLK_EnableModuleClock(EADC_MODULE);//EADCʱ��ģ��
	
	//CLK_EnableModuleClock(TMR1_MODULE); //����Ҫ
	//CLK_EnableModuleClock(TMR2_MODULE); //����Ҫ
	//CLK_EnableModuleClock(TMR3_MODULE); //����Ҫ

	//CLK_EnableModuleClock(I2C1_MODULE);//����Ҫ
#if defined(DEBUG) || defined(DEBUG0)
	CLK_EnableModuleClock(UART0_MODULE);
	CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));
#endif

	CLK_SetModuleClock(EMAC_MODULE, 0, CLK_CLKDIV3_EMAC(127));

	CLK_SetModuleClock(EPWM0_MODULE, CLK_CLKSEL2_EPWM0SEL_PLL, (uint32_t)NULL); //����Ҫ
	CLK_SetModuleClock(EPWM1_MODULE, CLK_CLKSEL2_EPWM1SEL_PLL, (uint32_t)NULL); //����Ҫ

	CLK_SetModuleClock(TMR0_MODULE, CLK_CLKSEL1_TMR0SEL_HXT, 0);
	CLK_SetModuleClock(EADC_MODULE, 0, CLK_CLKDIV0_EADC(1));

	//CLK_SetModuleClock(TMR1_MODULE, CLK_CLKSEL1_TMR1SEL_HXT, 0);
	//CLK_SetModuleClock(TMR2_MODULE, CLK_CLKSEL1_TMR2SEL_HXT, 0);
	//CLK_SetModuleClock(TMR3_MODULE, CLK_CLKSEL1_TMR3SEL_HXT, 0);

	SystemCoreClockUpdate();

	//��ʵ������ר��IO ����һ��ʾ��	
	//SYS->GPA_MFPH = SYS_GPA_MFPH_PA8MFP_INT4;
	//--------------------------------------------------------------------------------A
	SYS->GPA_MFPH = 0x00000000;
#if defined(DEBUG) || defined(DEBUG0)
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR | SYS_GPA_MFPL_PA3MFP_EPWM0_CH2 | SYS_GPA_MFPL_PA2MFP_EPWM0_CH3
	                 |SYS_GPA_MFPL_PA1MFP_UART0_TXD | SYS_GPA_MFPL_PA0MFP_UART0_RXD;
#else
	SYS->GPA_MFPL = SYS_GPA_MFPL_PA7MFP_EMAC_RMII_CRSDV | SYS_GPA_MFPL_PA6MFP_EMAC_RMII_RXERR|
									SYS_GPA_MFPL_PA3MFP_EPWM0_CH2 | SYS_GPA_MFPL_PA2MFP_EPWM0_CH3 ;
#endif
	//--------------------------------------------------------------------------------B
	//SYS->GPB_MFPH = 
	SYS->GPB_MFPL = SYS_GPB_MFPL_PB7MFP_EADC0_CH7 | SYS_GPB_MFPL_PB6MFP_EADC0_CH6 |
									SYS_GPB_MFPL_PB1MFP_EADC0_CH1 | SYS_GPB_MFPL_PB0MFP_EADC0_CH0;
	//--------------------------------------------------------------------------------C
	/*SYS_GPC_MFPH_PC11MFP_SPI3_MOSI | SYS_GPC_MFPH_PC10MFP_SPI3_CLK |*/ 
	SYS->GPC_MFPH = SYS_GPC_MFPH_PC13MFP_UART2_TXD | SYS_GPC_MFPH_PC8MFP_EMAC_RMII_REFCLK ;
	SYS->GPC_MFPL = SYS_GPC_MFPL_PC7MFP_EMAC_RMII_RXD0 | SYS_GPC_MFPL_PC6MFP_EMAC_RMII_RXD1 | SYS_GPC_MFPL_PC5MFP_EPWM1_CH0 | SYS_GPC_MFPL_PC4MFP_EPWM1_CH1 | 
								  SYS_GPC_MFPL_PC3MFP_EPWM1_CH2 | SYS_GPC_MFPL_PC2MFP_EPWM1_CH3 | SYS_GPC_MFPL_PC1MFP_EPWM1_CH4 | SYS_GPC_MFPL_PC0MFP_EPWM1_CH5;
	//--------------------------------------------------------------------------------D
	/*SYS_GPD_MFPH_PD14MFP_EPWM0_CH4 |*/
	SYS->GPD_MFPH = SYS_GPD_MFPH_PD12MFP_UART2_RXD |
									SYS_GPD_MFPH_PD11MFP_UART1_TXD | SYS_GPD_MFPH_PD10MFP_UART1_RXD;
	//SYS->GPD_MFPL = 0x00000000;
	//--------------------------------------------------------------------------------E
  SYS->GPE_MFPH = SYS_GPE_MFPH_PE12MFP_EMAC_RMII_TXEN | SYS_GPE_MFPH_PE11MFP_EMAC_RMII_TXD1 | SYS_GPE_MFPH_PE10MFP_EMAC_RMII_TXD0 |
									SYS_GPE_MFPH_PE9MFP_EMAC_RMII_MDIO | SYS_GPE_MFPH_PE8MFP_EMAC_RMII_MDC;
	SYS->GPE_MFPL = SYS_GPE_MFPL_PE7MFP_QEI1_INDEX | SYS_GPE_MFPL_PE6MFP_QEI1_A | SYS_GPE_MFPL_PE5MFP_QEI1_B | SYS_GPE_MFPL_PE4MFP_QEI0_INDEX |
									SYS_GPE_MFPL_PE3MFP_QEI0_A | SYS_GPE_MFPL_PE2MFP_QEI0_B;
	//--------------------------------------------------------------------------------F
	SYS->GPF_MFPH = SYS_GPF_MFPH_PF8MFP_SPI0_CLK | SYS_GPF_MFPH_PF9MFP_SPI0_SS;
	//| SYS_GPF_MFPL_PF1MFP_ICE_CLK | SYS_GPF_MFPL_PF0MFP_ICE_DAT
	SYS->GPF_MFPL = SYS_GPF_MFPL_PF7MFP_SPI0_MISO | SYS_GPF_MFPL_PF6MFP_SPI0_MOSI | SYS_GPF_MFPL_PF5MFP_X32_IN | SYS_GPF_MFPL_PF4MFP_X32_OUT | 
									SYS_GPF_MFPL_PF3MFP_XT1_IN | SYS_GPF_MFPL_PF2MFP_XT1_OUT;
	//--------------------------------------------------------------------------------G
	//SYS->GPG_MFPH = 0x00000000;
	SYS->GPG_MFPL = SYS_GPG_MFPL_PG3MFP_I2C1_SDA | SYS_GPG_MFPL_PG2MFP_I2C1_SCL;
	//--------------------------------------------------------------------------------H
	//SYS->GPH_MFPH = SYS_GPH_MFPH_PH9MFP_SPI1_SS | SYS_GPH_MFPH_PH8MFP_SPI1_CLK;
	SYS->GPH_MFPH = SYS_GPH_MFPH_PH11MFP_EPWM0_CH5;
	SYS->GPH_MFPL = SYS_GPH_MFPL_PH7MFP_SPI1_SS | SYS_GPH_MFPL_PH6MFP_SPI1_CLK | SYS_GPH_MFPL_PH5MFP_SPI1_MOSI | SYS_GPH_MFPL_PH4MFP_SPI1_MISO;
	//--------------------------------------------------------------------------------

	//Enable high slew rate on all RMII TX output pins
	PE->SLEWCTL = (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN10_Pos) | (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN11_Pos) | (GPIO_SLEWCTL_HIGH << GPIO_SLEWCTL_HSREN12_Pos);

	GPIO_DISABLE_DIGITAL_PATH(PB, B_C_AD1|B_C_AD0|  B_C_AD7 | B_C_AD6); 

	//IIC����
	//PE->SMTEN |= GPIO_SMTEN_SMTEN1_Msk;
	//PH->SMTEN |= GPIO_SMTEN_SMTEN8_Msk;
	SYS_LockReg();
}


//��ʵ������ͨ��IO ����һ��ʾ��
__STATIC_INLINE void IO_Init(void)
{

	GPIO_SET_DEBOUNCE_TIME(GPIO_DBCTL_DBCLKSRC_LIRC, Dsr);//ȥ����

	//�������
	//���縴λ�˿�
	//---------------------------------------------------------------------------------A
	GPIO_SetMode(PA, B_C_RMII_RESET | B_C_LED1 | B_C_BUZZER |
										B_C_M5_EN | B_C_M6_EN | B_C_M7_EN | B_C_M8_EN,
										GPIO_MODE_OUTPUT);
	P_C_RMII_RESET = 1;	//����������(���ݾ�������)��ƽ
	P_C_LED1 = 0; // 0----�� 	1----����
	P_C_BUZZER = 0;
	P_C_M5_EN = 1; P_C_M6_EN = 1; P_C_M7_EN = 1; P_C_M8_EN = 1;
	
	GPIO_SetMode(PA, B_C_INPUT_9 | B_C_INPUT_10 | B_C_INPUT_11, 
										GPIO_MODE_INPUT);
#if defined(DEBUG)
	GPIO_EnableInt(PA,N_C_INPUT_11,GPIO_INT_BOTH_EDGE);//��ֽ������ 0(���ڵ� ��ֽ)->1(�ڵ� ��ֽ)
#elif define(RELEASE)
	GPIO_EnableInt(PA,N_C_INPUT_11,GPIO_INT_FALLING);
#endif	
	NVIC_EnableIRQ(GPA_IRQn);
		
	GPIO_ENABLE_DEBOUNCE(PA, B_C_INPUT_9);
	GPIO_ENABLE_DEBOUNCE(PA, B_C_INPUT_10);
	GPIO_ENABLE_DEBOUNCE(PA, B_C_INPUT_11);
	
	//---------------------------------------------------------------------------------B
	GPIO_SetMode(PB, B_C_OUT_9 | B_C_OUT_10 | B_C_OUT_11 | B_C_OUT_12 | B_C_OUT_13 | B_C_OUT_14 | B_C_OUT_15 | B_C_OUT_16, 
										GPIO_MODE_OUTPUT);
	P_C_OUT_9 = 1; P_C_OUT_10 = 1; P_C_OUT_11 = 1; P_C_OUT_12 = 1; P_C_OUT_13 = 1; P_C_OUT_14 = 0; P_C_OUT_15 = 0; P_C_OUT_16 =0;
	
	
	GPIO_SetMode(PB, B_C_INPUT_1 | B_C_INPUT_2 |B_C_INPUT_3 | B_C_INPUT_4, 
								GPIO_MODE_INPUT);
								
	//GPIO_EnableInt(PB,N_C_INPUT_1,GPIO_INT_RISING);//ZHOU: ֽ�̸�λ������ 0(�ڵ�) -> 1(���ڵ�)	
	//GPIO_EnableInt(PB,N_C_INPUT_2,GPIO_INT_RISING);//��ֽ������	0(��ֽ-���ڵ�)->1(��ֽ-�ڵ�)
	GPIO_EnableInt(PB,N_C_INPUT_3,GPIO_INT_RISING);//��ֽ������ 0(���ڵ�)->1(�ڵ�) ��ֽ���������ڵ�
	NVIC_EnableIRQ(GPB_IRQn);
	
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_1);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_2);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_3);
	GPIO_ENABLE_DEBOUNCE(PB, B_C_INPUT_4);
	
	//---------------------------------------------------------------------------------C
	GPIO_SetMode(PC, B_C_OUT_8, GPIO_MODE_OUTPUT);
	P_C_OUT_8 = 1;
	
	GPIO_SetMode(PC, B_C_INPUT_5 | B_C_INPUT_6 | B_C_INPUT_7 | B_C_INPUT_8 , 
								GPIO_MODE_INPUT);
								
  GPIO_EnableInt(PC,N_C_INPUT_5,GPIO_INT_BOTH_EDGE);//��ֽ������ ->�ɴﴫ����									
	//GPIO_EnableInt(PC,N_C_INPUT_6,GPIO_INT_RISING);//������ 
	NVIC_EnableIRQ(GPC_IRQn);
	
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_5);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_6);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_7);
	GPIO_ENABLE_DEBOUNCE(PC, B_C_INPUT_8);
	
	//---------------------------------------------------------------------------------D
	GPIO_SetMode(PD, B_C_M3_DIR | B_C_M4_DIR |B_C_M4_EN | B_C_OUT_7, GPIO_MODE_OUTPUT);
	P_C_M3_DIR = 0; P_C_M4_DIR = 0;
	P_C_M4_EN = 1;
	P_C_OUT_7 = 1;
	//---------------------------------------------------------------------------------E
	GPIO_SetMode(PE, B_C_M1_DIR | B_C_M2_DIR |
										B_C_OUT_1 | B_C_OUT_2,
										GPIO_MODE_OUTPUT);
	P_C_M1_DIR = 0; P_C_M2_DIR = 0;
	P_C_OUT_1 = 1; P_C_OUT_2 = 1;
	
	//---------------------------------------------------------------------------------F
	GPIO_SetMode(PF, B_C_LED3 | B_C_LED4, GPIO_MODE_OUTPUT);
	P_C_LED3 = 0; P_C_LED4 = 0;

	//---------------------------------------------------------------------------------G
	GPIO_SetMode(PG, B_C_LED2 | B_C_M5_DIR | B_C_M6_DIR | B_C_M7_DIR | B_C_M8_DIR | 
										B_C_M1_EN | B_C_M2_EN | B_C_M3_EN, 
										GPIO_MODE_OUTPUT);
	P_C_LED2 = 0;
	P_C_M5_DIR = 0;	P_C_M6_DIR = 0;	P_C_M7_DIR = 0;	P_C_M8_DIR = 0;
	P_C_M1_EN = 1; P_C_M2_EN = 1; P_C_M3_EN = 1;
	//---------------------------------------------------------------------------------H
	GPIO_SetMode(PH, B_C_OUT_3 | B_C_OUT_4 | B_C_OUT_5, GPIO_MODE_OUTPUT);
	P_C_OUT_3 = 1; P_C_OUT_4 = 1; P_C_OUT_5 = 1;
	//P_C_OUT_6 = 1; | B_C_OUT_6
}

//��ʼ��ȫ�ֱ���  ����һ��ʾ��
__STATIC_INLINE void Init_VAR(void) //��ʼ��ȫ�ֱ���
{
	// BUSY = 0;
	EMACTime = 0;
	UPTime = 0;
	InitTime = 0;
	tempUPTime = 0;
	EADCTime = 0;
	PaperOutputSensor = 0;
	stuiFlagQEIOVUNF = 0;
	CUTRUNTime= 0;
	SOLENOID2Time = 0;
	HEATTime = 0;
	PaperSendBackSensor = 0;
	PaperSendStop = 0;
	PlateRiseTime = 0;
	OUTPUTTime = 0;
	FeiDaBackTime = 0;
	//---------------------------TMR1
	InPutPaperDithering = 0;
}

int main(void)
{
	uint32_t RxLen = 0;
	uint32_t CommID = 0; //����ID
	//ϵͳ��ʼ��	
	SYS_Init();

	//ZHOU:�������
#if defined(DEBUG)
	UART_Open(UART0, 115200);
#endif

	//�˿ڳ�ʼ��	
	IO_Init();

  //��ʼ��ȫ�ֱ���
	Init_VAR();

	//CLK_SysTickLongDelay(1000);
	//���ز���
	LoadConfig();

	tempUPTime = CONF.UPTime;

	//��ʼ������
  P_C_RMII_RESET = 1;

	CLK_SysTickLongDelay(50000);
	CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);
	//CLK_SysTickLongDelay(50000);

	EMACINT = 0;
	EMACINTOO = 0;
	
	//����TIMER0�жϷ���
	TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 2);
	TIMER_EnableInt(TIMER0);//ZHOU:��ʱ�������ж�
	
	NVIC_EnableIRQ(TMR0_IRQn);
	TIMER_Start(TIMER0);
	
	
	TIMER_Open(TIMER1,TIMER_PERIODIC_MODE,100);
	TIMER_EnableInt(TIMER1);
	NVIC_EnableIRQ(TMR1_IRQn);
	TIMER_Start(TIMER1);

	EMAC_Open(g_au8MacAddr);
	//Init phy
  //EMAC_PhyInit();
	EMAC_EnableCamEntry(1, g_au8MacAddrArp);

	EMACINT = 1;
	EMACINTOO = 1;
	P_C_RMII_RESET = 0;

	//CLK_SysTickLongDelay(1000);
	EMAC_DISABLE_RECV_BCASTPKT();
	EMAC_DISABLE_RECV_MCASTPKT();

	NVIC_EnableIRQ(EMAC_TX_IRQn);
	NVIC_EnableIRQ(EMAC_RX_IRQn);
	//CLK_SysTickLongDelay(1000);
	EMAC_ENABLE_RX();
	EMAC_ENABLE_TX();

	//P_EMACREST = 1;
	//CLK_SysTickLongDelay(50000);
	//P_EMACREST = 0;
	//CLK_SysTickLongDelay(50000);
	
	printf("Ready for circulation 2024-06-20-1\n");
	f_PIDInit();
	//----------------------------------------------
	uint16_t MainRollMode = 0;//����������ģʽ 1--ֽ�̸�λ	2--ֽ����λ  3--ֽ�̵�λ	
	uint32_t riseAlarmAndStop = 0; // ����ʱ�������ٴκ���Ȼû�е���λ����
	uint32_t risePlateFlag = 0;// ��ʼ����
	//----------------------------------------------
	uint8_t MachineIsBeging = 0;
	uint8_t MachineIsPause = 0;
	uint32_t g_uiQEI0 = 0;//��ʱ��¼QEI0��ֵ
	//----------------------------------------------
	uint16_t CurrPlateOperator = 0;
	//----------------------------------------------
	uint8_t Solenoid2Down = 0;//�¹�����(��ŷ�)״̬--���½�
	//----------------------------------------------
	uint32_t currPaperIndex = 0;
	uint16_t CurrOperator = 0;
	uint16_t BeforeOperator = 0;

	uint8_t CutPaperFlag = 0;
	uint8_t CutPaper = 0;
	uint8_t OutputSensorFlag = 0;
	//----------------------------------------------
	uint16_t CurrFeiDaOperator = 0;
	//----------------------------------------------
	uint32_t AlarmCodeAndStop = 0;
	uint32_t LastAlarmCode = 0;
	//----------------------------------------------��ʼ��
	uint8_t Init_Motor1Run = 0;
	//----------------------------------------------TMR1
	uint16_t u16FlagInputPaperShark = 0;
	//----------------------------------------------
	Init_Machine();
	//������ѭ��
	while (1) { //��ѭ��
		do {
				RxLen = u32PktLen;
				if (RxLen == 0)
						break;
				//NVIC_DisableIRQ(EMAC_RX_IRQn);
				EMACTime = 0; //?���жϾ�֤������������
				memcpy(pRxBufByte, auNetPkt, UDPLength);// ZHOU:����UDPͷ������
	
				RxLen = u32PktLen - UDPLength;// ZHOU:��ʵ�����ݳ���
				if (RxLen != 0) {
					memcpy((void*)&RxBuf, auNetPkt + UDPLength, RxLen);//ZHOU:��ʵ������
				}
				u32PktLen = 0;
				//printf("Recv IP msg\n");
				//ARP���� ��PC���ӱ���Ҫ
				if ((pRxBufByte[12] == 0x08) && (pRxBufByte[13] == 0x06)) {
					if (pRxBufByte[21] == 0x02) {	// ZHOU:��Ӧ
							//printf("Recv ARP ��Ӧ\n");
							g_au8YourMacAddr[0] = pRxBufByte[22];
							g_au8YourMacAddr[1] = pRxBufByte[23];
							g_au8YourMacAddr[2] = pRxBufByte[24];
							g_au8YourMacAddr[3] = pRxBufByte[25];
							g_au8YourMacAddr[4] = pRxBufByte[26];
							g_au8YourMacAddr[5] = pRxBufByte[27];
							g_au8YourMacAddr[0],
							g_au8YourMacAddr[1],
							g_au8YourMacAddr[2],
							g_au8YourMacAddr[3], 
							g_au8YourMacAddr[4], 
							g_au8YourMacAddr[5];
							tempUPTime = CONF.UPTime;
					} else if ((pRxBufByte[21] == 0x01) &&
						(pRxBufByte[38] == g_au8IpAddr[0]) &&
						(pRxBufByte[39] == g_au8IpAddr[1]) &&
						(pRxBufByte[40] == g_au8IpAddr[2]) &&
						(pRxBufByte[41] == g_au8IpAddr[3])) {// ZHOU: ����
						//printf("Recv ARP ����\n");
						g_au8YourMacAddr[0] = pRxBufByte[22];
						g_au8YourMacAddr[1] = pRxBufByte[23];
						g_au8YourMacAddr[2] = pRxBufByte[24];
						g_au8YourMacAddr[3] = pRxBufByte[25];
						g_au8YourMacAddr[4] = pRxBufByte[26];
						g_au8YourMacAddr[5] = pRxBufByte[27];

						g_au8YourMacAddr[0],
						g_au8YourMacAddr[1],
						g_au8YourMacAddr[2],
						g_au8YourMacAddr[3], 
						g_au8YourMacAddr[4], 
						g_au8YourMacAddr[5];

						//ZHOU: ֡ͷ(14) + Ӳ��Э��(2) + Э������(2) + Ӳ������(1) + Э�鳤��(1) + ����(2) + ԴMAC(6) + ԴIP(4) + Ŀ��MAC(6) + Ŀ��IP(4)
						uint8_t auPkt[] = {
								YOURMAC,
								MYMAC,
								0x08,
								0x06,//14
								0x00,0x01,
								0x08,0x00,
								0x06, 
								0x04,
								0x00,0x02,
								MYMAC ,
								MYIP,
								YOURMAC,
								YOURIP,
						};
						EMAC_SendPkt(auPkt, sizeof(auPkt));//ZHOU: ����EMAC ������һ�����ݰ�
						tempUPTime = CONF.UPTime;//ZHOU:��������ʲô��
					}
					break;
				}
			  //UDPЭ�� ����������Ӧ
				if ((pRxBufByte[0] == MYMAC0) && (pRxBufByte[1] == MYMAC1) && (pRxBufByte[2] == MYMAC2) &&
						(pRxBufByte[3] == MYMAC3) && (pRxBufByte[4] == MYMAC4) && (pRxBufByte[5] == g_au8MacAddr[5]) &&
						(pRxBufByte[23] == 0x11)) { //ZHOU:0x11 ��ʾЭ��ΪUDP
					CommID = theCmd;  //ZHOU:theCmd  RxBuf[0]  cmd���ݴ������ʵ�ʵ����ݾ���
					theCmd = 0;
					//printf("Recv UDP information CommID %d\n",CommID);
					switch (CommID) {
						case ID_TMDOutPutStatus:
							FMDOutPutStatus();
							break;
						case ID_ENTERTESTMODE:
							FMDEnterTestMode();
							break;
						case ID_EXITTESTMODE:
							FMDExitTestMode();
							break;
						case ID_FMDReadMessage:
							FMDReadMessage();
							break;
						case ID_FMDReadConfig:
							FMDReadConfig();
							break;
						case ID_FMDWriteConfig:
							FMDWriteConfig();
							break;
						case ID_FMDReSetConfig:
							FMDReSetConfig();
							break;
						case ID_FOO:
							foo();
							break;
						case ID_BAR:
							bar();
							break;
						case ID_M1RUN:
							Motor1_Run();
							g_iSignalOper = 1;
							break;
						case ID_M1STOP:
							Motor1_Stop();
							break;
						case ID_M2RUN:
							Motor2_Run();
							g_iSignalOper = 1;
							break;
						case ID_M2STOP:
							Motor2_Stop();
							break;
						case ID_M3RUN:	
							Motor3_Run();
							g_iSignalOper = 1;
							break;
						case ID_M3STOP:
							Motor3_Stop();
							break;
						case ID_M4RUN:
							Motor4_Run();
							g_iSignalOper = 1;
							break;
						case ID_M4STOP:
							Motor4_Stop();
							break;
						case ID_M5RUN:
							Motor5_Run();
							g_iSignalOper = 1;
							break;
						case ID_M5STOP:
							Motor5_Stop();
							break;
						case ID_M6RUN:
							Motor6_Run();
							g_iSignalOper = 1;
							break;
						case ID_M6STOP:
							Motor6_Stop();
							break;
						case ID_M7RUN:
							Motor7_Run();
							break;
						case ID_M7STOP:
							Motor7_Stop();
							break;
						case ID_M8RUN:
							Motor8_Run();
							break;
						case ID_M8STOP:
							Motor8_Stop();
							break;
						case ID_QEI0START:
							QEI0_Start();
							break;
						case ID_QEI0STOP:
							QEI0_Stop();
							break;
						case ID_QEI1START:
							QEI1_Start();
							break;
						case ID_QEI1STOP:
							QEI1_Stop();
							break;
						case ID_UPDATEOUTSTATE:
							OUTPUT_UpdateState();
							break;		
						case ID_UPDATEMACHINEFHZ:
							MACHINE_UpdateFHz();
							break;
						case ID_UPDATEMACHINEDIA:
							MACHINE_UpdateDia();
							break;
						case ID_BEGINGWORK: {//����
							g_iSignalOper = 0;
							uint32_t uiRet = Before_Begin_Working();//�жϷɴ�Ƶ���Ƿ����
							if(uiRet == 0) {
								Beging_Working();		
								QEIValueIndex_NextPaper =0;
								QEIValueIndex_OverLap = 0;
								QEIValueIndex_CutPaperPlace = 0;
								QEIValueIndex_BrokenPaper = 0;
															
								P_C_OUT_4 = 0;//�¹���ŷ� ����
								stuiFlagQEIOVUNF = 0;//��� Խ��
								
								Solenoid2Down = 0;//����ǰ��һ����ͣ�����¹���ŷ��ɿ�
								currPaperIndex = 0;	//�������
								//CurrOperator = CURROPERATOR_FEEDDOWNALIGNDOWN;
								if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) {//û��ֽ
									P_C_OUT_2 = 0;
									P_C_OUT_3 = 0;	
									MachineIsBeging = 2;
									MachineIsPause = 0;		
									P_C_OUT_7 = 0;				

									g_u32_Sheet_Record_LastStopQEI = 0; 
									g_u32_Sheet_Record_DeviationQEI = 0; 
								}
								else if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_HAVE_ON_PLATFORM__) {
									P_C_OUT_2 = 0; //��ֽ��
									P_C_OUT_3 = 1; //��������
									MachineIsBeging = 1;
									MachineIsPause = 0;										
								}
							
								BeforeOperator = 0;				
								CurrOperator = 0;								
								CurrPlateOperator = 0;								
								CurrFeiDaOperator = 0;
								
								g_u16FlagFocusFeederSensor = 0;
								stIsBeginFirstPaper = 0;
								
								LastAlarmCode = 0;
								AlarmCodeAndStop = 0;
								
								g_u32BrokenPaperStoreIndex = 0;
							}		
						}
							break;
						case ID_FINISHWORK: {//����
							//MachineIsBeging = 0;
							MachineIsPause = 1;
							Finish_Working();
						}
							break;
						case ID_LAMINATINGROLLHEAT: {//���ȸ�Ĥ����
							HEATTime = 0;//��ռ���ʱ�����
							HeatLaminationRoll();
						}
							break;
						case ID_UPDATEFEIDARETREAT:{
							FeiDaMotor_UpdateFHz();
						}
							break;
						case ID_TESTFEIDAFHZ: {
							g_iSignalOper = 1;
							TestFeiDaFhzWithMotor2();
						}
							break;
						case ID_TESTBROKENFHZ: {
							g_iSignalOper = 1;
							TestBrokenFhzWithMotot1();
						}	
							break;
						case ID_TESTSETSOLENOID_VALUE:{
							SetSolenoidValue();
						}
							break;
						case ID_TESTTEMP_DUTY: {
							TestHeatDuty();
						}
							break;
						case ID_TEST_SHEET_PAPER:{
							g_iSignalOper = 0;
							TestSheetPaper();
							P_C_OUT_4 = 0;//�¹���ŷ� ����
							stuiFlagQEIOVUNF = 0;//��� Խ��
							P_C_OUT_7 = 0;
							P_C_OUT_2 = 0;
							P_C_OUT_3 = 0;	
															
							LastAlarmCode = 0;
							AlarmCodeAndStop = 0;
							if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) {//û��ֽ
								//P_C_OUT_2 = 0; //��ֽ��
								//P_C_OUT_3 = 0; //��������
								MachineIsBeging = 3;
								currPaperIndex = 0;
								BeforeOperator = 0;				
								CurrOperator = 0;								
								CurrPlateOperator = 0;								
								CurrFeiDaOperator = 0;
								QEIValueIndex_NextPaper =0;
								QEIValueIndex_OverLap = 0;
								QEIValueIndex_CutPaperPlace = 0;
								QEIValueIndex_BrokenPaper = 0;
							} else {
								MachineIsBeging = 4;
								//P_C_OUT_2 = 1; //��ֽ��
								//P_C_OUT_3 = 0; //��������
							}
						}
							break;
						default: {
							P_C_LED1 = 1;
							P_C_LED2 = 0;
							P_C_LED3 = 1;
							P_C_LED4 = 0;
						}
							break;
						}
				}
				UPTime = 0;
				theCmd = 0;
				//NVIC_EnableIRQ(EMAC_RX_IRQn);
				//BUSY = 0;
		} while (0);
		///////////////////
		//�������� ϵ��.............	
		//----------------------------------------------����� --- ֽ�̵��ģʽ�ж� + ����ʱ����Զ����� + ��λ/��λֹͣ���
		if(P_C_INPUT_1 == 1 && P_C_INPUT_6 == 1){//��λ�ж�
			if(P_C_M3_DIR == 1) {
				CurrPlateOperator = PLATEOPERATOR_STOP;
			}
			if(MachineIsBeging == 1) { //ֽ�̸�λ ��� ֽ�̵�λ����
				riseAlarmAndStop = 0;
				CurrPlateOperator = PLATEOPERATOR_STOP;
				if(AlarmCodeAndStop == ALARM_PAPERPLATELOW) {
					AlarmCodeAndStop = 0;
				}
			}
		} else if(P_C_INPUT_1 == 0 && P_C_INPUT_6 == 0){//��λ�ж�
			if(P_C_M3_DIR == 0) {
				CurrPlateOperator = PLATEOPERATOR_STOP;
			}
		} else if(P_C_INPUT_1 == 0 && P_C_INPUT_6 == 1) {//ֽ���м�λ��
			if(MachineIsBeging == 1) {
				if(riseAlarmAndStop == CONF.PaperPlateRiseTimeAlarm) { 
					 AlarmCodeAndStop = ALARM_PAPERPLATELOW;
				} else {
					if(risePlateFlag == 0) {
						risePlateFlag = 1;
						PlateRiseTime = 0;
						CurrPlateOperator = PLATEOPERATOR_RISE;
					}
					if(risePlateFlag == 1 && PlateRiseTime >= 1) {
						risePlateFlag = 0;
						CurrPlateOperator = PLATEOPERATOR_STOP;
						riseAlarmAndStop++;
					}
				}			
			} 
		}
		if(CurrPlateOperator != 0 && AlarmCodeAndStop == 0) {
			uint16_t oper = CurrPlateOperator;
			CurrPlateOperator = 0;
			switch (oper)
      {
      	case PLATEOPERATOR_DOWN: {
					f_MotorRun(ID_M3RUN,CONF.M3_FHZ,0);
				}
      		break;
      	case PLATEOPERATOR_RISE: {
					f_MotorRun(ID_M3RUN,CONF.M3_FHZ,1);
				}
      		break;
				case PLATEOPERATOR_STOP: {
					f_MotorStop(ID_M3STOP);
				}
					break;
      	default:
      		break;
      }
		}
		//===========================================================================================
		if(MachineIsBeging == 2) {
			if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) {//��⵽ֽ��
				MachineIsBeging = 1;	
				if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) {//û��ֽ
					QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk); 
					uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
					g_uiQEI0 = uiQEI0;					
					g_u32Initial_ValueRecord = uiQEI0;
					if(currPaperIndex == 0) {
						PaperQEI[currPaperIndex][QEIVALUE_PAPERHEADER] =  uiQEI0 - g_AlignSolenoidToInSensorPulse;//- AlignSolenoidToInputPaperSensor;
						PaperQEI[currPaperIndex][QEIVALUE_NEXTPAPER] = uiQEI0 + g_AlignUpLengthToPulse - g_AlignSolenoidToInSensorPulse;// - AlignSolenoidToInputPaperSensor;
						
						PaperQEI[currPaperIndex][QEIVALUE_OVERLAP] = uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse - g_AlignSolenoidToInSensorPulse;// - AlignSolenoidToInputPaperSensor;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UploadStateNow_WithTwoParam(ID_UPLOADINITIAL_COUNT, g_u32Initial_ValueRecord, uiQEI0 + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath));//- AlignSolenoidToInputPaperSensor
						}	
						PaperQEI[currPaperIndex][QEIVALUE_CUTPAPERPLACE] = uiQEI0 - g_AlignSolenoidToInSensorPulse + (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse + g_AlignSolenoidToInSensorPulse);// - AlignSolenoidToInputPaperSensor 
						
						//BrokenPaperQEI[g_u32BrokenPaperLength] = uiQEI0 - g_AlignSolenoidToInSensorPulse + (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse - g_AlignSolenoidToInSensorPulse);
						//��¼��ֽ��λ��						
						BrokenPaperQEI[g_u32BrokenPaperLength++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse +  ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);// ��һ����Ҫ��ֽʱ��QEIֵ
						currPaperIndex++;
						g_u16FlagFocusFeederSensor = 1; 
					} 											
				}
				//QEI_SET_CNT_VALUE(QEI0,4096);
			}
		} 
		if(MachineIsBeging == 1) {	
			if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 0 && g_u16FlagFocusFeederSensor == 1) {//û�м�⵽ֽ && g_u16FlagFocusFeederSensor == 1
				//����ֹͣ
				if(u16FlagInputPaperShark == 0) {
					u16FlagInputPaperShark = 1;
					InPutPaperDithering = 0;
					P_C_LED1 = 1;
					P_C_LED2 = 0;
					P_C_LED3 = 1;
					P_C_LED4 = 0;
				}
				if(u16FlagInputPaperShark == 1 && InPutPaperDithering >= 6) {
					Solenoid2Down = 1;
					SOLENOID2Time = 0;
					MachineIsBeging = 0;
					InPutPaperDithering = 0;
					u16FlagInputPaperShark = 0;
					P_C_LED1 = 0;
					P_C_LED2 = 1;
					P_C_LED3 = 0;
					P_C_LED4 = 1;
					AlarmCodeAndStop = ALARM_INPAPERUNDETECTED;
					LastAlarmCode = 0;
				}
			} else if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) {//��⵽��ֽ
				u16FlagInputPaperShark = 0;
				if(AlarmCodeAndStop == ALARM_INPAPERUNDETECTED) {
					AlarmCodeAndStop = 0;
				} 
			}
			QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk); 
			uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
			g_uiQEI0 = uiQEI0;			
			if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_HAVE_ON_PLATFORM__) { // ��ֽ
				if(uiQEI0 == g_FeiDaMotorForwardPulse && stuiFlagQEIOVUNF == 0 && g_FeiDaMotorForwardPulse != 0) {//�ɴ�����������  ʣ���ֽ����һ����һ��ֹͣʱû�м�����ֽ
					g_FeiDaMotorForwardPulse = 0;
					CurrFeiDaOperator = FEIDAOPERATOR_FEIDAFOWWARD;
					g_u16FlagFocusFeederSensor = 1;
				}		
				if(uiQEI0 == g_FirstPaperHeaderQEI && stuiFlagQEIOVUNF == 0) {//�������ߵ�����ȥ������ֽ���ص�����
					if(currPaperIndex == 0) {
						PaperQEI[currPaperIndex][QEIVALUE_PAPERHEADER] = uiQEI0;
						PaperQEI[currPaperIndex][QEIVALUE_NEXTPAPER] = uiQEI0 + g_AlignUpLengthToPulse;
						PaperQEI[currPaperIndex][QEIVALUE_OVERLAP] = uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse;
						PaperQEI[currPaperIndex][QEIVALUE_CUTPAPERPLACE] = uiQEI0 + (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse + g_AlignSolenoidToInSensorPulse);//
						currPaperIndex++;
						
						BrokenPaperQEI[g_u32BrokenPaperLength++] = uiQEI0 +  g_AlignSolenoidToCutPaperPulse + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);
					} 
					//���� ��ֽ��ŷ����� �����ŷ��½� 
					CurrOperator = CURROPERATOR_FEEDUPALIGNDOWN;
					//if(g_iSchema == SCHEMA_TESTMODE) {
						//UploadStateNow_WithOneParam(ID_RUN_STATE_FEEDUPALIGNDOWN,121);
					//}						
				}							
			}
			//-----------------------------------------------------------
			if(QEIValueIndex_NextPaper < currPaperIndex && uiQEI0 == PaperQEI[QEIValueIndex_NextPaper][QEIVALUE_NEXTPAPER]) {
				//���� ��ֽ��ŷ��½� �����ŷ����� 
				CurrOperator = CURROPERATOR_FEEDDOWNALIGNUP;
				QEIValueIndex_NextPaper++;
				if(QEIValueIndex_NextPaper == g_OneCycleTotalPaperCount) {
					QEIValueIndex_NextPaper = 0; 
				}
				CurrFeiDaOperator = FEIDAOPERATOR_FEIDAFOWWARD;
				//if(g_iSchema == SCHEMA_TESTMODE) {
					//UploadStateNow_WithOneParam(ID_CUTPAPER,1122);
				//}	
			}
			if(QEIValueIndex_OverLap < currPaperIndex && uiQEI0 == PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP]) {
				//���� ��ֽ��ŷ����� �����ŷ��½� 
				CurrOperator = CURROPERATOR_FEEDUPALIGNDOWN;
				QEIValueIndex_OverLap++;
				if(QEIValueIndex_OverLap == g_OneCycleTotalPaperCount) {
					QEIValueIndex_OverLap = 0;
				}
				if(currPaperIndex != g_OneCycleTotalPaperCount) {
					currPaperIndex++;
				}
				PaperQEI[QEIValueIndex_OverLap][QEIVALUE_PAPERHEADER] = uiQEI0;
				uint32_t QEIGapMax = MAXQEI32INT - uiQEI0;
				if(QEIGapMax < g_AlignUpLengthToPulse) {			
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_NEXTPAPER] = g_AlignUpLengthToPulse - QEIGapMax;
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = g_PaperLengthToPulse - g_OverlapLengthToPulse - QEIGapMax;
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
				}	else {
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_NEXTPAPER] = uiQEI0 + g_AlignUpLengthToPulse;
					if(QEIGapMax < (g_PaperLengthToPulse - g_OverlapLengthToPulse)) {
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = g_PaperLengthToPulse - g_OverlapLengthToPulse - QEIGapMax;
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
					} else {
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse;
						if(QEIGapMax < (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse + g_AlignSolenoidToInSensorPulse)) {
							PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
						} else {
							PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = uiQEI0 + g_AlignSolenoidToCutPaperPulse;
						}
					}
				}

				if(g_u32BrokenPaperLength < __BROKEN_PAPER_QEI_MAX_COUNT__) {
					BrokenPaperQEI[g_u32BrokenPaperLength++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);
				} else {
					if(g_u32BrokenPaperStoreIndex == __BROKEN_PAPER_QEI_MAX_COUNT__) {
						g_u32BrokenPaperStoreIndex = 0;
					}
					BrokenPaperQEI[g_u32BrokenPaperStoreIndex++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);		
					if(g_u32BrokenPaperStoreIndex == QEIValueIndex_BrokenPaper) {
						if(g_iSchema == SCHEMA_TESTMODE) {
							g_AlarmCode = 438;
							FMDUploadAlarm();
						}
					}
				}			
			}
			if(QEIValueIndex_CutPaperPlace < currPaperIndex && uiQEI0 == PaperQEI[QEIValueIndex_CutPaperPlace][QEIVALUE_CUTPAPERPLACE]) {//������ͣ
				QEIValueIndex_CutPaperPlace++;
				if(QEIValueIndex_CutPaperPlace == g_OneCycleTotalPaperCount) {
					QEIValueIndex_CutPaperPlace = 0;
				}
				if(MachineIsPause == 1) {//��ͣ // ��һ����ͣ����Ҫ����		
					//CurrOperator = CURROPERATOR_ALLMACHINESTOP;
					f_AllMachineStop();
					if(g_iSchema == SCHEMA_TESTMODE) {
						UploadStateNow_WithOneParam(ID_PAUSEMACHINE,uiQEI0);
					}
					MachineIsBeging = 0;
					MachineIsPause = 0;
					g_LastBatchCount = 0;
					currPaperIndex = 0;
					Solenoid2Down = 1;
					SOLENOID2Time = 0;
				}
			}			
			//-----------------------------------------------------------��һ����ֽ��û�����������ͣ
			if(MachineIsPause == 1 && g_LastBatchCount != 0) {
				if(((uiQEI0-QEIRecordValue) % (g_LastPaperLengthPulse - g_LastOverlapLengthPulse)) == 0) {
					uint32_t uiMultiple = (uiQEI0-QEIRecordValue) / (g_LastPaperLengthPulse - g_LastOverlapLengthPulse);
					if(uiMultiple <= g_LastBatchCount) {
						//CurrOperator = CURROPERATOR_ALLMACHINESTOP;				
						f_AllMachineStop();
						if(g_iSchema == SCHEMA_TESTMODE) {
							UploadStateNow_WithOneParam(ID_PAUSEMACHINE,uiQEI0);
						}
						MachineIsBeging = 0;
						currPaperIndex = 0;
						MachineIsPause = 0;
						g_LastBatchCount = 0;
						Solenoid2Down = 1;
						SOLENOID2Time = 0;
					}
				}
			}
			//-----------------------------------------------------------��ֽʧ�ܵĴ�����ʱ�����Ҳ����
			if(QEIValueIndex_BrokenPaper < g_u32BrokenPaperLength && uiQEI0 == BrokenPaperQEI[QEIValueIndex_BrokenPaper]) {//��ֽ
				QEIValueIndex_BrokenPaper++;
				if(QEIValueIndex_BrokenPaper == __BROKEN_PAPER_QEI_MAX_COUNT__) {
					QEIValueIndex_BrokenPaper = 0;
				}
				CutPaper = 1;
			}
			//��ֽ����������ʱ��δ����
			if(CutPaper == 1) {
				CutPaper = 0;
				CutPaperFlag = 1;
				CUTRUNTime = 0;
				//CurrOperator = CURROPERATOR_CUTPAPER;
				f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
				if(g_iSchema == SCHEMA_TESTMODE) {
					UploadStateNow_WithOneParam(ID_CUTPAPER,uiQEI0);
				}
				g_CalculatePaperCount++;
				CONF.LaminatedPaperCount = g_CalculatePaperCount;
			}
			if(PaperBrolenMotorStop == 0 && (CUTRUNTime == 20 && CutPaperFlag == 1)) {//10����Ȼû�����е�λ
				CutPaperFlag = 0;
				AlarmCodeAndStop = ALARM_BROKENPAPERMOTOR;
			}
			//-----------------------------------------------------------����״̬�еĲ���
			if(CurrOperator != BeforeOperator && AlarmCodeAndStop == 0) {
				BeforeOperator = CurrOperator;
				switch (CurrOperator)
				{
					case CURROPERATOR_FEEDDOWNALIGNUP: {//2--��ֽ 3--���� 0--�� 1--��  7--��ֽ����	0--�� 1--��
						P_C_OUT_2 = 0;
						P_C_OUT_3 = 1;
						P_C_OUT_7 = 1;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(0,1,uiQEI0);//duiqi sonzhi
						}
					}
						break;
					case CURROPERATOR_FEEDUPALIGNDOWN: {
						P_C_OUT_2 = 1;
						P_C_OUT_3 = 0;
						P_C_OUT_7 = 0;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(1,0,uiQEI0);
						}
					}
						break;
					case CURROPERATOR_FEEDDOWNALIGNDOWN:{
						P_C_OUT_2 = 0;
						P_C_OUT_3 = 0;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(0,0,uiQEI0);
						}
					}
						break;
					case CURROPERATOR_ALLMACHINESTOP: {
						
					}
						break;
					case CURROPERATOR_CUTPAPER: {
						//f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
						//if(g_iSchema == SCHEMA_TESTMODE) {
							//UploadStateNow_WithOneParam(ID_CUTPAPER,uiQEI0);
						//}
					}
						break;
					default:
						break;
				}
			}
		}
		//===========================================================================================
		if(MachineIsBeging == 3) {
			if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) {//��⵽ֽ��
					MachineIsBeging = 4;	
					if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) {//û��ֽ
						QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk); 
						uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
						g_uiQEI0 = uiQEI0;					
						g_u32Initial_ValueRecord = uiQEI0;
						if(currPaperIndex == 0) {
							PaperQEI[currPaperIndex][QEIVALUE_PAPERHEADER] =  uiQEI0 - g_AlignSolenoidToInSensorPulse;//- AlignSolenoidToInputPaperSensor;
							PaperQEI[currPaperIndex][QEIVALUE_NEXTPAPER] = uiQEI0 + g_AlignUpLengthToPulse - g_AlignSolenoidToInSensorPulse;// - AlignSolenoidToInputPaperSensor;
							
							PaperQEI[currPaperIndex][QEIVALUE_OVERLAP] = uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse - g_AlignSolenoidToInSensorPulse;// - AlignSolenoidToInputPaperSensor;
							if(g_iSchema == SCHEMA_TESTMODE) {
								UploadStateNow_WithTwoParam(ID_UPLOADINITIAL_COUNT, g_u32Initial_ValueRecord, uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse - g_AlignSolenoidToInSensorPulse);//- AlignSolenoidToInputPaperSensor
							}	
							PaperQEI[currPaperIndex][QEIVALUE_CUTPAPERPLACE] = uiQEI0 - g_AlignSolenoidToInSensorPulse + g_AlignSolenoidToCutPaperPulse;// - AlignSolenoidToInputPaperSensor 
							
							//BrokenPaperQEI[g_u32BrokenPaperLength] = uiQEI0 - g_AlignSolenoidToInSensorPulse + (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse - g_AlignSolenoidToInSensorPulse);
							//��¼��ֽ��λ��						
							BrokenPaperQEI[g_u32BrokenPaperLength++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse +  ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);// ��һ����Ҫ��ֽʱ��QEIֵ
							currPaperIndex++;
						} 											
					}
					//QEI_SET_CNT_VALUE(QEI0,4096);
				}
		}			
		if(MachineIsBeging == 4) {			
			if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 0) {//û�м�⵽ֽ && g_u16FlagFocusFeederSensor == 1
				//����ֹͣ
				if(u16FlagInputPaperShark == 0) {
					u16FlagInputPaperShark = 1;
					InPutPaperDithering = 0;
				}
				if(u16FlagInputPaperShark == 1 && InPutPaperDithering >= 6) {
					Solenoid2Down = 1;
					SOLENOID2Time = 0;
					MachineIsBeging = 0;
					InPutPaperDithering = 0;
					u16FlagInputPaperShark = 0;
					AlarmCodeAndStop = ALARM_INPAPERUNDETECTED;
				}
			} else if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) {//��⵽��ֽ
				u16FlagInputPaperShark = 0;
				if(AlarmCodeAndStop == ALARM_INPAPERUNDETECTED) {
					AlarmCodeAndStop = 0;
				} 
			}
			QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk); 
			uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
			g_uiQEI0 = uiQEI0;			
			//-----------------------------------------------------------
			if(QEIValueIndex_NextPaper < currPaperIndex && uiQEI0 == (PaperQEI[QEIValueIndex_NextPaper][QEIVALUE_NEXTPAPER] - g_u32_Sheet_Record_DeviationQEI)) {
				//���� ��ֽ��ŷ��½� �����ŷ����� 
				CurrOperator = CURROPERATOR_FEEDDOWNALIGNUP;
				QEIValueIndex_NextPaper++;
				if(QEIValueIndex_NextPaper == g_OneCycleTotalPaperCount) {
					QEIValueIndex_NextPaper = 0; 
				}
				CurrFeiDaOperator = FEIDAOPERATOR_FEIDAFOWWARD;
				if(g_iSchema == SCHEMA_TESTMODE) {
					UploadStateNow_WithOneParam(ID_RUN_STATE_FEEDDOWNALIGNUP,uiQEI0);
				}	
			}
			//-----------------------------------------------------------
			if(QEIValueIndex_OverLap < currPaperIndex && uiQEI0 == (PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] - g_u32_Sheet_Record_DeviationQEI)) {
				//���� ��ֽ��ŷ����� �����ŷ��½� 
				//CurrOperator = CURROPERATOR_ALLMACHINESTOP;
				QEIValueIndex_OverLap++;
				if(QEIValueIndex_OverLap == g_OneCycleTotalPaperCount) {
					QEIValueIndex_OverLap = 0;
				}
				if(currPaperIndex != g_OneCycleTotalPaperCount) {
					currPaperIndex++;
				}
				PaperQEI[QEIValueIndex_OverLap][QEIVALUE_PAPERHEADER] = uiQEI0;
				uint32_t QEIGapMax = MAXQEI32INT - uiQEI0;
				if(QEIGapMax < g_AlignUpLengthToPulse) {			
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_NEXTPAPER] = g_AlignUpLengthToPulse - QEIGapMax;
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = g_PaperLengthToPulse - g_OverlapLengthToPulse - QEIGapMax;
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
				}	else {
					PaperQEI[QEIValueIndex_OverLap][QEIVALUE_NEXTPAPER] = uiQEI0 + g_AlignUpLengthToPulse;
					if(QEIGapMax < (g_PaperLengthToPulse - g_OverlapLengthToPulse)) {
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = g_PaperLengthToPulse - g_OverlapLengthToPulse - QEIGapMax;
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
					} else {
						PaperQEI[QEIValueIndex_OverLap][QEIVALUE_OVERLAP] = uiQEI0 + g_PaperLengthToPulse - g_OverlapLengthToPulse;
						if(QEIGapMax < (g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse + g_AlignSolenoidToInSensorPulse)) {
							PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = g_AlignSolenoidToCutPaperPulse - QEIGapMax;
						} else {
							PaperQEI[QEIValueIndex_OverLap][QEIVALUE_CUTPAPERPLACE] = uiQEI0 + g_AlignSolenoidToCutPaperPulse;
						}
					}
				}

				if(g_u32BrokenPaperLength < __BROKEN_PAPER_QEI_MAX_COUNT__) {
					BrokenPaperQEI[g_u32BrokenPaperLength++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);
				} else {
					if(g_u32BrokenPaperStoreIndex == __BROKEN_PAPER_QEI_MAX_COUNT__) {
						g_u32BrokenPaperStoreIndex = 0;
					}
					BrokenPaperQEI[g_u32BrokenPaperStoreIndex++] = uiQEI0 + g_AlignSolenoidToCutPaperPulse + ((g_PaperLengthToPulse-g_OverlapLengthToPulse)*g_f64BrokenLengthPath);		
					if(g_u32BrokenPaperStoreIndex == QEIValueIndex_BrokenPaper) {
						if(g_iSchema == SCHEMA_TESTMODE) {
							g_AlarmCode = 438;
							FMDUploadAlarm();
						}
					}
				}
				
				f_AllMachineStop();
				g_u32_Sheet_Record_LastStopQEI = uiQEI0;
				//Solenoid2Down = 1;
				//SOLENOID2Time = 0;
				if(g_iSchema == SCHEMA_TESTMODE) {
					UploadStateNow_WithTwoParam(ID_RUN_STATE_SHEET_STOP, uiQEI0, currPaperIndex);
				}
			}	
			//-----------------------------------------------------------��ֽʧ�ܵĴ�����ʱ�����Ҳ����
			if(QEIValueIndex_BrokenPaper < g_u32BrokenPaperLength && uiQEI0 == BrokenPaperQEI[QEIValueIndex_BrokenPaper]) {//��ֽ
				QEIValueIndex_BrokenPaper++;
				if(QEIValueIndex_BrokenPaper == __BROKEN_PAPER_QEI_MAX_COUNT__) {
					QEIValueIndex_BrokenPaper = 0;
				}
				CutPaper = 1;
			}
			//��ֽ����������ʱ��δ����
			if(CutPaper == 1) {
				CutPaper = 0;
				CutPaperFlag = 1;
				CUTRUNTime = 0;
				f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
				if(g_iSchema == SCHEMA_TESTMODE) {
					UploadStateNow_WithOneParam(ID_CUTPAPER,uiQEI0);
				}
				g_CalculatePaperCount++;
				CONF.LaminatedPaperCount = g_CalculatePaperCount;
			}
			if(PaperBrolenMotorStop == 0 && (CUTRUNTime == 20 && CutPaperFlag == 1)) {//10����Ȼû�����е�λ
				CutPaperFlag = 0;
				AlarmCodeAndStop = ALARM_BROKENPAPERMOTOR;
			}
			//-----------------------------------------------------------����״̬�еĲ���
			if(CurrOperator != BeforeOperator && AlarmCodeAndStop == 0) {
				BeforeOperator = CurrOperator;
				switch (CurrOperator)
				{
					case CURROPERATOR_FEEDDOWNALIGNUP: {//2--��ֽ 3--���� 0--�� 1--��  7--��ֽ����	0--�� 1--��
						P_C_OUT_2 = 0;
						P_C_OUT_3 = 1;
						P_C_OUT_7 = 1;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(0,1,uiQEI0);//duiqi sonzhi
						}
					}
						break;
					case CURROPERATOR_FEEDUPALIGNDOWN: {
						P_C_OUT_2 = 1;
						P_C_OUT_3 = 0;
						P_C_OUT_7 = 0;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(1,0,uiQEI0);
						}
					}
						break;
					case CURROPERATOR_FEEDDOWNALIGNDOWN:{
						P_C_OUT_2 = 0;
						P_C_OUT_3 = 0;
						if(g_iSchema == SCHEMA_TESTMODE) {
							UpLoadAlignBlockSolenoidState(0,0,uiQEI0);
						}
					}
						break;
					case CURROPERATOR_ALLMACHINESTOP: {				
					}
						break;
					case CURROPERATOR_CUTPAPER: {
						f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
						if(g_iSchema == SCHEMA_TESTMODE) {
							UploadStateNow_WithOneParam(ID_CUTPAPER,uiQEI0);
						}
					}
						break;
					default:
						break;
				}
			}
		}
		//===========================================================================================
		if(PaperBrolenMotorStop == 1 && g_iSignalOper == 0) {//��⵽ͣ���1	
			PaperBrolenMotorStop = 0;
			if(CutPaperFlag == 1) { // ����ʱ��ֽ����һȦ
				CutPaperFlag = 0;
			}
			if(Init_Motor1Run == 1) { // ��ʼ��ʱ��ֽ����һȦ
				Init_Motor1Run = 0;
			}
			f_MotorStop(ID_M1STOP);
			if(ALARM_BROKENPAPERMOTOR == AlarmCodeAndStop) {
				AlarmCodeAndStop = 0;
			}
			if(g_iSchema == SCHEMA_TESTMODE) {
				UploadStateNow_WithOneParam(ID_CUTPAPEREND,g_uiQEI0);
			}
		} else if(Init_Motor1Run == 1 && CUTRUNTime == 20 && PaperBrolenMotorStop == 0) {//��ʼ���Ƕ�ֽ�������
			Init_Motor1Run = 0;
			CUTRUNTime = 0;
			AlarmCodeAndStop = ALARM_BROKENPAPERMOTOR;
		}
		if(Solenoid2Down == 1 && SOLENOID2Time >= CONF.DownRollDrop) {//��ͣ��15���¹���ŷ��½�
			Solenoid2Down = 0;
			P_C_OUT_4 = 1;//�¹���ŷ�
			SOLENOID2Time = 0;
			if(g_iSchema == SCHEMA_TESTMODE) {
				UploadStateNow_WithOneParam(ID_DOWNROLLPLACE,1);
			}
		}
		//-----------------------------------------------------------
		if(PaperSendBackSensor == 1 && g_iSignalOper == 0) { //�ɴ�������
			//�ɴ�������
			if(MachineIsBeging == 1) {
				if(FeiDaBackTime >= CONF.FeiDaBackTime) {
					PaperSendBackSensor = 0;
					CurrFeiDaOperator = FEIDAOPERATOR_FEIDARETREAT;
				}					
			} else {
				PaperSendBackSensor = 0;
				CurrFeiDaOperator = FEIDAOPERATOR_FEIDARETREAT;
			}
		}
		if(PaperSendStop == 1 && g_iSignalOper == 0) {
			PaperSendStop = 0;
			CurrFeiDaOperator = FEIDAOPERATOR_FEIDASTOP;
		}
		if(CurrFeiDaOperator != 0 && AlarmCodeAndStop == 0) {
			uint16_t oper = CurrFeiDaOperator; 
			CurrFeiDaOperator = 0;
			switch (oper)
      {
      	case FEIDAOPERATOR_FEIDAFOWWARD: {
					FeiDaMotorForward();
					if(g_iSchema == SCHEMA_TESTMODE) {
						UploadStateNow_WithOneParam(ID_FEIDAMOTORFORWARD,g_uiQEI0);
					}
				}
      		break;
      	case FEIDAOPERATOR_FEIDARETREAT: {
					FeiDaMotorRetreat();
					if(g_iSchema == SCHEMA_TESTMODE) {
						UploadStateNow_WithOneParam(ID_FEIDAMOTORRETREAT,g_uiQEI0);
					}	
				}
      		break;
				case FEIDAOPERATOR_FEIDASTOP: {
					FeiDaMotorStop();
					if(g_iSchema == SCHEMA_TESTMODE) {
						UploadStateNow_WithOneParam(ID_FEIDAMOTORSTOP,g_uiQEI0);
					}	
				}
					break;
      	default:
      		break;
      }
		}
		//----------------------------------------------
		if(AlarmCodeAndStop != 0 && LastAlarmCode != AlarmCodeAndStop) { //����
			LastAlarmCode = AlarmCodeAndStop;
			AlarmCodeAndStop = 0;
			MachineIsBeging = 0;
			MachineIsPause = 1;
			Solenoid2Down = 1;
			SOLENOID2Time = 0;
			
			P_C_OUT_2 = 1;
			P_C_OUT_3 = 1;
			
			if(P_C_OUT_5 == 0) {
				P_C_OUT_5 = 1;
			}
			
			if(P_C_OUT_7 == 0) {
				P_C_OUT_7 = 1;
			}
			
			//if(P_C_OUT_6 == 0) {P_C_OUT_6 = 1;}
			if(g_u32FlagIsHeating == 0) {
				EPWM_Stop(C_HEAT_PWM,C_HEAT_PUL_MASK);
				EPWM_ForceStop(C_HEAT_PWM,C_HEAT_PUL_MASK);
				EPWM_DisableOutput(C_HEAT_PWM,C_HEAT_PUL_MASK);
				g_u32FlagIsHeating = 1;
			}
			
			switch (LastAlarmCode)
      {
        case ALARM_PAPERPLATELOW: {
					f_MotorStop(0);
					g_AlarmCode = ALARM_PAPERPLATELOW;
					FMDUploadAlarm();
				}
        	break;
        case ALARM_INPAPERUNDETECTED: {
					f_MotorStop(0);
					g_AlarmCode = ALARM_INPAPERUNDETECTED;
					FMDUploadAlarm();
				}
        	break;
				case ALARM_BROKENPAPERMOTOR: {
					f_MotorStop(0);
					g_AlarmCode = ALARM_BROKENPAPERMOTOR;
					FMDUploadAlarm();
				}
        default:
        	break;
      }
		}
		//----------------------------------------------		
		if(InitTime > CONF.InitTime) { // ��ʼ��	
			InitTime = 0;
			if(g_iSchema == SCHEMA_WORKMODE) {
				if(MachineIsBeging == 0) {
					if(P_C_M2_EN == 0) {
						EPWM_Stop(C_M2_PWM, C_M2_PUL_MASK);
						EPWM_DisableOutput(C_M2_PWM, C_M2_PUL_MASK);
						P_C_M2_EN = 1;
					}
					
					if(P_C_M1_EN == 0) {
						EPWM_Stop(C_M1_PWM, C_M1_PUL_MASK);
						EPWM_DisableOutput(C_M1_PWM, C_M1_PUL_MASK);
						P_C_M1_EN = 1;
					}
	
					if(P_C_M3_EN == 0) {
						EPWM_Stop(C_M3_PWM, C_M3_PUL_MASK);
						EPWM_DisableOutput(C_M3_PWM, C_M3_PUL_MASK);
						P_C_M3_EN = 1;
					}
					
					if(P_C_M4_EN == 0) {
						EPWM_Stop(C_M4_PWM, C_M4_PUL_MASK);
						EPWM_DisableOutput(C_M4_PWM, C_M4_PUL_MASK);
						P_C_M4_EN = 1;
					}
					
					if(P_C_M5_EN == 0) {
						EPWM_Stop(C_M5_PWM, C_M5_PUL_MASK);
						EPWM_DisableOutput(C_M5_PWM, C_M5_PUL_MASK);
						P_C_M5_EN = 1;
					}
	
					if(P_C_OUT_4 == 0) {
						P_C_OUT_4 = 1;
					}
					
					if(P_C_INPUT_5 == 1) { //�ɴﴫ���������Ļ�
						FeiDaMotorForward();
					}
					
					if(P_C_INPUT_11 == 1) { // ��ֽ��������⵽1������ȱ�ڴ���Ҫ�˶�����ȱ�ڴ�
						CUTRUNTime = 0;
						Init_Motor1Run = 1;
						f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
					}
					
					if(P_C_OUT_2 == 0) {
						P_C_OUT_2 = 1;
					}
					if(P_C_OUT_3 == 0) {
						P_C_OUT_3 = 1;
					}
				}	
			}	
		}
		if(EADCTime > CONF.ADTime ) { //ע��:�ڶ�ʱ������printf�������>10����
		  EADCTime =0;
			doAD();		
			//----------------------------------------------�жϼ���
			if(g_u32FlagIsHeating == 0) {
				uint32_t u32Temp = f_GetTemperatureFrom(g_C_AD6_V);
				if(u32Temp <= (CONF.LaminateHeatTemperature*9/10)) {
					EPWM_ConfigOutputChannel(C_HEAT_PWM, C_HEAT_PUL, CONF.Heat_Fhz, 0);
				} else {
					uint32_t u32Duty = f_PIDCalulate(u32Temp);
					EPWM_ConfigOutputChannel(C_HEAT_PWM, C_HEAT_PUL, CONF.Heat_Fhz, u32Duty);
					if(g_iSchema == SCHEMA_TESTMODE) {
						UploadStateNow_WithOneParam(ID_UPLOADTEMP_DUTY,u32Duty);
					}
				}											
			}
			//----------------------------------------------
		}
		if(UPTime> CONF.UPTime ) { //ע��:�ڶ�ʱ������printf�������>10����
				UPTime = 0;
			if((g_au8YourMacAddr[0] == 0xFF)
						&& (g_au8YourMacAddr[1] == 0xFF)
						&& (g_au8YourMacAddr[2] == 0xFF)
						&& (g_au8YourMacAddr[3] == 0xFF)
						&& (g_au8YourMacAddr[4] == 0xFF)
						&& (g_au8YourMacAddr[5] == 0xFF)) {
					//�ϴ�ʱ�䵽  ARP ���� % d... % d...\r\n), CONF.UPTime, CONF.EMACTime);
						iFMDOutPutStatus();
						tempUPTime = CONF.EMACTime;
				} else {
						FMDOutPutStatus();//ZHOU:����̶�ʱ���ϴ�״̬
						tempUPTime = CONF.UPTime; 
				}
		}		
	} //while(1){//��ѭ��

	return 0;
}

