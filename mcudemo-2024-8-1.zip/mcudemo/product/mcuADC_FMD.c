#include "NuMicro.h"
#include <stdio.h>
#include <string.h>

#include "mcuCmd_FMD.h"

volatile uint32_t g_C_AD1_V = 0;   //
volatile uint32_t g_C_AD0_V = 0;   //
volatile uint32_t g_C_AD7_V = 0;   //
volatile uint32_t g_C_AD6_V = 0;   //

volatile uint32_t g_C_AD1[8] = { 0,0,0,0,0,0,0,0 };   //
volatile uint32_t g_C_AD0[8] = { 0,0,0,0,0,0,0,0 };   //
volatile uint32_t g_C_AD7[8] = { 0,0,0,0,0,0,0,0 };   //
volatile uint32_t g_C_AD6[8] = { 0,0,0,0,0,0,0,0 };   //


void doAD(void)
{
	//	int32_t  u32ChannelCount;
	//printf("doAD_begin\n");
	int32_t  i32ConversionData;

	uint8_t  u32SAMPLECount = 0;
	int32_t  n32ConversionData[16] = { 0 };

	int32_t  i32V = 0;

	EADC_Open(EADC, EADC_CTL_DIFFEN_SINGLE_END);

	EADC_ConfigSampleModule(EADC, S_C_AD1, EADC_ADINT0_TRIGGER, N_C_AD1);
	EADC_ConfigSampleModule(EADC, S_C_AD0, EADC_ADINT0_TRIGGER, N_C_AD0);
	
	EADC_ConfigSampleModule(EADC, S_C_AD7, EADC_ADINT0_TRIGGER, N_C_AD7);
	EADC_ConfigSampleModule(EADC, S_C_AD6, EADC_ADINT0_TRIGGER, N_C_AD6);
	
	//NVIC_EnableIRQ(ADC0_IRQn);//ZHOU:��

	//EADC_CLR_INT_FLAG();
	
	EADC_START_CONV(EADC,  B_C_AD1 | B_C_AD0 | B_C_AD7 | B_C_AD6 );

	/* Wait conversion done */
	while (EADC_GET_DATA_VALID_FLAG(EADC, (B_C_AD1 | B_C_AD0 | B_C_AD7 | B_C_AD6)));
	printf("doAD__1\n");

	i32V = 0;
	i32ConversionData = EADC_GET_CONV_DATA(EADC, S_C_AD1);
	//Log(BN(AD�������� C_AD1 ͨ�� : %d  ���� : 0x%X(%d)\r\n), S_C_AD1, i32ConversionData, i32ConversionData);
	if (g_C_AD1[0] == 0) {
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData;
	}
	else if (g_C_AD1[1] == 0) {
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[1];
		i32V /= 2;
	}
	else if (g_C_AD1[2] == 0) {
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[2] + g_C_AD1[1];
		i32V /= 3;
	}
	else if (g_C_AD1[3] == 0) {
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];
		i32V /= 4;
	}
	else if (g_C_AD1[4] == 0) {
		g_C_AD1[4] = g_C_AD1[3];
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[4] + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];
		i32V /= 5;
	}
	else if (g_C_AD1[5] == 0) {
		g_C_AD1[5] = g_C_AD1[4];
		g_C_AD1[4] = g_C_AD1[3];
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[5] + g_C_AD1[4] + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];
		i32V /= 6;
	}
	else if (g_C_AD1[6] == 0) {
		g_C_AD1[6] = g_C_AD1[5];
		g_C_AD1[5] = g_C_AD1[4];
		g_C_AD1[4] = g_C_AD1[3];
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[6] + g_C_AD1[5] + g_C_AD1[4] + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];
		i32V /= 7;
	}
	else if (g_C_AD1[7] == 0) {
		g_C_AD1[7] = g_C_AD1[6];
		g_C_AD1[6] = g_C_AD1[5];
		g_C_AD1[5] = g_C_AD1[4];
		g_C_AD1[4] = g_C_AD1[3];
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[7] + g_C_AD1[6] + g_C_AD1[5] + g_C_AD1[4] + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];
		//		i32V >>= 3;
		i32V /= 8;	
	}
	else {
		g_C_AD1[7] = g_C_AD1[6];
		g_C_AD1[6] = g_C_AD1[5];
		g_C_AD1[5] = g_C_AD1[4];
		g_C_AD1[4] = g_C_AD1[3];
		g_C_AD1[3] = g_C_AD1[2];
		g_C_AD1[2] = g_C_AD1[1];
		g_C_AD1[1] = g_C_AD1[0];
		g_C_AD1[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD1[7] + g_C_AD1[6] + g_C_AD1[5] + g_C_AD1[4] + g_C_AD1[3] + g_C_AD1[2] + g_C_AD1[1];		//		i32V >>= 3;
		i32V /= 8;
	}

//	i32V -= CONF.C_AD1_0;
	g_C_AD1_V = (((i32V > 0) ? i32V : 0) & 0xfff); //(i32V > 0) ? i32V : 0;
	//printf("doAD__2\n");

  //Log(BN(���� AD�������� C_AD1 ͨ�� : %d  ���� : 0x%X(%d) \r\n), S_C_AD1, g_C_AD1_V, g_C_AD1_V);
  
	i32V = 0;
	i32ConversionData = EADC_GET_CONV_DATA(EADC, S_C_AD0);
//	Log(BN(AD�������� C_AD0 ͨ�� : %d  ���� : 0x%X(%d)\r\n), S_C_AD0, i32ConversionData, i32ConversionData);
	if (g_C_AD0[0] == 0) {
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData;
	}
	else if (g_C_AD0[1] == 0) {
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[1];
		i32V /= 2;
	}
	else if (g_C_AD0[2] == 0) {
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[2] + g_C_AD0[1];
		i32V /= 3;
	}
	else if (g_C_AD0[3] == 0) {
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];
		i32V /= 4;
	}

	else if (g_C_AD0[4] == 0) {
		g_C_AD0[4] = g_C_AD0[3];
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[4] + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];
		i32V /= 5;
	}

	else if (g_C_AD0[5] == 0) {
		g_C_AD0[5] = g_C_AD0[4];
		g_C_AD0[4] = g_C_AD0[3];
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[5] + g_C_AD0[4] + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];
		i32V /= 6;

	}
	else if (g_C_AD0[6] == 0) {
		g_C_AD0[6] = g_C_AD0[5];
		g_C_AD0[5] = g_C_AD0[4];
		g_C_AD0[4] = g_C_AD0[3];
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;

		i32V = i32ConversionData + g_C_AD0[6] + g_C_AD0[5] + g_C_AD0[4] + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];
		i32V /= 7;
	}
	else if (g_C_AD0[7] == 0) {
		g_C_AD0[7] = g_C_AD0[6];
		g_C_AD0[6] = g_C_AD0[5];
		g_C_AD0[5] = g_C_AD0[4];
		g_C_AD0[4] = g_C_AD0[3];
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[7] + g_C_AD0[6] + g_C_AD0[5] + g_C_AD0[4] + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];
		//		i32V >>= 3;
		i32V /= 8;
		
	}
	else {
		g_C_AD0[7] = g_C_AD0[6];
		g_C_AD0[6] = g_C_AD0[5];
		g_C_AD0[5] = g_C_AD0[4];
		g_C_AD0[4] = g_C_AD0[3];
		g_C_AD0[3] = g_C_AD0[2];
		g_C_AD0[2] = g_C_AD0[1];
		g_C_AD0[1] = g_C_AD0[0];
		g_C_AD0[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD0[7] + g_C_AD0[6] + g_C_AD0[5] + g_C_AD0[4] + g_C_AD0[3] + g_C_AD0[2] + g_C_AD0[1];		//		i32V >>= 3;
		i32V /= 8;
	}

//	i32V += CONF.C_AD0_0;
  	g_C_AD0_V = (((i32V > 0) ? i32V : 0) & 0xfff);
  //	g_C_AD0_V = ((((i32V > 0) ? i32V : 0) >> 2) & 0x3ff);
  	//printf("doAD__3\n");
//	Log(BN(���� AD�������� C_AD0 ͨ�� : %d  ���� : 0x%X(%d) �¶� %d \r\n), S_C_AD0, g_C_AD0_V, g_C_AD0_V,g_C_AD0_V_T );

	i32V = 0;
	i32ConversionData = EADC_GET_CONV_DATA(EADC, S_C_AD7);
//	Log(BN(AD�������� C_AD7 ͨ�� : %d  ���� : 0x%X(%d)\r\n), S_C_AD7, i32ConversionData, i32ConversionData);
	if (g_C_AD7[0] == 0) {
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData;
	}
	else if (g_C_AD7[1] == 0) {
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[1];
		i32V /= 2;
	}
	else if (g_C_AD7[2] == 0) {
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[2] + g_C_AD7[1];
		i32V /= 3;
	}
	else if (g_C_AD7[3] == 0) {
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];
		i32V /= 4;
	}

	else if (g_C_AD7[4] == 0) {
		g_C_AD7[4] = g_C_AD7[3];
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[4] + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];
		i32V /= 5;
	}

	else if (g_C_AD7[5] == 0) {
		g_C_AD7[5] = g_C_AD7[4];
		g_C_AD7[4] = g_C_AD7[3];
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[5] + g_C_AD7[4] + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];
		i32V /= 6;

	}
	else if (g_C_AD7[6] == 0) {
		g_C_AD7[6] = g_C_AD7[5];
		g_C_AD7[5] = g_C_AD7[4];
		g_C_AD7[4] = g_C_AD7[3];
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;

		i32V = i32ConversionData + g_C_AD7[6] + g_C_AD7[5] + g_C_AD7[4] + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];
		i32V /= 7;
	}
	else if (g_C_AD7[7] == 0) {
		g_C_AD7[7] = g_C_AD7[6];
		g_C_AD7[6] = g_C_AD7[5];
		g_C_AD7[5] = g_C_AD7[4];
		g_C_AD7[4] = g_C_AD7[3];
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[7] + g_C_AD7[6] + g_C_AD7[5] + g_C_AD7[4] + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];
		//		i32V >>= 3;
		i32V /= 8;
		
	}
	else {
		g_C_AD7[7] = g_C_AD7[6];
		g_C_AD7[6] = g_C_AD7[5];
		g_C_AD7[5] = g_C_AD7[4];
		g_C_AD7[4] = g_C_AD7[3];
		g_C_AD7[3] = g_C_AD7[2];
		g_C_AD7[2] = g_C_AD7[1];
		g_C_AD7[1] = g_C_AD7[0];
		g_C_AD7[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD7[7] + g_C_AD7[6] + g_C_AD7[5] + g_C_AD7[4] + g_C_AD7[3] + g_C_AD7[2] + g_C_AD7[1];		//		i32V >>= 3;
		i32V /= 8;
	}

//	i32V += CONF.C_AD7_0;
	
  g_C_AD7_V = (((i32V > 0) ? i32V : 0) & 0xfff);
 // 	g_C_AD7_V = ((((i32V > 0) ? i32V : 0) >> 2) & 0x3ff);
//	Log(BN(���� AD�������� C_AD7 ͨ�� : %d  ���� : 0x%X(%d) �¶� %d \r\n), S_C_AD7, g_C_AD7_V, g_C_AD7_V,g_C_AD7_V_T );
	//printf("doAD__4\n");

	i32V = 0;
	i32ConversionData = EADC_GET_CONV_DATA(EADC, S_C_AD6);
//	Log(BN(AD�������� C_AD6 ͨ�� : %d  ���� : 0x%X(%d)\r\n), S_C_AD6, i32ConversionData, i32ConversionData);
	if (g_C_AD6[0] == 0) {
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData;
	}
	else if (g_C_AD6[1] == 0) {
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[1];
		i32V /= 2;
	}
	else if (g_C_AD6[2] == 0) {
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[2] + g_C_AD6[1];
		i32V /= 3;
	}
	else if (g_C_AD6[3] == 0) {
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];
		i32V /= 4;
	}

	else if (g_C_AD6[4] == 0) {
		g_C_AD6[4] = g_C_AD6[3];
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[4] + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];
		i32V /= 5;
	}

	else if (g_C_AD6[5] == 0) {
		g_C_AD6[5] = g_C_AD6[4];
		g_C_AD6[4] = g_C_AD6[3];
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[5] + g_C_AD6[4] + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];
		i32V /= 6;

	}
	else if (g_C_AD6[6] == 0) {
		g_C_AD6[6] = g_C_AD6[5];
		g_C_AD6[5] = g_C_AD6[4];
		g_C_AD6[4] = g_C_AD6[3];
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;

		i32V = i32ConversionData + g_C_AD6[6] + g_C_AD6[5] + g_C_AD6[4] + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];
		i32V /= 7;
	}
	else if (g_C_AD6[7] == 0) {
		g_C_AD6[7] = g_C_AD6[6];
		g_C_AD6[6] = g_C_AD6[5];
		g_C_AD6[5] = g_C_AD6[4];
		g_C_AD6[4] = g_C_AD6[3];
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[7] + g_C_AD6[6] + g_C_AD6[5] + g_C_AD6[4] + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];
		//		i32V >>= 3;
		i32V /= 8;
		
	}
	else {
		g_C_AD6[7] = g_C_AD6[6];
		g_C_AD6[6] = g_C_AD6[5];
		g_C_AD6[5] = g_C_AD6[4];
		g_C_AD6[4] = g_C_AD6[3];
		g_C_AD6[3] = g_C_AD6[2];
		g_C_AD6[2] = g_C_AD6[1];
		g_C_AD6[1] = g_C_AD6[0];
		g_C_AD6[0] = i32ConversionData;
		i32V = i32ConversionData + g_C_AD6[7] + g_C_AD6[6] + g_C_AD6[5] + g_C_AD6[4] + g_C_AD6[3] + g_C_AD6[2] + g_C_AD6[1];		//		i32V >>= 3;
		i32V /= 8;
	}

//	i32V += CONF.C_AD6_0;
 	g_C_AD6_V = (((i32V > 0) ? i32V : 0) & 0xfff);
	//printf("doAD__5\n");

//	g_C_AD6_V =  ((((i32V > 0) ? i32V : 0) >> 2) & 0x3ff);
//	Log(BN(���� AD�������� C_AD6 ͨ�� : %d  ���� : 0x%X(%d) �¶� %d \r\n), S_C_AD6, g_C_AD6_V, g_C_AD6_V,g_C_AD6_V_T );
	EADC_Close(EADC);
	NVIC_DisableIRQ(ADC0_IRQn);
	//NVIC_DisableIRQ(EADC00_IRQn);
	//NVIC_DisableIRQ(EADC01_IRQn);
	//NVIC_DisableIRQ(EADC02_IRQn);
	//NVIC_DisableIRQ(EADC03_IRQn);
	//printf("doAD_End\n");

}
